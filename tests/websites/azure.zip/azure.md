Table des matières

# Documentation Azure

Découvrez comment créer et gérer des applications performantes à l'aide des services cloud Microsoft Azure. Accédez à la documentation associée, à des exemples de code, à des tutoriels et bien plus encore.

Bien démarrer

[Bien démarrer pour les développeurs Azure](https://learn.microsoft.com/fr-fr/azure/developer/)

Architecture

[Concevoir votre application en utilisant le Centre des architectures Azure](https://learn.microsoft.com/fr-fr/azure/architecture/)

Vue d'ensemble

[Préparer votre organisation avec le Framework d'adoption du cloud](https://learn.microsoft.com/fr-fr/azure/cloud-adoption-framework/)

Entrainement

[Développer vos compétences avec les formations Microsoft Learn](https://learn.microsoft.com/fr-fr/training/browse/?products=azure&resource_type=learning%20path)

[](https://learn.microsoft.com/fr-fr/azure/?product=popular#parcourir-les-produits-azure)

## Parcourir les produits Azure

-   Populaires
-   Analytics
-   Bases de données
-   Calcul
-   Conteneurs
-   DevOps
-   Gestion et gouvernance
-   Hybride + multicloud
-   IA + Machine Learning
-   Identité
-   Infrastructure VDI
-   Intégration
-   Internet des objets
-   Média
-   Migration
-   Mise en réseau
-   Mixed Reality
-   Mobile
-   Outils de développement
-   Sécurité
-   Stockage
-   Web

Populaires

-   Populaires
-   Analytics
-   Bases de données
-   Calcul
-   Conteneurs
-   DevOps
-   Gestion et gouvernance
-   Hybride + multicloud
-   IA + Machine Learning
-   Identité
-   Infrastructure VDI
-   Intégration
-   Internet des objets
-   Média
-   Migration
-   Mise en réseau
-   Mixed Reality
-   Mobile
-   Outils de développement
-   Sécurité
-   Stockage
-   Web

### Populaires

 [API Apps](https://learn.microsoft.com/fr-fr/azure/app-service/)

Générez et utilisez facilement des API de cloud

[API Apps](https://learn.microsoft.com/fr-fr/azure/app-service/)

 [API Azure pour FHIR](https://learn.microsoft.com/fr-fr/azure/healthcare-apis/azure-api-for-fhir/)

Créez et déployez facilement un service FHIR pour les solutions de données d'intégrité et l'interopérabilité

[API Azure pour FHIR](https://learn.microsoft.com/fr-fr/azure/healthcare-apis/azure-api-for-fhir/)

 [App Configuration](https://learn.microsoft.com/fr-fr/azure/azure-app-configuration/)

Stockage de paramètres rapide et évolutif pour la configuration d'application

[App Configuration](https://learn.microsoft.com/fr-fr/azure/azure-app-configuration/)

 [App Service](https://learn.microsoft.com/fr-fr/azure/app-service/)

Créez rapidement des applications cloud performantes pour le web et les appareils mobiles

[App Service](https://learn.microsoft.com/fr-fr/azure/app-service/)

 [Application Gateway](https://learn.microsoft.com/fr-fr/azure/application-gateway/)

Créez des serveurs web frontaux sécurisés, évolutifs et à haut niveau de disponibilité dans Azure

[Application Gateway](https://learn.microsoft.com/fr-fr/azure/application-gateway/)

 [Application Insights](https://learn.microsoft.com/fr-fr/azure/azure-monitor/)

Observabilité complète de vos applications, de votre infrastructure et de votre réseau

[Application Insights](https://learn.microsoft.com/fr-fr/azure/azure-monitor/)

 [Applications managées Azure](https://learn.microsoft.com/fr-fr/azure/azure-resource-manager/managed-applications/)

Simplifiez la gestion des offres cloud

[Applications managées Azure](https://learn.microsoft.com/fr-fr/azure/azure-resource-manager/managed-applications/)

 [Automatisation](https://learn.microsoft.com/fr-fr/azure/automation/)

Simplifiez la gestion du cloud en automatisant les processus

[Automatisation](https://learn.microsoft.com/fr-fr/azure/automation/)

 [Avere vFXT pour Azure](https://learn.microsoft.com/fr-fr/azure/avere-vfxt/)

Exécutez des charges de travail haute performance basées sur des fichiers dans le cloud

[Avere vFXT pour Azure](https://learn.microsoft.com/fr-fr/azure/avere-vfxt/)

 [Azure Advisor](https://learn.microsoft.com/fr-fr/azure/advisor/)

Votre moteur de recommandation personnalisé sur les meilleures pratiques Azure

[Azure Advisor](https://learn.microsoft.com/fr-fr/azure/advisor/)

 [Azure AI Bot Service](https://learn.microsoft.com/fr-fr/azure/bot-service/)

Service de bot intelligent serverless qui s'adapte à la demande

[Azure AI Bot Service](https://learn.microsoft.com/fr-fr/azure/bot-service/)

 [Azure AI services](https://learn.microsoft.com/fr-fr/azure/ai-services/)

Créez des applications de pointe, prêtes à être commercialisées, et responsables pour vos organisations avec l'IA

[Azure AI services](https://learn.microsoft.com/fr-fr/azure/ai-services/)

 [Azure AI Video Indexer](https://learn.microsoft.com/fr-fr/azure/azure-video-indexer/)

Révélez les insights des vidéos

[Azure AI Video Indexer](https://learn.microsoft.com/fr-fr/azure/azure-video-indexer/)

 [Azure Analysis Services](https://learn.microsoft.com/fr-fr/azure/analysis-services/)

Moteur d'analytique de niveau professionnel en tant que service

[Azure Analysis Services](https://learn.microsoft.com/fr-fr/azure/analysis-services/)

 [Azure Arc](https://learn.microsoft.com/fr-fr/azure/azure-arc/)

Intégrez la gestion et les services Azure à toute infrastructure

[Azure Arc](https://learn.microsoft.com/fr-fr/azure/azure-arc/)

 [Azure Artifacts](https://learn.microsoft.com/fr-fr/azure/devops/artifacts/)

Créez, hébergez et partagez des packages avec votre équipe

[Azure Artifacts](https://learn.microsoft.com/fr-fr/azure/devops/artifacts/)

 [Azure Blueprints (préversion)](https://learn.microsoft.com/fr-fr/azure/governance/blueprints/)

Création rapide et reproductible d'environnements gouvernés

[Azure Blueprints (préversion)](https://learn.microsoft.com/fr-fr/azure/governance/blueprints/)

 [Azure Boards](https://learn.microsoft.com/fr-fr/azure/devops/boards/)

Planifiez, suivez et discutez travail entre toutes vos équipes

[Azure Boards](https://learn.microsoft.com/fr-fr/azure/devops/boards/)

 [Azure Chaos Studio](https://learn.microsoft.com/fr-fr/azure/chaos-studio/)

Améliorez la résilience des applications en introduisant des défaillances et en simulant des pannes

[Azure Chaos Studio](https://learn.microsoft.com/fr-fr/azure/chaos-studio/)

 [Azure Cloud Shell](https://learn.microsoft.com/fr-fr/azure/cloud-shell/overview)

Simplifiez l'administration d'Azure avec un interpréteur de commandes basé sur un navigateur

[Azure Cloud Shell](https://learn.microsoft.com/fr-fr/azure/cloud-shell/overview)

 [Azure Communication Services](https://learn.microsoft.com/fr-fr/azure/communication-services/overview)

Créez des expériences de communication enrichies à l'aide de la même plateforme sécurisée que celle utilisée par Microsoft Teams

[Azure Communication Services](https://learn.microsoft.com/fr-fr/azure/communication-services/overview)

 [Azure Communications Gateway](https://learn.microsoft.com/fr-fr/azure/communications-gateway/)

Connecter rapidement vos réseaux fixes et mobiles à Microsoft Teams

[Azure Communications Gateway](https://learn.microsoft.com/fr-fr/azure/communications-gateway/)

 [Azure Compute Fleet (préversion)](https://learn.microsoft.com/fr-fr/azure/azure-compute-fleet/overview)

Approvisionner et gérer facilement la capacité de calcul Azure à grande échelle

[Azure Compute Fleet (préversion)](https://learn.microsoft.com/fr-fr/azure/azure-compute-fleet/overview)

 [Azure Container Apps](https://learn.microsoft.com/fr-fr/azure/container-apps/)

Créer et déployer des applications et des microservices modernes avec des conteneurs serverless

[Azure Container Apps](https://learn.microsoft.com/fr-fr/azure/container-apps/)

 [Azure Cosmos DB](https://learn.microsoft.com/fr-fr/azure/cosmos-db/)

Base de données NoSQL rapide avec des API ouvertes pour toute échelle

[Azure Cosmos DB](https://learn.microsoft.com/fr-fr/azure/cosmos-db/)

 [Azure CycleCloud](https://learn.microsoft.com/fr-fr/azure/cyclecloud/index)

Créez, gérez, exploitez et optimisez les clusters HPC et Big Compute, quelle que soit leur échelle

[Azure CycleCloud](https://learn.microsoft.com/fr-fr/azure/cyclecloud/index)

 [Azure Data Lake Storage](https://learn.microsoft.com/fr-fr/azure/storage/blobs/data-lake-storage-introduction)

Fonctionnalité de lac de données sécurisée et extrêmement scalable qui repose sur le Stockage Blob Azure

[Azure Data Lake Storage](https://learn.microsoft.com/fr-fr/azure/storage/blobs/data-lake-storage-introduction)

 [Azure Data Manager for Agriculture (préversion)](https://learn.microsoft.com/fr-fr/azure/data-manager-for-agri/)

Créer un avenir plus durable en innovant avec les données agricoles

[Azure Data Manager for Agriculture (préversion)](https://learn.microsoft.com/fr-fr/azure/data-manager-for-agri/)

 [Azure Data Share](https://learn.microsoft.com/fr-fr/azure/data-share/)

Service simple et sûr pour le partage de Big Data avec des organisations externes

[Azure Data Share](https://learn.microsoft.com/fr-fr/azure/data-share/)

 [Azure Data Studio](https://learn.microsoft.com/fr-fr/azure-data-studio/)

Éditeur léger capable d'exécuter des requêtes de pool SQL serverless et d'afficher et d'enregistrer les résultats au format texte, JSON ou Excel.

[Azure Data Studio](https://learn.microsoft.com/fr-fr/azure-data-studio/)

 [Azure Database for MariaDB](https://learn.microsoft.com/fr-fr/azure/mariadb/)

Service de base de données MariaDB managée pour les développeurs d'applications

[Azure Database for MariaDB](https://learn.microsoft.com/fr-fr/azure/mariadb/)

 [Azure Database Migration Service](https://learn.microsoft.com/fr-fr/azure/dms/)

Simplifiez la migration de base de données locale vers le cloud

[Azure Database Migration Service](https://learn.microsoft.com/fr-fr/azure/dms/)

 [Azure Database pour MySQL](https://learn.microsoft.com/fr-fr/azure/mysql/)

Service géré de base de données MySQL pour développeurs d'applications

[Azure Database pour MySQL](https://learn.microsoft.com/fr-fr/azure/mysql/)

 [Azure Database pour PostgreSQL](https://learn.microsoft.com/fr-fr/azure/postgresql/)

Service géré de base de données PostgreSQL pour développeurs d'applications

[Azure Database pour PostgreSQL](https://learn.microsoft.com/fr-fr/azure/postgresql/)

 [Azure Databricks](https://learn.microsoft.com/fr-fr/azure/databricks/)

Plateforme d'analytique Apache Spark rapide, facile et collaborative

[Azure Databricks](https://learn.microsoft.com/fr-fr/azure/databricks/)

 [Azure Dedicated Host](https://learn.microsoft.com/fr-fr/azure/virtual-machines/dedicated-hosts)

Serveur physique dédié pour héberger vos machines virtuelles Azure pour Windows et Linux

[Azure Dedicated Host](https://learn.microsoft.com/fr-fr/azure/virtual-machines/dedicated-hosts)

 [Azure DevOps](https://learn.microsoft.com/fr-fr/azure/devops/)

Services permettant aux équipes de partager du code, de suivre des tâches et de livrer des logiciels

[Azure DevOps](https://learn.microsoft.com/fr-fr/azure/devops/)

 [Azure DevTest Labs](https://learn.microsoft.com/fr-fr/azure/devtest-labs/)

Créez rapidement des environnements avec des modèles et des artefacts réutilisables

[Azure DevTest Labs](https://learn.microsoft.com/fr-fr/azure/devtest-labs/)

 [Azure DNS](https://learn.microsoft.com/fr-fr/azure/dns/)

Hébergez votre domaine DNS dans Azure

[Azure DNS](https://learn.microsoft.com/fr-fr/azure/dns/)

 [Azure Elastic SAN](https://learn.microsoft.com/fr-fr/azure/storage/elastic-san/)

Elastic SAN est un service natif cloud de réseau de zone de stockage (SAN) basé sur Azure. Bénéficiez d'un accès à une expérience de bout en bout comme votre réseau SAN local.

[Azure Elastic SAN](https://learn.microsoft.com/fr-fr/azure/storage/elastic-san/)

 [Azure ExpressRoute](https://learn.microsoft.com/fr-fr/azure/expressroute/)

Connexions de réseau privé dédiées par fibre optique à Azure

[Azure ExpressRoute](https://learn.microsoft.com/fr-fr/azure/expressroute/)

 [Azure Files](https://learn.microsoft.com/fr-fr/azure/storage/files/)

Partages de fichiers cloud simples, sécurisés et serverless de niveau entreprise

[Azure Files](https://learn.microsoft.com/fr-fr/azure/storage/files/)

 [Azure Front Door](https://learn.microsoft.com/fr-fr/azure/frontdoor/)

Point de livraison scalable avec sécurité renforcée pour des applications web mondiales basées sur des microservices

[Azure Front Door](https://learn.microsoft.com/fr-fr/azure/frontdoor/)

 [Azure Front Door et Content Delivery Network (CDN)](https://learn.microsoft.com/fr-fr/azure/frontdoor/)

Garantissez la distribution de contenu fiable et sécurisée avec une large portée générale

[Azure Front Door et Content Delivery Network (CDN)](https://learn.microsoft.com/fr-fr/azure/frontdoor/)

 [Azure Functions](https://learn.microsoft.com/fr-fr/azure/azure-functions/)

Traitez les événements avec du code sans serveur

[Azure Functions](https://learn.microsoft.com/fr-fr/azure/azure-functions/)

 [Azure FXT Edge Filer](https://learn.microsoft.com/fr-fr/azure/fxt-edge-filer/)

Solution d'optimisation du stockage hybride pour les environnements HPC

[Azure FXT Edge Filer](https://learn.microsoft.com/fr-fr/azure/fxt-edge-filer/)

 [Azure Health Data Services](https://learn.microsoft.com/fr-fr/azure/healthcare-apis/)

Solution unifiée qui permet de protéger et combiner des données d'intégrité dans le cloud, et génère des insights de santé avec l'analytique

[Azure Health Data Services](https://learn.microsoft.com/fr-fr/azure/healthcare-apis/)

 [Azure HPC Cache](https://learn.microsoft.com/fr-fr/azure/hpc-cache/)

Mise en cache de fichiers pour le calcul haute performance (HPC)

[Azure HPC Cache](https://learn.microsoft.com/fr-fr/azure/hpc-cache/)

 [Azure Information Protection](https://learn.microsoft.com/fr-fr/azure/information-protection/)

Améliorez la protection de vos informations sensibles à tout moment et en tout lieu

[Azure Information Protection](https://learn.microsoft.com/fr-fr/azure/information-protection/)

 [Azure IoT](https://learn.microsoft.com/fr-fr/azure/iot/)

Une collection de services cloud et de périphérie gérés par Microsoft qui permettent de connecter, superviser et contrôler des milliards de ressources IoT.

[Azure IoT](https://learn.microsoft.com/fr-fr/azure/iot/)

 [Azure IoT Central](https://learn.microsoft.com/fr-fr/azure/iot-central/)

Accélérer la création de solutions IoT

[Azure IoT Central](https://learn.microsoft.com/fr-fr/azure/iot-central/)

 [Azure IoT Hub](https://learn.microsoft.com/fr-fr/azure/iot-hub/)

Connectez, supervisez et gérez des milliards de ressources IoT

[Azure IoT Hub](https://learn.microsoft.com/fr-fr/azure/iot-hub/)

 [Azure IoT Edge](https://learn.microsoft.com/fr-fr/azure/iot-edge/)

Étendez l'intelligence cloud et l'analytique aux appareils en périphérie

[Azure IoT Edge](https://learn.microsoft.com/fr-fr/azure/iot-edge/)

 [Azure Kubernetes Fleet Manager (Fleet)](https://learn.microsoft.com/fr-fr/azure/kubernetes-fleet/)

Activer des scénarios multi-cluster et à grande échelle pour les clusters Azure Kubernetes Service

[Azure Kubernetes Fleet Manager (Fleet)](https://learn.microsoft.com/fr-fr/azure/kubernetes-fleet/)

 [Azure Kubernetes Service (AKS)](https://learn.microsoft.com/fr-fr/azure/aks/)

Simplifiez le déploiement, la gestion et les opérations de Kubernetes

[Azure Kubernetes Service (AKS)](https://learn.microsoft.com/fr-fr/azure/aks/)

 [Azure Kubernetes Service Edge Essentials](https://learn.microsoft.com/fr-fr/azure/aks/hybrid/aks-edge-overview)

Une implémentation Kubernetes locale d'Azure Kubernetes Service (AKS) qui automatise l'exécution d'applications conteneurisées à grande échelle

[Azure Kubernetes Service Edge Essentials](https://learn.microsoft.com/fr-fr/azure/aks/hybrid/aks-edge-overview)

 [Azure Lab Services](https://learn.microsoft.com/fr-fr/azure/lab-services/)

Configurez des labos pour des salles de classe, des épreuves, du développement et des tests, et autres scénarios

[Azure Lab Services](https://learn.microsoft.com/fr-fr/azure/lab-services/)

 [Azure Lab Services](https://learn.microsoft.com/fr-fr/azure/lab-services/)

Configurer des laboratoires virtuels pour des cours, des formations, des hackathons et d'autres scénarios associés

[Azure Lab Services](https://learn.microsoft.com/fr-fr/azure/lab-services/)

 [Azure Lighthouse](https://learn.microsoft.com/fr-fr/azure/lighthouse/)

Autorisez les fournisseurs de services à gérer les clients à grande échelle et avec précision

[Azure Lighthouse](https://learn.microsoft.com/fr-fr/azure/lighthouse/)

 [Azure Load Testing](https://learn.microsoft.com/fr-fr/azure/load-testing/)

Générer une charge à grande échelle et identifier les goulots d'étranglement au niveau des performances

[Azure Load Testing](https://learn.microsoft.com/fr-fr/azure/load-testing/)

 [Azure Machine Learning](https://learn.microsoft.com/fr-fr/azure/machine-learning/)

Proposez l'intelligence artificielle à tous avec une plateforme de bout en bout, évolutive et approuvée qui inclut l'expérimentation et la gestion des modèles

[Azure Machine Learning](https://learn.microsoft.com/fr-fr/azure/machine-learning/)

 [Azure Managed Lustre](https://learn.microsoft.com/fr-fr/azure/azure-managed-lustre/)

Un système de fichiers parallèle basé sur le cloud complètement managé qui permet aux clients d'exécuter leurs charges de travail de calcul haute performance dans le cloud

[Azure Managed Lustre](https://learn.microsoft.com/fr-fr/azure/azure-managed-lustre/)

 [Azure Managed Instance pour Apache Cassandra](https://learn.microsoft.com/fr-fr/azure/managed-instance-apache-cassandra/)

Automatisez le déploiement et la mise à l'échelle pour les centres de données Apache Cassandra open source managés

[Azure Managed Instance pour Apache Cassandra](https://learn.microsoft.com/fr-fr/azure/managed-instance-apache-cassandra/)

 [Azure Maps](https://learn.microsoft.com/fr-fr/azure/azure-maps/)

Les API de géolocalisation simples et sécurisées fournissent un contexte géospatial aux données

[Azure Maps](https://learn.microsoft.com/fr-fr/azure/azure-maps/)

 [Azure Media Player](https://learn.microsoft.com/fr-fr/azure/media-services/latest/player-media-players-concept)

Un seul lecteur pour tous vos besoins de lecture

[Azure Media Player](https://learn.microsoft.com/fr-fr/azure/media-services/latest/player-media-players-concept)

 [Azure Migrate](https://learn.microsoft.com/fr-fr/azure/migrate/)

Détectez, évaluez, dimensionnez et migrez facilement vos machines virtuelles locales vers Azure

[Azure Migrate](https://learn.microsoft.com/fr-fr/azure/migrate/)

 [Azure Monitor](https://learn.microsoft.com/fr-fr/azure/azure-monitor/)

Observabilité complète de vos applications, de votre infrastructure et de votre réseau

[Azure Monitor](https://learn.microsoft.com/fr-fr/azure/azure-monitor/)

 [Azure NetApp Files](https://learn.microsoft.com/fr-fr/azure/azure-netapp-files/)

Partages de fichiers Azure de classe Entreprise, basés sur NetApp

[Azure NetApp Files](https://learn.microsoft.com/fr-fr/azure/azure-netapp-files/)

 [Azure Network Function Manager](https://learn.microsoft.com/fr-fr/azure/network-function-manager/)

Étendre la gestion Azure pour le déploiement de fonctions réseau 5G et SD-WAN sur des appareils de périphérie

[Azure Network Function Manager](https://learn.microsoft.com/fr-fr/azure/network-function-manager/)

 [Azure Open Datasets](https://learn.microsoft.com/fr-fr/azure/open-datasets/)

Plateforme cloud permettant d'héberger et de partager des jeux de données ouverts organisés pour accélérer le développement de modèles de Machine Learning

[Azure Open Datasets](https://learn.microsoft.com/fr-fr/azure/open-datasets/)

 [Azure OpenAI Service](https://learn.microsoft.com/fr-fr/azure/ai-services/openai/)

Appliquer des modèles de codage et de langage avancés à divers cas d'usage

[Azure OpenAI Service](https://learn.microsoft.com/fr-fr/azure/ai-services/openai/)

 [Azure Operator Insights](https://learn.microsoft.com/fr-fr/azure/operator-insights/)

Analyser les données réseau à partir de plusieurs sources

[Azure Operator Insights](https://learn.microsoft.com/fr-fr/azure/operator-insights/)

 [Azure Operator Nexus](https://learn.microsoft.com/fr-fr/azure/operator-nexus/)

Générer vos réseaux mobiles stratégiques avec une plateforme cloud hybride de qualité opérateur

[Azure Operator Nexus](https://learn.microsoft.com/fr-fr/azure/operator-nexus/)

 [Azure Operator Service Manager](https://learn.microsoft.com/fr-fr/azure/operator-service-manager/)

Gérer les services réseau sur les sites cloud hybrides

[Azure Operator Service Manager](https://learn.microsoft.com/fr-fr/azure/operator-service-manager/)

 [Azure Orbital Ground Station](https://learn.microsoft.com/fr-fr/azure/orbital/)

Services de station terrienne et de planification pour une transmission rapide des données

[Azure Orbital Ground Station](https://learn.microsoft.com/fr-fr/azure/orbital/)

 [Azure Pipelines](https://learn.microsoft.com/fr-fr/azure/devops/pipelines/)

Créez, testez et déployez en continu sur la plateforme et le cloud de votre choix

[Azure Pipelines](https://learn.microsoft.com/fr-fr/azure/devops/pipelines/)

 [Azure Policy](https://learn.microsoft.com/fr-fr/azure/governance/policy/)

Implémentez la gouvernance d'entreprise et les standards à l'échelle pour vos ressources Azure

[Azure Policy](https://learn.microsoft.com/fr-fr/azure/governance/policy/)

 [Azure Private Link](https://learn.microsoft.com/fr-fr/azure/private-link/)

Accès privé aux services hébergés sur la plateforme Azure, tout en conservant vos données sur le réseau Microsoft

[Azure Private Link](https://learn.microsoft.com/fr-fr/azure/private-link/)

 [Azure Private 5G Core](https://learn.microsoft.com/fr-fr/azure/private-5g-core/)

Déployer et gérer rapidement des réseaux 5G privés à la périphérie de l'entreprise

[Azure Private 5G Core](https://learn.microsoft.com/fr-fr/azure/private-5g-core/)

 [Azure Quantum (préversion)](https://learn.microsoft.com/fr-fr/azure/quantum/)

Découvrez aujourd'hui l'impact quantique sur Azure

[Azure Quantum (préversion)](https://learn.microsoft.com/fr-fr/azure/quantum/)

 [Azure Red Hat OpenShift](https://learn.microsoft.com/fr-fr/azure/virtual-machines/linux/openshift-get-started)

Service OpenShift complètement managé, fourni avec Red Hat

[Azure Red Hat OpenShift](https://learn.microsoft.com/fr-fr/azure/virtual-machines/linux/openshift-get-started)

 [Azure Remote Rendering](https://learn.microsoft.com/fr-fr/azure/remote-rendering/)

Affichez du contenu 3D interactif de haute qualité et diffusez-le sur vos appareils en temps réel

[Azure Remote Rendering](https://learn.microsoft.com/fr-fr/azure/remote-rendering/)

 [Azure Repos](https://learn.microsoft.com/fr-fr/azure/devops/repos/)

Bénéficiez d'un nombre illimité de dépôts Git privés hébergés dans le cloud pour votre projet

[Azure Repos](https://learn.microsoft.com/fr-fr/azure/devops/repos/)

 [Azure Resource Manager](https://learn.microsoft.com/fr-fr/azure/azure-resource-manager/)

Simplifiez la façon dont vous gérez les ressources de vos applications

[Azure Resource Manager](https://learn.microsoft.com/fr-fr/azure/azure-resource-manager/)

 [Azure Resource Mover](https://learn.microsoft.com/fr-fr/azure/resource-mover/)

Simplifiez le déplacement de plusieurs ressources d'une région Azure à une autre

[Azure Resource Mover](https://learn.microsoft.com/fr-fr/azure/resource-mover/)

 [Azure Service Health](https://learn.microsoft.com/fr-fr/azure/service-health/)

Conseils et support personnalisés quand des problèmes avec les services Azure vous affectent

[Azure Service Health](https://learn.microsoft.com/fr-fr/azure/service-health/)

 [Azure Site Recovery](https://learn.microsoft.com/fr-fr/azure/site-recovery/)

Assurez le fonctionnement continu de votre entreprise avec le service de reprise d'activité après sinistre intégré

[Azure Site Recovery](https://learn.microsoft.com/fr-fr/azure/site-recovery/)

 [Azure Sphere](https://learn.microsoft.com/fr-fr/azure-sphere/)

Connectez de façon sécurisée des appareils MCU du silicone au cloud

[Azure Sphere](https://learn.microsoft.com/fr-fr/azure-sphere/)

 [Azure Spring Apps](https://learn.microsoft.com/fr-fr/azure/spring-apps/)

Service Spring Cloud complètement managé, créé et exploité avec Pivotal

[Azure Spring Apps](https://learn.microsoft.com/fr-fr/azure/spring-apps/)

 [Azure SQL](https://learn.microsoft.com/fr-fr/azure/azure-sql/index)

Famille SQL moderne pour la modernisation de la migration et des applications

[Azure SQL](https://learn.microsoft.com/fr-fr/azure/azure-sql/index)

 [Azure SQL Database](https://learn.microsoft.com/fr-fr/azure/azure-sql/database/index)

SQL intelligent managé dans le cloud

[Azure SQL Database](https://learn.microsoft.com/fr-fr/azure/azure-sql/database/index)

 [Azure SQL Edge](https://learn.microsoft.com/fr-fr/azure/azure-sql-edge/)

Moteur de données à faible empreinte, optimisé pour la périphérie, avec IA intégré

[Azure SQL Edge](https://learn.microsoft.com/fr-fr/azure/azure-sql-edge/)

 [Azure SQL Managed Instance](https://learn.microsoft.com/fr-fr/azure/azure-sql/managed-instance/index)

Instance SQL managée et toujours à jour dans le cloud

[Azure SQL Managed Instance](https://learn.microsoft.com/fr-fr/azure/azure-sql/managed-instance/index)

 [Azure Stack](https://learn.microsoft.com/fr-fr/azure-stack/)

Générez et exécutez des applications hybrides novatrices dans les limites du cloud

[Azure Stack](https://learn.microsoft.com/fr-fr/azure-stack/)

 [Azure Stack Edge](https://learn.microsoft.com/fr-fr/azure/databox-online/)

Une appliance managée Azure qui permet à la périphérie de bénéficier du calcul, du stockage et de l'intelligence d'Azure

[Azure Stack Edge](https://learn.microsoft.com/fr-fr/azure/databox-online/)

 [Azure Stack HCI](https://learn.microsoft.com/fr-fr/azure-stack/hci/)

Intégrer une infrastructure hyperconvergée à Azure et à des services hybrides pour exécuter des charges de travail virtuelles locales

[Azure Stack HCI](https://learn.microsoft.com/fr-fr/azure-stack/hci/)

 [Azure Stack Hub](https://learn.microsoft.com/fr-fr/azure-stack/operator/)

Azure Stack Hub est vendu en tant que système matériel intégré, avec des logiciels préinstallés sur du matériel validé

[Azure Stack Hub](https://learn.microsoft.com/fr-fr/azure-stack/operator/)

 [Azure Stream Analytics](https://learn.microsoft.com/fr-fr/azure/stream-analytics/)

Analytique en temps réel sur les flux de données en déplacement rapide provenant d'applications et d'appareils

[Azure Stream Analytics](https://learn.microsoft.com/fr-fr/azure/stream-analytics/)

 [Azure Synapse Analytics](https://learn.microsoft.com/fr-fr/azure/synapse-analytics/)

Service analytique illimité avec un temps d'accès aux insights inégalé

[Azure Synapse Analytics](https://learn.microsoft.com/fr-fr/azure/synapse-analytics/)

 [Azure Test Plans](https://learn.microsoft.com/fr-fr/azure/devops/test/)

Testez et livrez en toute confiance avec un kit de tests exploratoires et manuels

[Azure Test Plans](https://learn.microsoft.com/fr-fr/azure/devops/test/)

 [Azure Time Series Insights](https://learn.microsoft.com/fr-fr/azure/time-series-insights/)

Explorez et analysez les données de série chronologique des appareils IoT

[Azure Time Series Insights](https://learn.microsoft.com/fr-fr/azure/time-series-insights/)

 [Azure Update Manager](https://learn.microsoft.com/fr-fr/azure/update-manager/)

Gérer de manière centralisée les mises à jour et la conformité à grande échelle

[Azure Update Manager](https://learn.microsoft.com/fr-fr/azure/update-manager/)

 [Azure Virtual Desktop](https://learn.microsoft.com/fr-fr/azure/virtual-desktop/)

La meilleure expérience de bureau virtuel sur Azure

[Azure Virtual Desktop](https://learn.microsoft.com/fr-fr/azure/virtual-desktop/)

 [Azure VMware Solution](https://learn.microsoft.com/fr-fr/azure/azure-vmware/)

Exécutez vos charges de travail VMware en mode natif sur Azure

[Azure VMware Solution](https://learn.microsoft.com/fr-fr/azure/azure-vmware/)

 [Azure Web PubSub](https://learn.microsoft.com/fr-fr/azure/azure-web-pubsub/)

Créer facilement des applications web de messagerie en temps réel avec des WebSockets et le modèle publication-abonnement

[Azure Web PubSub](https://learn.microsoft.com/fr-fr/azure/azure-web-pubsub/)

 [Azure Digital Twins](https://learn.microsoft.com/fr-fr/azure/digital-twins/)

Élaborer des solutions d'intelligence spatiale IoT de nouvelle génération

[Azure Digital Twins](https://learn.microsoft.com/fr-fr/azure/digital-twins/)

 [Batch](https://learn.microsoft.com/fr-fr/azure/batch/)

Planifiez les tâches et la gestion des calculs à l'échelle du cloud

[Batch](https://learn.microsoft.com/fr-fr/azure/batch/)

 [Cache Azure pour Redis](https://learn.microsoft.com/fr-fr/azure/azure-cache-for-redis/)

Alimentez les applications avec un accès aux données à débit élevé et à latence faible

[Cache Azure pour Redis](https://learn.microsoft.com/fr-fr/azure/azure-cache-for-redis/)

 [Container Instances](https://learn.microsoft.com/fr-fr/azure/container-instances/)

Exécutez facilement des conteneurs sur Azure sans gérer les serveurs

[Container Instances](https://learn.microsoft.com/fr-fr/azure/container-instances/)

 [Container Registry](https://learn.microsoft.com/fr-fr/azure/container-registry/)

Stocker et gérer les images de conteneur pour tous les types de déploiements Azure

[Container Registry](https://learn.microsoft.com/fr-fr/azure/container-registry/)

 [Content Safety](https://learn.microsoft.com/fr-fr/azure/ai-services/content-safety/)

Utiliser l'IA pour surveiller le contenu de texte et d'image pour assurer la sécurité

[Content Safety](https://learn.microsoft.com/fr-fr/azure/ai-services/content-safety/)

 [Cost Management + facturation](https://learn.microsoft.com/fr-fr/azure/cost-management-billing/)

Optimisez vos dépenses sur le cloud, tout en maximisant le potentiel du cloud

[Cost Management + facturation](https://learn.microsoft.com/fr-fr/azure/cost-management-billing/)

 [Data Box](https://learn.microsoft.com/fr-fr/azure/databox/)

Appliances et solutions pour le transfert de données vers Azure

[Data Box](https://learn.microsoft.com/fr-fr/azure/databox/)

 [Data Factory](https://learn.microsoft.com/fr-fr/azure/data-factory/)

Intégration de données hybrides facilitée à l'échelle de l'entreprise

[Data Factory](https://learn.microsoft.com/fr-fr/azure/data-factory/)

 [Data Lake Analytics](https://learn.microsoft.com/fr-fr/azure/data-lake-analytics/)

Service d'analyse distribué facilitant les Big Data

[Data Lake Analytics](https://learn.microsoft.com/fr-fr/azure/data-lake-analytics/)

 [Data Science Virtual Machine](https://learn.microsoft.com/fr-fr/azure/machine-learning/data-science-virtual-machine/)

Riche environnement préconfiguré pour le développement de l'IA

[Data Science Virtual Machine](https://learn.microsoft.com/fr-fr/azure/machine-learning/data-science-virtual-machine/)

 [Encodage](https://learn.microsoft.com/fr-fr/azure/media-services/latest/encode-concept)

Encodage de type studio à l'échelle du cloud

[Encodage](https://learn.microsoft.com/fr-fr/azure/media-services/latest/encode-concept)

 [Environnements de déploiement Azure](https://learn.microsoft.com/fr-fr/azure/deployment-environments/)

Créer rapidement des environnements d'infrastructure d'application avec des modèles basés sur des projets

[Environnements de déploiement Azure](https://learn.microsoft.com/fr-fr/azure/deployment-environments/)

 [Équilibreur de charge](https://learn.microsoft.com/fr-fr/azure/load-balancer/)

Fournissez une haute disponibilité et des performances réseau optimales à vos applications

[Équilibreur de charge](https://learn.microsoft.com/fr-fr/azure/load-balancer/)

 [Event Grid](https://learn.microsoft.com/fr-fr/azure/event-grid/)

Bénéficiez d'une livraison fiable d'événement à grande échelle

[Event Grid](https://learn.microsoft.com/fr-fr/azure/event-grid/)

 [Event Hubs](https://learn.microsoft.com/fr-fr/azure/event-hubs/)

Recevez des données de télémétrie provenant de millions d'appareils

[Event Hubs](https://learn.microsoft.com/fr-fr/azure/event-hubs/)

 [Explorateur de données Azure](https://learn.microsoft.com/fr-fr/azure/data-explorer)

Service d'exploration des données rapide et très scalable

[Explorateur de données Azure](https://learn.microsoft.com/fr-fr/azure/data-explorer)

 [Explorateur Stockage](https://learn.microsoft.com/fr-fr/azure/vs-azure-tools-storage-manage-with-storage-explorer)

Consultez et utilisez les ressources Stockage Azure

[Explorateur Stockage](https://learn.microsoft.com/fr-fr/azure/vs-azure-tools-storage-manage-with-storage-explorer)

 [Face](https://learn.microsoft.com/fr-fr/azure/ai-services/computer-vision/overview-identity)

Détecter, identifier, analyser, organiser et baliser les visages dans des photos

[Face](https://learn.microsoft.com/fr-fr/azure/ai-services/computer-vision/overview-identity)

 [Gestion des API](https://learn.microsoft.com/fr-fr/azure/api-management/)

Publiez des API en toute sécurité et à grande échelle pour les développeurs, les partenaires et les employés

[Gestion des API](https://learn.microsoft.com/fr-fr/azure/api-management/)

 [GitHub Actions pour Azure](https://learn.microsoft.com/fr-fr/azure/developer/github/github-actions)

Créer, tester et déployer une application de GitHub sur Azure

[GitHub Actions pour Azure](https://learn.microsoft.com/fr-fr/azure/developer/github/github-actions)

 [Grafana géré par Azure](https://learn.microsoft.com/fr-fr/azure/managed-grafana/)

Déployer des tableaux de bord Grafana en tant que service Azure entièrement géré

[Grafana géré par Azure](https://learn.microsoft.com/fr-fr/azure/managed-grafana/)

 [HDInsight](https://learn.microsoft.com/fr-fr/azure/hdinsight/)

Approvisionnez les clusters Hadoop, Spark, R Server, HBase et Storm dans le cloud

[HDInsight](https://learn.microsoft.com/fr-fr/azure/hdinsight/)

 [HDInsight sur AKS](https://learn.microsoft.com/fr-fr/azure/hdinsight-aks/)

Déployer des charges de travail Apache Spark, Apache Flink et Trino sans gérer et surveiller les conteneurs

[HDInsight sur AKS](https://learn.microsoft.com/fr-fr/azure/hdinsight-aks/)

 [Health Bot](https://learn.microsoft.com/fr-fr/azure/health-bot/)

Service managé conçu pour le développement d'assistants médicaux virtuels.

[Health Bot](https://learn.microsoft.com/fr-fr/azure/health-bot/)

 [Intelligence documentaire](https://learn.microsoft.com/fr-fr/azure/ai-services/document-intelligence/)

Service d'extraction de documents alimenté par l'IA qui comprend vos formulaires

[Intelligence documentaire](https://learn.microsoft.com/fr-fr/azure/ai-services/document-intelligence/)

 [Key Vault](https://learn.microsoft.com/fr-fr/azure/key-vault/)

Protégez les clés et autres secrets et gardez-en le contrôle

[Key Vault](https://learn.microsoft.com/fr-fr/azure/key-vault/)

 [Kinect DK](https://learn.microsoft.com/fr-fr/azure/kinect-dk/)

Créez des modèles de vision par ordinateur et vocaux en utilisant un kit de développement avec des capteurs IA avancés

[Kinect DK](https://learn.microsoft.com/fr-fr/azure/kinect-dk/)

 [Langage](https://learn.microsoft.com/fr-fr/azure/ai-services/language-service/)

Évaluez facilement les sentiments et les sujets pour comprendre ce que veulent les utilisateurs

[Langage](https://learn.microsoft.com/fr-fr/azure/ai-services/language-service/)

 [Lecteur immersif](https://learn.microsoft.com/fr-fr/azure/ai-services/immersive-reader/)

Permettez aux utilisateurs de tous âges et de toutes capacités de lire et de comprendre le texte

[Lecteur immersif](https://learn.microsoft.com/fr-fr/azure/ai-services/immersive-reader/)

 [Log Analytics](https://learn.microsoft.com/fr-fr/azure/azure-monitor/)

Observabilité complète de vos applications, de votre infrastructure et de votre réseau

[Log Analytics](https://learn.microsoft.com/fr-fr/azure/azure-monitor/)

 [Logic Apps](https://learn.microsoft.com/fr-fr/azure/logic-apps/)

Automatisez l'accès à vos données et leur utilisation dans différents clouds sans écrire de code

[Logic Apps](https://learn.microsoft.com/fr-fr/azure/logic-apps/)

 [Machines Virtuelles](https://learn.microsoft.com/fr-fr/azure/virtual-machines/)

Approvisionner des machines virtuelles pour Ubuntu, Red Hat, Windows, et bien plus encore

[Machines Virtuelles](https://learn.microsoft.com/fr-fr/azure/virtual-machines/)

 [Machines virtuelles Azure Spot](https://learn.microsoft.com/fr-fr/azure/virtual-machines/spot-vms)

Provisionner des capacités de calcul inutilisées avec des remises importantes pour exécuter des charges de travail interruptibles

[Machines virtuelles Azure Spot](https://learn.microsoft.com/fr-fr/azure/virtual-machines/spot-vms)

 [Media Services](https://learn.microsoft.com/fr-fr/azure/media-services/latest/)

Encodez, stockez et diffusez du contenu audio et vidéo à grande échelle

[Media Services](https://learn.microsoft.com/fr-fr/azure/media-services/latest/)

 [Microsoft Azure Data Manager for Energy (préversion)](https://learn.microsoft.com/fr-fr/azure/energy-data-services/)

Accélérer votre parcours vers la modernisation et la transformation numérique des données relatives aux énergies

[Microsoft Azure Data Manager for Energy (préversion)](https://learn.microsoft.com/fr-fr/azure/energy-data-services/)

 [Microsoft Copilot for Azure (Préversion)](https://learn.microsoft.com/fr-fr/azure/copilot)

Simplifier les opérations et la gestion du cloud vers la périphérie avec un compagnon IA

[Microsoft Copilot for Azure (Préversion)](https://learn.microsoft.com/fr-fr/azure/copilot)

 [Microsoft Defender pour IoT](https://learn.microsoft.com/fr-fr/azure/defender-for-iot/)

Gestion continue des actifs et détection des menaces pour les appareils IoT/OT managés et non managés

[Microsoft Defender pour IoT](https://learn.microsoft.com/fr-fr/azure/defender-for-iot/)

 [Microsoft Defender pour la gestion des surfaces d'attaque externe](https://learn.microsoft.com/fr-fr/azure/external-attack-surface-management/overview)

Protéger l'expérience numérique en découvrant toutes les ressources exposées sur Internet

[Microsoft Defender pour la gestion des surfaces d'attaque externe](https://learn.microsoft.com/fr-fr/azure/external-attack-surface-management/overview)

 [Microsoft Defender pour le cloud](https://learn.microsoft.com/fr-fr/azure/defender-for-cloud/)

Gestion de la posture de sécurité et protection avancée contre les menaces sur des charges de travail Azure, hybrides et multiclouds

[Microsoft Defender pour le cloud](https://learn.microsoft.com/fr-fr/azure/defender-for-cloud/)

 [Microsoft Dev Box](https://learn.microsoft.com/fr-fr/azure/dev-box/)

Simplifier le développement avec des stations de travail prêtes à l'emploi sécurisées dans le cloud

[Microsoft Dev Box](https://learn.microsoft.com/fr-fr/azure/dev-box/)

 [Microsoft Entra External ID](https://learn.microsoft.com/fr-fr/entra/external-id/)

Gestion des identités et des accès des consommateurs dans le cloud

[Microsoft Entra External ID](https://learn.microsoft.com/fr-fr/entra/external-id/)

 [Microsoft Entra ID](https://learn.microsoft.com/fr-fr/entra/identity/)

Synchronisez les répertoires locaux et activez l'authentification unique

[Microsoft Entra ID](https://learn.microsoft.com/fr-fr/entra/identity/)

 [Microsoft Genomics](https://learn.microsoft.com/fr-fr/azure/genomics/)

Optimisez le séquençage des génomes et les insights de recherche

[Microsoft Genomics](https://learn.microsoft.com/fr-fr/azure/genomics/)

 [Microsoft Playwright Testing (préversion)](https://learn.microsoft.com/fr-fr/azure/playwright-testing/)

Exécuter des tests Playwright à grande échelle

[Microsoft Playwright Testing (préversion)](https://learn.microsoft.com/fr-fr/azure/playwright-testing/)

 [Microsoft Sentinel](https://learn.microsoft.com/fr-fr/azure/sentinel/)

Mettez au travail l'analytique de sécurité intelligente et SIEM cloud-native pour contribuer à la protection de votre entreprise

[Microsoft Sentinel](https://learn.microsoft.com/fr-fr/azure/sentinel/)

 [Microsoft.Purview](https://learn.microsoft.com/fr-fr/purview/index)

Optimiser la valeur métier avec une gouvernance des données unifiée

[Microsoft.Purview](https://learn.microsoft.com/fr-fr/purview/index)

 [Modèles ARM](https://learn.microsoft.com/fr-fr/azure/azure-resource-manager/templates/)

Livrez une infrastructure en tant que code pour toutes vos ressources Azure en utilisant Resource Manager

[Modèles ARM](https://learn.microsoft.com/fr-fr/azure/azure-resource-manager/templates/)

 [Module de sécurité matériel (HSM) dédié Azure](https://learn.microsoft.com/fr-fr/azure/dedicated-hsm/)

Gérez les modules de sécurité matériels que vous utilisez dans le cloud

[Module de sécurité matériel (HSM) dédié Azure](https://learn.microsoft.com/fr-fr/azure/dedicated-hsm/)

 [NAT Gateway](https://learn.microsoft.com/fr-fr/azure/nat-gateway/)

Fournir une connectivité sortante à l\'Internet hautement fiable, sécurisée et évolutive

[NAT Gateway](https://learn.microsoft.com/fr-fr/azure/nat-gateway/)

 [Notification Hubs](https://learn.microsoft.com/fr-fr/azure/notification-hubs/)

Envoyez des notifications Push vers n'importe quelle plateforme à partir d'un back end

[Notification Hubs](https://learn.microsoft.com/fr-fr/azure/notification-hubs/)

 [Object Anchors (préversion)](https://learn.microsoft.com/fr-fr/azure/object-anchors/)

Alignez et ancrez automatiquement du contenu 3D à des objets du monde physique

[Object Anchors (préversion)](https://learn.microsoft.com/fr-fr/azure/object-anchors/)

 [Opérations Azure IoT (préversion)](https://learn.microsoft.com/fr-fr/azure/iot-operations/)

Déverrouiller des insights pour des actions locales intelligentes et une visibilité globale

[Opérations Azure IoT (préversion)](https://learn.microsoft.com/fr-fr/azure/iot-operations/)

 [Pare-feu Azure](https://learn.microsoft.com/fr-fr/azure/firewall/)

Fonctionnalités de pare-feu natives, avec une haute disponibilité intégrée, une scalabilité cloud illimitée et aucune maintenance

[Pare-feu Azure](https://learn.microsoft.com/fr-fr/azure/firewall/)

 [Pare-feu d'applications web](https://learn.microsoft.com/fr-fr/azure/web-application-firewall/)

Service de pare-feu d'applications web (WAF) cloud natif qui fournit une solide protection aux applications web

[Pare-feu d'applications web](https://learn.microsoft.com/fr-fr/azure/web-application-firewall/)

 [Passerelle VPN](https://learn.microsoft.com/fr-fr/azure/vpn-gateway/)

Établissez une connectivité sécurisée intersite

[Passerelle VPN](https://learn.microsoft.com/fr-fr/azure/vpn-gateway/)

 [Portail Microsoft Azure](https://learn.microsoft.com/fr-fr/azure/azure-portal/)

Générez, gérez et surveillez tous les produits Azure dans une seule et même console

[Portail Microsoft Azure](https://learn.microsoft.com/fr-fr/azure/azure-portal/)

 [Power BI Embedded](https://learn.microsoft.com/fr-fr/power-bi/developer/azure-pbie-what-is-power-bi-embedded)

Incorporez des visualisations de données totalement interactives et saisissantes dans vos applications

[Power BI Embedded](https://learn.microsoft.com/fr-fr/power-bi/developer/azure-pbie-what-is-power-bi-embedded)

 [Protection DDoS dans Azure](https://learn.microsoft.com/fr-fr/azure/ddos-protection/)

Protéger ses applications contre les attaques DDoS (Distributed Denial of Service, déni de service distribué)

[Protection DDoS dans Azure](https://learn.microsoft.com/fr-fr/azure/ddos-protection/)

 [Protection du contenu](https://learn.microsoft.com/fr-fr/azure/media-services/latest/drm-content-protection-concept)

Fournissez en toute sécurité des contenus à l'aide d'AES, de PlayReady, de Widevine et de Fairplay

[Protection du contenu](https://learn.microsoft.com/fr-fr/azure/media-services/latest/drm-content-protection-concept)

 [Recherche Azure AI](https://learn.microsoft.com/fr-fr/azure/search/)

Service de recherche cloud alimenté par l'IA pour développer des applications mobiles et web

[Recherche Azure AI](https://learn.microsoft.com/fr-fr/azure/search/)

 [Registre confidentiel Azure](https://learn.microsoft.com/fr-fr/azure/confidential-ledger/)

Un magasin de données non structuré et infalsifiable hébergé dans des environnements d'exécution de confiance et étayé par une preuve cryptographique vérifiable

[Registre confidentiel Azure](https://learn.microsoft.com/fr-fr/azure/confidential-ledger/)

 [Relais Azure Fluid](https://learn.microsoft.com/fr-fr/azure/azure-fluid-relay/)

Ajouter facilement des expériences collaboratives en temps réel à vos applications avec Infrastructure Fluid

[Relais Azure Fluid](https://learn.microsoft.com/fr-fr/azure/azure-fluid-relay/)

 [Réseau virtuel](https://learn.microsoft.com/fr-fr/azure/virtual-network/)

Mettez en service des réseaux privés et établissez une connexion à des centres de données locaux

[Réseau virtuel](https://learn.microsoft.com/fr-fr/azure/virtual-network/)

 [Sauvegarde Azure](https://learn.microsoft.com/fr-fr/azure/backup/)

Simplifiez la protection des données et protégez-vous contre le ransomware

[Sauvegarde Azure](https://learn.microsoft.com/fr-fr/azure/backup/)

 [Service Azure SignalR](https://learn.microsoft.com/fr-fr/azure/azure-signalr/)

Ajouter facilement des fonctionnalités web en temps réel

[Service Azure SignalR](https://learn.microsoft.com/fr-fr/azure/azure-signalr/)

 [Service Bus](https://learn.microsoft.com/fr-fr/azure/service-bus-messaging/)

Connectez-vous à des environnements de cloud privés et publics

[Service Bus](https://learn.microsoft.com/fr-fr/azure/service-bus-messaging/)

 [Service Fabric](https://learn.microsoft.com/fr-fr/azure/service-fabric/)

Développez les microservices et orchestrez des conteneurs sur Windows ou Linux

[Service Fabric](https://learn.microsoft.com/fr-fr/azure/service-fabric/)

 [Services cloud](https://learn.microsoft.com/fr-fr/azure/cloud-services-extended-support/)

Créez des API et des applications cloud hautement disponibles et évolutives à l'infini

[Services cloud](https://learn.microsoft.com/fr-fr/azure/cloud-services-extended-support/)

 [Services de domaine Microsoft Entra](https://learn.microsoft.com/fr-fr/entra/identity/domain-services/)

Joignez des machines virtuelles Azure à un domaine sans contrôleur de domaine

[Services de domaine Microsoft Entra](https://learn.microsoft.com/fr-fr/entra/identity/domain-services/)

 [Spatial Anchors](https://learn.microsoft.com/fr-fr/azure/spatial-anchors/)

Créer des expériences de réalité mixte multi-utilisateurs sensibles à l'espace

[Spatial Anchors](https://learn.microsoft.com/fr-fr/azure/spatial-anchors/)

 [SQL Server sur les machines virtuelles](https://learn.microsoft.com/fr-fr/azure/azure-sql/virtual-machines/windows/sql-server-on-azure-vm-iaas-what-is-overview?toc=/azure/virtual-machines/windows/toc.json)

Hébergez des applications SQL Server d'entreprise dans le cloud

[SQL Server sur les machines virtuelles](https://learn.microsoft.com/fr-fr/azure/azure-sql/virtual-machines/windows/sql-server-on-azure-vm-iaas-what-is-overview?toc=/azure/virtual-machines/windows/toc.json)

 [Static Web Apps](https://learn.microsoft.com/fr-fr/azure/static-web-apps/)

Un service d'application web moderne qui offre un développement full-stack fluide, du code source à la haute disponibilité mondiale

[Static Web Apps](https://learn.microsoft.com/fr-fr/azure/static-web-apps/)

 [Stockage](https://learn.microsoft.com/fr-fr/azure/storage/)

Stockage dans le cloud durable, hautement disponible et considérablement évolutif

[Stockage](https://learn.microsoft.com/fr-fr/azure/storage/)

 [Stockage archive](https://learn.microsoft.com/fr-fr/azure/storage/blobs/access-tiers-overview)

Prix leader du secteur pour le stockage des données auxquelles vous accédez rarement

[Stockage archive](https://learn.microsoft.com/fr-fr/azure/storage/blobs/access-tiers-overview)

 [Stockage Blob](https://learn.microsoft.com/fr-fr/azure/storage/blobs/)

Stockage d'objets basé sur REST pour les données non structurées

[Stockage Blob](https://learn.microsoft.com/fr-fr/azure/storage/blobs/)

 [Stockage de conteneur Azure](https://learn.microsoft.com/fr-fr/azure/storage/container-storage/)

Gérer des volumes persistants pour des applications de conteneur avec état

[Stockage de conteneur Azure](https://learn.microsoft.com/fr-fr/azure/storage/container-storage/)

 [Stockage File d'attente](https://learn.microsoft.com/fr-fr/azure/storage/queues/)

Faire évoluer vos applications en fonction du trafic

[Stockage File d'attente](https://learn.microsoft.com/fr-fr/azure/storage/queues/)

 [Stockage sur disque](https://learn.microsoft.com/fr-fr/azure/virtual-machines/managed-disks-overview)

Stockage de blocs à haute durabilité et à hautes performances pour Machines virtuelles Azure

[Stockage sur disque](https://learn.microsoft.com/fr-fr/azure/virtual-machines/managed-disks-overview)

 [Stockage Table](https://learn.microsoft.com/fr-fr/azure/storage/tables/table-storage-overview)

Stockage de valeurs de clé NoSQL utilisant des jeux de données semi-structurées

[Stockage Table](https://learn.microsoft.com/fr-fr/azure/storage/tables/table-storage-overview)

 [StorSimple](https://learn.microsoft.com/fr-fr/azure/storsimple/)

Réduction des coûts avec une solution de stockage cloud hybride de classe Entreprise

[StorSimple](https://learn.microsoft.com/fr-fr/azure/storsimple/)

 [Streaming à la demande et live](https://learn.microsoft.com/fr-fr/azure/media-services/latest/stream-live-tutorial-with-api)

Effectuez la remise du contenu sur tous les appareils à une échelle adaptée aux besoins de l'entreprise

[Streaming à la demande et live](https://learn.microsoft.com/fr-fr/azure/media-services/latest/stream-live-tutorial-with-api)

 [Tous les services de mise en réseau](https://learn.microsoft.com/fr-fr/azure/networking/)

Fournissent une connectivité à vos ressources dans Azure, livrent et protègent les applications et permettent de sécuriser votre réseau.

[Tous les services de mise en réseau](https://learn.microsoft.com/fr-fr/azure/networking/)

 [Traducteur](https://learn.microsoft.com/fr-fr/azure/ai-services/translator/)

Obtenez facilement une traduction machine en appelant simplement une API REST

[Traducteur](https://learn.microsoft.com/fr-fr/azure/ai-services/translator/)

 [Virtual Machine Scale Sets](https://learn.microsoft.com/fr-fr/azure/virtual-machine-scale-sets/)

Gérez et mettez à l'échelle jusqu'à des milliers de machines virtuelles Windows et Linux

[Virtual Machine Scale Sets](https://learn.microsoft.com/fr-fr/azure/virtual-machine-scale-sets/)

 [Vision](https://learn.microsoft.com/fr-fr/azure/ai-services/computer-vision/)

Diffuser des informations actionnables à partir d'images

[Vision](https://learn.microsoft.com/fr-fr/azure/ai-services/computer-vision/)

 [Vision personnalisée](https://learn.microsoft.com/fr-fr/azure/ai-services/custom-vision-service/)

Personnalisez facilement vos excellents modèles de vision par ordinateur pour votre propre cas d'usage

[Vision personnalisée](https://learn.microsoft.com/fr-fr/azure/ai-services/custom-vision-service/)

 [Visual Studio](https://learn.microsoft.com/fr-fr/visualstudio/windows)

Environnement puissant et flexible pour développer des applications dans le cloud

[Visual Studio](https://learn.microsoft.com/fr-fr/visualstudio/windows)

 [Visual Studio App Center](https://learn.microsoft.com/fr-fr/appcenter/)

Créez, testez, publiez et supervisez en continu vos applications mobiles et de bureau

[Visual Studio App Center](https://learn.microsoft.com/fr-fr/appcenter/)

 [Visual Studio Code](https://code.visualstudio.com/docs)

Éditeur de code léger et performant pour le développement cloud

[Visual Studio Code](https://code.visualstudio.com/docs)

 [Voix](https://learn.microsoft.com/fr-fr/azure/ai-services/speech-service/)

Reconnaissance vocale, conversion de texte par synthèse vocale, traduction et reconnaissance de l\'orateur

[Voix](https://learn.microsoft.com/fr-fr/azure/ai-services/speech-service/)

 [WAN virtuel](https://learn.microsoft.com/fr-fr/azure/virtual-wan/)

Service hub-and-spoke géré par Microsoft pour la connectivité et la sécurité

[WAN virtuel](https://learn.microsoft.com/fr-fr/azure/virtual-wan/)

 [Web App pour conteneurs](https://learn.microsoft.com/fr-fr/azure/app-service/)

Déployer et exécuter facilement des applications web en conteneur qui évoluent avec votre entreprise

[Web App pour conteneurs](https://learn.microsoft.com/fr-fr/azure/app-service/)

 [Web Apps](https://learn.microsoft.com/fr-fr/azure/app-service/)

Créez et déployez rapidement des applications web stratégiques à grande échelle

[Web Apps](https://learn.microsoft.com/fr-fr/azure/app-service/)

 [Windows 10 IoT Core Services](https://learn.microsoft.com/fr-fr/windows-hardware/manufacture/iot/iotcoreservicesoverview)

Support à long terme du système d'exploitation et services pour gérer les mises à jour des appareils et évaluer leur intégrité

[Windows 10 IoT Core Services](https://learn.microsoft.com/fr-fr/windows-hardware/manufacture/iot/iotcoreservicesoverview)

 [Windows pour IoT](https://learn.microsoft.com/fr-fr/windows/iot/)

Créer des solutions de périphérie intelligentes avec des outils de classe mondiale pour développeur, un support à long terme et une sécurité de niveau entreprise

[Windows pour IoT](https://learn.microsoft.com/fr-fr/windows/iot/)

 [Xamarin](https://learn.microsoft.com/fr-fr/xamarin/)

Créez des applications mobiles cloud plus rapidement

[Xamarin](https://learn.microsoft.com/fr-fr/xamarin/)

### Analytics

-   [Azure Analysis Services](https://learn.microsoft.com/fr-fr/azure/analysis-services/)
    Moteur d'analytique de niveau professionnel en tant que service

-   [Azure Chaos Studio](https://learn.microsoft.com/fr-fr/azure/chaos-studio/)
    Améliorez la résilience des applications en introduisant des défaillances et en simulant des pannes

-   [Azure Data Lake Storage](https://learn.microsoft.com/fr-fr/azure/storage/blobs/data-lake-storage-introduction)
    Fonctionnalité de lac de données sécurisée et extrêmement scalable qui repose sur le Stockage Blob Azure

-   [Azure Data Share](https://learn.microsoft.com/fr-fr/azure/data-share/)
    Service simple et sûr pour le partage de Big Data avec des organisations externes

-   [Azure Databricks](https://learn.microsoft.com/fr-fr/azure/databricks/)
    Plateforme d'analytique Apache Spark rapide, facile et collaborative

-   [Azure Stream Analytics](https://learn.microsoft.com/fr-fr/azure/stream-analytics/)
    Analytique en temps réel sur les flux de données en déplacement rapide provenant d'applications et d'appareils

-   [Azure Synapse Analytics](https://learn.microsoft.com/fr-fr/azure/synapse-analytics/)
    Service analytique illimité avec un temps d'accès aux insights inégalé

-   [Data Factory](https://learn.microsoft.com/fr-fr/azure/data-factory/)
    Intégration de données hybrides facilitée à l'échelle de l'entreprise

-   [Data Lake Analytics](https://learn.microsoft.com/fr-fr/azure/data-lake-analytics/)
    Service d'analyse distribué facilitant les Big Data

-   [Event Hubs](https://learn.microsoft.com/fr-fr/azure/event-hubs/)
    Recevez des données de télémétrie provenant de millions d'appareils

-   [Explorateur de données Azure](https://learn.microsoft.com/fr-fr/azure/data-explorer)
    Service d'exploration des données rapide et très scalable

-   [HDInsight](https://learn.microsoft.com/fr-fr/azure/hdinsight/)
    Approvisionnez les clusters Hadoop, Spark, R Server, HBase et Storm dans le cloud

-   [HDInsight sur AKS](https://learn.microsoft.com/fr-fr/azure/hdinsight-aks/)
    Déployer des charges de travail Apache Spark, Apache Flink et Trino sans gérer et surveiller les conteneurs

-   [Log Analytics](https://learn.microsoft.com/fr-fr/azure/azure-monitor/)
    Observabilité complète de vos applications, de votre infrastructure et de votre réseau

-   [Microsoft.Purview](https://learn.microsoft.com/fr-fr/purview/index)
    Optimiser la valeur métier avec une gouvernance des données unifiée

-   [Power BI Embedded](https://learn.microsoft.com/fr-fr/power-bi/developer/azure-pbie-what-is-power-bi-embedded)
    Incorporez des visualisations de données totalement interactives et saisissantes dans vos applications

### Bases de données

-   [Azure Cosmos DB](https://learn.microsoft.com/fr-fr/azure/cosmos-db/)
    Base de données NoSQL rapide avec des API ouvertes pour toute échelle

-   [Azure Database for MariaDB](https://learn.microsoft.com/fr-fr/azure/mariadb/)
    Service de base de données MariaDB managée pour les développeurs d'applications

-   [Azure Database Migration Service](https://learn.microsoft.com/fr-fr/azure/dms/)
    Simplifiez la migration de base de données locale vers le cloud

-   [Azure Database pour MySQL](https://learn.microsoft.com/fr-fr/azure/mysql/)
    Service géré de base de données MySQL pour développeurs d'applications

-   [Azure Database pour PostgreSQL](https://learn.microsoft.com/fr-fr/azure/postgresql/)
    Service géré de base de données PostgreSQL pour développeurs d'applications

-   [Azure Managed Instance pour Apache Cassandra](https://learn.microsoft.com/fr-fr/azure/managed-instance-apache-cassandra/)
    Automatisez le déploiement et la mise à l'échelle pour les centres de données Apache Cassandra open source managés

-   [Azure SQL](https://learn.microsoft.com/fr-fr/azure/azure-sql/index)
    Famille SQL moderne pour la modernisation de la migration et des applications

-   [Azure SQL Database](https://learn.microsoft.com/fr-fr/azure/azure-sql/database/index)
    SQL intelligent managé dans le cloud

-   [Azure SQL Edge](https://learn.microsoft.com/fr-fr/azure/azure-sql-edge/)
    Moteur de données à faible empreinte, optimisé pour la périphérie, avec IA intégré

-   [Azure SQL Managed Instance](https://learn.microsoft.com/fr-fr/azure/azure-sql/managed-instance/index)
    Instance SQL managée et toujours à jour dans le cloud

-   [Cache Azure pour Redis](https://learn.microsoft.com/fr-fr/azure/azure-cache-for-redis/)
    Alimentez les applications avec un accès aux données à débit élevé et à latence faible

-   [Registre confidentiel Azure](https://learn.microsoft.com/fr-fr/azure/confidential-ledger/)
    Un magasin de données non structuré et infalsifiable hébergé dans des environnements d'exécution de confiance et étayé par une preuve cryptographique vérifiable

-   [SQL Server sur les machines virtuelles](https://learn.microsoft.com/fr-fr/azure/azure-sql/virtual-machines/windows/sql-server-on-azure-vm-iaas-what-is-overview?toc=/azure/virtual-machines/windows/toc.json)
    Hébergez des applications SQL Server d'entreprise dans le cloud

-   [Stockage Table](https://learn.microsoft.com/fr-fr/azure/storage/tables/table-storage-overview)
    Stockage de valeurs de clé NoSQL utilisant des jeux de données semi-structurées

### Calcul

-   [API Apps](https://learn.microsoft.com/fr-fr/azure/app-service/)
    Générez et utilisez facilement des API de cloud

-   [App Service](https://learn.microsoft.com/fr-fr/azure/app-service/)
    Créez rapidement des applications cloud performantes pour le web et les appareils mobiles

-   [Azure Compute Fleet (préversion)](https://learn.microsoft.com/fr-fr/azure/azure-compute-fleet/overview)
    Approvisionner et gérer facilement la capacité de calcul Azure à grande échelle

-   [Azure CycleCloud](https://learn.microsoft.com/fr-fr/azure/cyclecloud/index)
    Créez, gérez, exploitez et optimisez les clusters HPC et Big Compute, quelle que soit leur échelle

-   [Azure Dedicated Host](https://learn.microsoft.com/fr-fr/azure/virtual-machines/dedicated-hosts)
    Serveur physique dédié pour héberger vos machines virtuelles Azure pour Windows et Linux

-   [Azure Functions](https://learn.microsoft.com/fr-fr/azure/azure-functions/)
    Traitez les événements avec du code sans serveur

-   [Azure Kubernetes Fleet Manager (Fleet)](https://learn.microsoft.com/fr-fr/azure/kubernetes-fleet/)
    Activer des scénarios multi-cluster et à grande échelle pour les clusters Azure Kubernetes Service

-   [Azure Kubernetes Service (AKS)](https://learn.microsoft.com/fr-fr/azure/aks/)
    Simplifiez le déploiement, la gestion et les opérations de Kubernetes

-   [Azure Quantum (préversion)](https://learn.microsoft.com/fr-fr/azure/quantum/)
    Découvrez aujourd'hui l'impact quantique sur Azure

-   [Azure Spring Apps](https://learn.microsoft.com/fr-fr/azure/spring-apps/)
    Service Spring Cloud complètement managé, créé et exploité avec Pivotal

-   [Azure Virtual Desktop](https://learn.microsoft.com/fr-fr/azure/virtual-desktop/)
    La meilleure expérience de bureau virtuel sur Azure

-   [Azure VMware Solution](https://learn.microsoft.com/fr-fr/azure/azure-vmware/)
    Exécutez vos charges de travail VMware en mode natif sur Azure

-   [Batch](https://learn.microsoft.com/fr-fr/azure/batch/)
    Planifiez les tâches et la gestion des calculs à l'échelle du cloud

-   [Container Instances](https://learn.microsoft.com/fr-fr/azure/container-instances/)
    Exécutez facilement des conteneurs sur Azure sans gérer les serveurs

-   [Machines Virtuelles](https://learn.microsoft.com/fr-fr/azure/virtual-machines/)
    Approvisionner des machines virtuelles pour Ubuntu, Red Hat, Windows, et bien plus encore

-   [Machines virtuelles Azure Spot](https://learn.microsoft.com/fr-fr/azure/virtual-machines/spot-vms)
    Provisionner des capacités de calcul inutilisées avec des remises importantes pour exécuter des charges de travail interruptibles

-   [Service Fabric](https://learn.microsoft.com/fr-fr/azure/service-fabric/)
    Développez les microservices et orchestrez des conteneurs sur Windows ou Linux

-   [Services cloud](https://learn.microsoft.com/fr-fr/azure/cloud-services-extended-support/)
    Créez des API et des applications cloud hautement disponibles et évolutives à l'infini

-   [SQL Server sur les machines virtuelles](https://learn.microsoft.com/fr-fr/azure/azure-sql/virtual-machines/windows/sql-server-on-azure-vm-iaas-what-is-overview?toc=/azure/virtual-machines/windows/toc.json)
    Hébergez des applications SQL Server d'entreprise dans le cloud

-   [Static Web Apps](https://learn.microsoft.com/fr-fr/azure/static-web-apps/)
    Un service d'application web moderne qui offre un développement full-stack fluide, du code source à la haute disponibilité mondiale

-   [Virtual Machine Scale Sets](https://learn.microsoft.com/fr-fr/azure/virtual-machine-scale-sets/)
    Gérez et mettez à l'échelle jusqu'à des milliers de machines virtuelles Windows et Linux

-   [Web Apps](https://learn.microsoft.com/fr-fr/azure/app-service/)
    Créez et déployez rapidement des applications web stratégiques à grande échelle

### Conteneurs

-   [API Apps](https://learn.microsoft.com/fr-fr/azure/app-service/)
    Générez et utilisez facilement des API de cloud

-   [App Configuration](https://learn.microsoft.com/fr-fr/azure/azure-app-configuration/)
    Stockage de paramètres rapide et évolutif pour la configuration d'application

-   [Azure Container Apps](https://learn.microsoft.com/fr-fr/azure/container-apps/)
    Créer et déployer des applications et des microservices modernes avec des conteneurs serverless

-   [Azure Functions](https://learn.microsoft.com/fr-fr/azure/azure-functions/)
    Traitez les événements avec du code sans serveur

-   [Azure Kubernetes Fleet Manager (Fleet)](https://learn.microsoft.com/fr-fr/azure/kubernetes-fleet/)
    Activer des scénarios multi-cluster et à grande échelle pour les clusters Azure Kubernetes Service

-   [Azure Kubernetes Service (AKS)](https://learn.microsoft.com/fr-fr/azure/aks/)
    Simplifiez le déploiement, la gestion et les opérations de Kubernetes

-   [Azure Red Hat OpenShift](https://learn.microsoft.com/fr-fr/azure/virtual-machines/linux/openshift-get-started)
    Service OpenShift complètement managé, fourni avec Red Hat

-   [Container Instances](https://learn.microsoft.com/fr-fr/azure/container-instances/)
    Exécutez facilement des conteneurs sur Azure sans gérer les serveurs

-   [Container Registry](https://learn.microsoft.com/fr-fr/azure/container-registry/)
    Stocker et gérer les images de conteneur pour tous les types de déploiements Azure

-   [Service Fabric](https://learn.microsoft.com/fr-fr/azure/service-fabric/)
    Développez les microservices et orchestrez des conteneurs sur Windows ou Linux

-   [Stockage de conteneur Azure](https://learn.microsoft.com/fr-fr/azure/storage/container-storage/)
    Gérer des volumes persistants pour des applications de conteneur avec état

-   [Web App pour conteneurs](https://learn.microsoft.com/fr-fr/azure/app-service/)
    Déployer et exécuter facilement des applications web en conteneur qui évoluent avec votre entreprise

-   [Web Apps](https://learn.microsoft.com/fr-fr/azure/app-service/)
    Créez et déployez rapidement des applications web stratégiques à grande échelle

### DevOps

-   [Application Insights](https://learn.microsoft.com/fr-fr/azure/azure-monitor/)
    Observabilité complète de vos applications, de votre infrastructure et de votre réseau

-   [Azure Artifacts](https://learn.microsoft.com/fr-fr/azure/devops/artifacts/)
    Créez, hébergez et partagez des packages avec votre équipe

-   [Azure Boards](https://learn.microsoft.com/fr-fr/azure/devops/boards/)
    Planifiez, suivez et discutez travail entre toutes vos équipes

-   [Azure DevOps](https://learn.microsoft.com/fr-fr/azure/devops/)
    Services permettant aux équipes de partager du code, de suivre des tâches et de livrer des logiciels

-   [Azure DevTest Labs](https://learn.microsoft.com/fr-fr/azure/devtest-labs/)
    Créez rapidement des environnements avec des modèles et des artefacts réutilisables

-   [Azure Load Testing](https://learn.microsoft.com/fr-fr/azure/load-testing/)
    Générer une charge à grande échelle et identifier les goulots d'étranglement au niveau des performances

-   [Azure Monitor](https://learn.microsoft.com/fr-fr/azure/azure-monitor/)
    Observabilité complète de vos applications, de votre infrastructure et de votre réseau

-   [Azure Pipelines](https://learn.microsoft.com/fr-fr/azure/devops/pipelines/)
    Créez, testez et déployez en continu sur la plateforme et le cloud de votre choix

-   [Azure Repos](https://learn.microsoft.com/fr-fr/azure/devops/repos/)
    Bénéficiez d'un nombre illimité de dépôts Git privés hébergés dans le cloud pour votre projet

-   [Azure Test Plans](https://learn.microsoft.com/fr-fr/azure/devops/test/)
    Testez et livrez en toute confiance avec un kit de tests exploratoires et manuels

-   [Environnements de déploiement Azure](https://learn.microsoft.com/fr-fr/azure/deployment-environments/)
    Créer rapidement des environnements d'infrastructure d'application avec des modèles basés sur des projets

-   [GitHub Actions pour Azure](https://learn.microsoft.com/fr-fr/azure/developer/github/github-actions)
    Créer, tester et déployer une application de GitHub sur Azure

-   [Grafana géré par Azure](https://learn.microsoft.com/fr-fr/azure/managed-grafana/)
    Déployer des tableaux de bord Grafana en tant que service Azure entièrement géré

-   [Microsoft Dev Box](https://learn.microsoft.com/fr-fr/azure/dev-box/)
    Simplifier le développement avec des stations de travail prêtes à l'emploi sécurisées dans le cloud

-   [Microsoft Playwright Testing (préversion)](https://learn.microsoft.com/fr-fr/azure/playwright-testing/)
    Exécuter des tests Playwright à grande échelle

### Gestion et gouvernance

-   [Application Insights](https://learn.microsoft.com/fr-fr/azure/azure-monitor/)
    Observabilité complète de vos applications, de votre infrastructure et de votre réseau

-   [Applications managées Azure](https://learn.microsoft.com/fr-fr/azure/azure-resource-manager/managed-applications/)
    Simplifiez la gestion des offres cloud

-   [Automatisation](https://learn.microsoft.com/fr-fr/azure/automation/)
    Simplifiez la gestion du cloud en automatisant les processus

-   [Azure Advisor](https://learn.microsoft.com/fr-fr/azure/advisor/)
    Votre moteur de recommandation personnalisé sur les meilleures pratiques Azure

-   [Azure Blueprints (préversion)](https://learn.microsoft.com/fr-fr/azure/governance/blueprints/)
    Création rapide et reproductible d'environnements gouvernés

-   [Azure Chaos Studio](https://learn.microsoft.com/fr-fr/azure/chaos-studio/)
    Améliorez la résilience des applications en introduisant des défaillances et en simulant des pannes

-   [Azure Cloud Shell](https://learn.microsoft.com/fr-fr/azure/cloud-shell/overview)
    Simplifiez l'administration d'Azure avec un interpréteur de commandes basé sur un navigateur

-   [Azure Lighthouse](https://learn.microsoft.com/fr-fr/azure/lighthouse/)
    Autorisez les fournisseurs de services à gérer les clients à grande échelle et avec précision

-   [Azure Migrate](https://learn.microsoft.com/fr-fr/azure/migrate/)
    Détectez, évaluez, dimensionnez et migrez facilement vos machines virtuelles locales vers Azure

-   [Azure Monitor](https://learn.microsoft.com/fr-fr/azure/azure-monitor/)
    Observabilité complète de vos applications, de votre infrastructure et de votre réseau

-   [Azure Policy](https://learn.microsoft.com/fr-fr/azure/governance/policy/)
    Implémentez la gouvernance d'entreprise et les standards à l'échelle pour vos ressources Azure

-   [Azure Resource Manager](https://learn.microsoft.com/fr-fr/azure/azure-resource-manager/)
    Simplifiez la façon dont vous gérez les ressources de vos applications

-   [Azure Resource Mover](https://learn.microsoft.com/fr-fr/azure/resource-mover/)
    Simplifiez le déplacement de plusieurs ressources d'une région Azure à une autre

-   [Azure Service Health](https://learn.microsoft.com/fr-fr/azure/service-health/)
    Conseils et support personnalisés quand des problèmes avec les services Azure vous affectent

-   [Azure Site Recovery](https://learn.microsoft.com/fr-fr/azure/site-recovery/)
    Assurez le fonctionnement continu de votre entreprise avec le service de reprise d'activité après sinistre intégré

-   [Azure Update Manager](https://learn.microsoft.com/fr-fr/azure/update-manager/)
    Gérer de manière centralisée les mises à jour et la conformité à grande échelle

-   [Cost Management + facturation](https://learn.microsoft.com/fr-fr/azure/cost-management-billing/)
    Optimisez vos dépenses sur le cloud, tout en maximisant le potentiel du cloud

-   [Grafana géré par Azure](https://learn.microsoft.com/fr-fr/azure/managed-grafana/)
    Déployer des tableaux de bord Grafana en tant que service Azure entièrement géré

-   [Log Analytics](https://learn.microsoft.com/fr-fr/azure/azure-monitor/)
    Observabilité complète de vos applications, de votre infrastructure et de votre réseau

-   [Microsoft Copilot for Azure (Préversion)](https://learn.microsoft.com/fr-fr/azure/copilot)
    Simplifier les opérations et la gestion du cloud vers la périphérie avec un compagnon IA

-   [Microsoft Defender pour la gestion des surfaces d'attaque externe](https://learn.microsoft.com/fr-fr/azure/external-attack-surface-management/overview)
    Protéger l'expérience numérique en découvrant toutes les ressources exposées sur Internet

-   [Microsoft.Purview](https://learn.microsoft.com/fr-fr/purview/index)
    Optimiser la valeur métier avec une gouvernance des données unifiée

-   [Modèles ARM](https://learn.microsoft.com/fr-fr/azure/azure-resource-manager/templates/)
    Livrez une infrastructure en tant que code pour toutes vos ressources Azure en utilisant Resource Manager

-   [Portail Microsoft Azure](https://learn.microsoft.com/fr-fr/azure/azure-portal/)
    Générez, gérez et surveillez tous les produits Azure dans une seule et même console

-   [Sauvegarde Azure](https://learn.microsoft.com/fr-fr/azure/backup/)
    Simplifiez la protection des données et protégez-vous contre le ransomware

### Hybride + multicloud

-   [Azure Arc](https://learn.microsoft.com/fr-fr/azure/azure-arc/)
    Intégrez la gestion et les services Azure à toute infrastructure

-   [Azure Database pour PostgreSQL](https://learn.microsoft.com/fr-fr/azure/postgresql/)
    Service géré de base de données PostgreSQL pour développeurs d'applications

-   [Azure DevOps](https://learn.microsoft.com/fr-fr/azure/devops/)
    Services permettant aux équipes de partager du code, de suivre des tâches et de livrer des logiciels

-   [Azure ExpressRoute](https://learn.microsoft.com/fr-fr/azure/expressroute/)
    Connexions de réseau privé dédiées par fibre optique à Azure

-   [Azure IoT Edge](https://learn.microsoft.com/fr-fr/azure/iot-edge/)
    Étendez l'intelligence cloud et l'analytique aux appareils en périphérie

-   [Azure Kubernetes Service Edge Essentials](https://learn.microsoft.com/fr-fr/azure/aks/hybrid/aks-edge-overview)
    Une implémentation Kubernetes locale d'Azure Kubernetes Service (AKS) qui automatise l'exécution d'applications conteneurisées à grande échelle

-   [Azure Operator Insights](https://learn.microsoft.com/fr-fr/azure/operator-insights/)
    Analyser les données réseau à partir de plusieurs sources

-   [Azure Operator Nexus](https://learn.microsoft.com/fr-fr/azure/operator-nexus/)
    Générer vos réseaux mobiles stratégiques avec une plateforme cloud hybride de qualité opérateur

-   [Azure Operator Service Manager](https://learn.microsoft.com/fr-fr/azure/operator-service-manager/)
    Gérer les services réseau sur les sites cloud hybrides

-   [Azure SQL](https://learn.microsoft.com/fr-fr/azure/azure-sql/index)
    Famille SQL moderne pour la modernisation de la migration et des applications

-   [Azure Stack](https://learn.microsoft.com/fr-fr/azure-stack/)
    Générez et exécutez des applications hybrides novatrices dans les limites du cloud

-   [Azure Stack Edge](https://learn.microsoft.com/fr-fr/azure/databox-online/)
    Une appliance managée Azure qui permet à la périphérie de bénéficier du calcul, du stockage et de l'intelligence d'Azure

-   [Azure Stack HCI](https://learn.microsoft.com/fr-fr/azure-stack/hci/)
    Intégrer une infrastructure hyperconvergée à Azure et à des services hybrides pour exécuter des charges de travail virtuelles locales

-   [Azure Stack Hub](https://learn.microsoft.com/fr-fr/azure-stack/operator/)
    Azure Stack Hub est vendu en tant que système matériel intégré, avec des logiciels préinstallés sur du matériel validé

-   [Microsoft Entra ID](https://learn.microsoft.com/fr-fr/entra/identity/)
    Synchronisez les répertoires locaux et activez l'authentification unique

-   [Microsoft Sentinel](https://learn.microsoft.com/fr-fr/azure/sentinel/)
    Mettez au travail l'analytique de sécurité intelligente et SIEM cloud-native pour contribuer à la protection de votre entreprise

### IA + Machine Learning

-   [Azure AI Bot Service](https://learn.microsoft.com/fr-fr/azure/bot-service/)
    Service de bot intelligent serverless qui s'adapte à la demande

-   [Azure AI services](https://learn.microsoft.com/fr-fr/azure/ai-services/)
    Créez des applications de pointe, prêtes à être commercialisées, et responsables pour vos organisations avec l'IA

-   [Azure AI Video Indexer](https://learn.microsoft.com/fr-fr/azure/azure-video-indexer/)
    Révélez les insights des vidéos

-   [Azure Databricks](https://learn.microsoft.com/fr-fr/azure/databricks/)
    Plateforme d'analytique Apache Spark rapide, facile et collaborative

-   [Azure Machine Learning](https://learn.microsoft.com/fr-fr/azure/machine-learning/)
    Proposez l'intelligence artificielle à tous avec une plateforme de bout en bout, évolutive et approuvée qui inclut l'expérimentation et la gestion des modèles

-   [Azure Open Datasets](https://learn.microsoft.com/fr-fr/azure/open-datasets/)
    Plateforme cloud permettant d'héberger et de partager des jeux de données ouverts organisés pour accélérer le développement de modèles de Machine Learning

-   [Azure OpenAI Service](https://learn.microsoft.com/fr-fr/azure/ai-services/openai/)
    Appliquer des modèles de codage et de langage avancés à divers cas d'usage

-   [Content Safety](https://learn.microsoft.com/fr-fr/azure/ai-services/content-safety/)
    Utiliser l'IA pour surveiller le contenu de texte et d'image pour assurer la sécurité

-   [Data Science Virtual Machine](https://learn.microsoft.com/fr-fr/azure/machine-learning/data-science-virtual-machine/)
    Riche environnement préconfiguré pour le développement de l'IA

-   [Face](https://learn.microsoft.com/fr-fr/azure/ai-services/computer-vision/overview-identity)
    Détecter, identifier, analyser, organiser et baliser les visages dans des photos

-   [Health Bot](https://learn.microsoft.com/fr-fr/azure/health-bot/)
    Service managé conçu pour le développement d'assistants médicaux virtuels.

-   [Intelligence documentaire](https://learn.microsoft.com/fr-fr/azure/ai-services/document-intelligence/)
    Service d'extraction de documents alimenté par l'IA qui comprend vos formulaires

-   [Kinect DK](https://learn.microsoft.com/fr-fr/azure/kinect-dk/)
    Créez des modèles de vision par ordinateur et vocaux en utilisant un kit de développement avec des capteurs IA avancés

-   [Langage](https://learn.microsoft.com/fr-fr/azure/ai-services/language-service/)
    Évaluez facilement les sentiments et les sujets pour comprendre ce que veulent les utilisateurs

-   [Lecteur immersif](https://learn.microsoft.com/fr-fr/azure/ai-services/immersive-reader/)
    Permettez aux utilisateurs de tous âges et de toutes capacités de lire et de comprendre le texte

-   [Microsoft Genomics](https://learn.microsoft.com/fr-fr/azure/genomics/)
    Optimisez le séquençage des génomes et les insights de recherche

-   [Recherche Azure AI](https://learn.microsoft.com/fr-fr/azure/search/)
    Service de recherche cloud alimenté par l'IA pour développer des applications mobiles et web

-   [Traducteur](https://learn.microsoft.com/fr-fr/azure/ai-services/translator/)
    Obtenez facilement une traduction machine en appelant simplement une API REST

-   [Vision](https://learn.microsoft.com/fr-fr/azure/ai-services/computer-vision/)
    Diffuser des informations actionnables à partir d'images

-   [Vision personnalisée](https://learn.microsoft.com/fr-fr/azure/ai-services/custom-vision-service/)
    Personnalisez facilement vos excellents modèles de vision par ordinateur pour votre propre cas d'usage

-   [Voix](https://learn.microsoft.com/fr-fr/azure/ai-services/speech-service/)
    Reconnaissance vocale, conversion de texte par synthèse vocale, traduction et reconnaissance de l\'orateur

### Identité

-   [Azure Information Protection](https://learn.microsoft.com/fr-fr/azure/information-protection/)
    Améliorez la protection de vos informations sensibles à tout moment et en tout lieu

-   [Microsoft Entra External ID](https://learn.microsoft.com/fr-fr/entra/external-id/)
    Gestion des identités et des accès des consommateurs dans le cloud

-   [Microsoft Entra ID](https://learn.microsoft.com/fr-fr/entra/identity/)
    Synchronisez les répertoires locaux et activez l'authentification unique

-   [Services de domaine Microsoft Entra](https://learn.microsoft.com/fr-fr/entra/identity/domain-services/)
    Joignez des machines virtuelles Azure à un domaine sans contrôleur de domaine

### Infrastructure VDI

-   [Azure Lab Services](https://learn.microsoft.com/fr-fr/azure/lab-services/)
    Configurer des laboratoires virtuels pour des cours, des formations, des hackathons et d'autres scénarios associés

-   [Azure Virtual Desktop](https://learn.microsoft.com/fr-fr/azure/virtual-desktop/)
    La meilleure expérience de bureau virtuel sur Azure

-   [Microsoft Dev Box](https://learn.microsoft.com/fr-fr/azure/dev-box/)
    Simplifier le développement avec des stations de travail prêtes à l'emploi sécurisées dans le cloud

### Intégration

-   [API Azure pour FHIR](https://learn.microsoft.com/fr-fr/azure/healthcare-apis/azure-api-for-fhir/)
    Créez et déployez facilement un service FHIR pour les solutions de données d'intégrité et l'interopérabilité

-   [Azure Data Manager for Agriculture (préversion)](https://learn.microsoft.com/fr-fr/azure/data-manager-for-agri/)
    Créer un avenir plus durable en innovant avec les données agricoles

-   [Azure Health Data Services](https://learn.microsoft.com/fr-fr/azure/healthcare-apis/)
    Solution unifiée qui permet de protéger et combiner des données d'intégrité dans le cloud, et génère des insights de santé avec l'analytique

-   [Azure Web PubSub](https://learn.microsoft.com/fr-fr/azure/azure-web-pubsub/)
    Créer facilement des applications web de messagerie en temps réel avec des WebSockets et le modèle publication-abonnement

-   [Event Grid](https://learn.microsoft.com/fr-fr/azure/event-grid/)
    Bénéficiez d'une livraison fiable d'événement à grande échelle

-   [Gestion des API](https://learn.microsoft.com/fr-fr/azure/api-management/)
    Publiez des API en toute sécurité et à grande échelle pour les développeurs, les partenaires et les employés

-   [Logic Apps](https://learn.microsoft.com/fr-fr/azure/logic-apps/)
    Automatisez l'accès à vos données et leur utilisation dans différents clouds sans écrire de code

-   [Microsoft Azure Data Manager for Energy (préversion)](https://learn.microsoft.com/fr-fr/azure/energy-data-services/)
    Accélérer votre parcours vers la modernisation et la transformation numérique des données relatives aux énergies

-   [Service Bus](https://learn.microsoft.com/fr-fr/azure/service-bus-messaging/)
    Connectez-vous à des environnements de cloud privés et publics

### Internet des objets

-   [Azure Cosmos DB](https://learn.microsoft.com/fr-fr/azure/cosmos-db/)
    Base de données NoSQL rapide avec des API ouvertes pour toute échelle

-   [Azure Functions](https://learn.microsoft.com/fr-fr/azure/azure-functions/)
    Traitez les événements avec du code sans serveur

-   [Azure IoT](https://learn.microsoft.com/fr-fr/azure/iot/)
    Une collection de services cloud et de périphérie gérés par Microsoft qui permettent de connecter, superviser et contrôler des milliards de ressources IoT.

-   [Azure IoT Central](https://learn.microsoft.com/fr-fr/azure/iot-central/)
    Accélérer la création de solutions IoT

-   [Azure IoT Hub](https://learn.microsoft.com/fr-fr/azure/iot-hub/)
    Connectez, supervisez et gérez des milliards de ressources IoT

-   [Azure IoT Edge](https://learn.microsoft.com/fr-fr/azure/iot-edge/)
    Étendez l'intelligence cloud et l'analytique aux appareils en périphérie

-   [Azure Machine Learning](https://learn.microsoft.com/fr-fr/azure/machine-learning/)
    Proposez l'intelligence artificielle à tous avec une plateforme de bout en bout, évolutive et approuvée qui inclut l'expérimentation et la gestion des modèles

-   [Azure Maps](https://learn.microsoft.com/fr-fr/azure/azure-maps/)
    Les API de géolocalisation simples et sécurisées fournissent un contexte géospatial aux données

-   [Azure Sphere](https://learn.microsoft.com/fr-fr/azure-sphere/)
    Connectez de façon sécurisée des appareils MCU du silicone au cloud

-   [Azure SQL Edge](https://learn.microsoft.com/fr-fr/azure/azure-sql-edge/)
    Moteur de données à faible empreinte, optimisé pour la périphérie, avec IA intégré

-   [Azure Stream Analytics](https://learn.microsoft.com/fr-fr/azure/stream-analytics/)
    Analytique en temps réel sur les flux de données en déplacement rapide provenant d'applications et d'appareils

-   [Azure Time Series Insights](https://learn.microsoft.com/fr-fr/azure/time-series-insights/)
    Explorez et analysez les données de série chronologique des appareils IoT

-   [Azure Digital Twins](https://learn.microsoft.com/fr-fr/azure/digital-twins/)
    Élaborer des solutions d'intelligence spatiale IoT de nouvelle génération

-   [Event Grid](https://learn.microsoft.com/fr-fr/azure/event-grid/)
    Bénéficiez d'une livraison fiable d'événement à grande échelle

-   [Gestion des API](https://learn.microsoft.com/fr-fr/azure/api-management/)
    Publiez des API en toute sécurité et à grande échelle pour les développeurs, les partenaires et les employés

-   [Kinect DK](https://learn.microsoft.com/fr-fr/azure/kinect-dk/)
    Créez des modèles de vision par ordinateur et vocaux en utilisant un kit de développement avec des capteurs IA avancés

-   [Logic Apps](https://learn.microsoft.com/fr-fr/azure/logic-apps/)
    Automatisez l'accès à vos données et leur utilisation dans différents clouds sans écrire de code

-   [Microsoft Defender pour IoT](https://learn.microsoft.com/fr-fr/azure/defender-for-iot/)
    Gestion continue des actifs et détection des menaces pour les appareils IoT/OT managés et non managés

-   [Notification Hubs](https://learn.microsoft.com/fr-fr/azure/notification-hubs/)
    Envoyez des notifications Push vers n'importe quelle plateforme à partir d'un back end

-   [Opérations Azure IoT (préversion)](https://learn.microsoft.com/fr-fr/azure/iot-operations/)
    Déverrouiller des insights pour des actions locales intelligentes et une visibilité globale

-   [Windows 10 IoT Core Services](https://learn.microsoft.com/fr-fr/windows-hardware/manufacture/iot/iotcoreservicesoverview)
    Support à long terme du système d'exploitation et services pour gérer les mises à jour des appareils et évaluer leur intégrité

-   [Windows pour IoT](https://learn.microsoft.com/fr-fr/windows/iot/)
    Créer des solutions de périphérie intelligentes avec des outils de classe mondiale pour développeur, un support à long terme et une sécurité de niveau entreprise

### Média

-   [Azure AI Video Indexer](https://learn.microsoft.com/fr-fr/azure/azure-video-indexer/)
    Révélez les insights des vidéos

-   [Azure Front Door et Content Delivery Network (CDN)](https://learn.microsoft.com/fr-fr/azure/frontdoor/)
    Garantissez la distribution de contenu fiable et sécurisée avec une large portée générale

-   [Azure Media Player](https://learn.microsoft.com/fr-fr/azure/media-services/latest/player-media-players-concept)
    Un seul lecteur pour tous vos besoins de lecture

-   [Encodage](https://learn.microsoft.com/fr-fr/azure/media-services/latest/encode-concept)
    Encodage de type studio à l'échelle du cloud

-   [Media Services](https://learn.microsoft.com/fr-fr/azure/media-services/latest/)
    Encodez, stockez et diffusez du contenu audio et vidéo à grande échelle

-   [Protection du contenu](https://learn.microsoft.com/fr-fr/azure/media-services/latest/drm-content-protection-concept)
    Fournissez en toute sécurité des contenus à l'aide d'AES, de PlayReady, de Widevine et de Fairplay

-   [Streaming à la demande et live](https://learn.microsoft.com/fr-fr/azure/media-services/latest/stream-live-tutorial-with-api)
    Effectuez la remise du contenu sur tous les appareils à une échelle adaptée aux besoins de l'entreprise

### Migration

-   [Azure Database Migration Service](https://learn.microsoft.com/fr-fr/azure/dms/)
    Simplifiez la migration de base de données locale vers le cloud

-   [Azure Migrate](https://learn.microsoft.com/fr-fr/azure/migrate/)
    Détectez, évaluez, dimensionnez et migrez facilement vos machines virtuelles locales vers Azure

-   [Azure Site Recovery](https://learn.microsoft.com/fr-fr/azure/site-recovery/)
    Assurez le fonctionnement continu de votre entreprise avec le service de reprise d'activité après sinistre intégré

-   [Cost Management + facturation](https://learn.microsoft.com/fr-fr/azure/cost-management-billing/)
    Optimisez vos dépenses sur le cloud, tout en maximisant le potentiel du cloud

-   [Data Box](https://learn.microsoft.com/fr-fr/azure/databox/)
    Appliances et solutions pour le transfert de données vers Azure

### Mise en réseau

-   [Application Gateway](https://learn.microsoft.com/fr-fr/azure/application-gateway/)
    Créez des serveurs web frontaux sécurisés, évolutifs et à haut niveau de disponibilité dans Azure

-   [Azure Communications Gateway](https://learn.microsoft.com/fr-fr/azure/communications-gateway/)
    Connecter rapidement vos réseaux fixes et mobiles à Microsoft Teams

-   [Azure DNS](https://learn.microsoft.com/fr-fr/azure/dns/)
    Hébergez votre domaine DNS dans Azure

-   [Azure ExpressRoute](https://learn.microsoft.com/fr-fr/azure/expressroute/)
    Connexions de réseau privé dédiées par fibre optique à Azure

-   [Azure Front Door](https://learn.microsoft.com/fr-fr/azure/frontdoor/)
    Point de livraison scalable avec sécurité renforcée pour des applications web mondiales basées sur des microservices

-   [Azure Network Function Manager](https://learn.microsoft.com/fr-fr/azure/network-function-manager/)
    Étendre la gestion Azure pour le déploiement de fonctions réseau 5G et SD-WAN sur des appareils de périphérie

-   [Azure Operator Service Manager](https://learn.microsoft.com/fr-fr/azure/operator-service-manager/)
    Gérer les services réseau sur les sites cloud hybrides

-   [Azure Orbital Ground Station](https://learn.microsoft.com/fr-fr/azure/orbital/)
    Services de station terrienne et de planification pour une transmission rapide des données

-   [Azure Private Link](https://learn.microsoft.com/fr-fr/azure/private-link/)
    Accès privé aux services hébergés sur la plateforme Azure, tout en conservant vos données sur le réseau Microsoft

-   [Azure Private 5G Core](https://learn.microsoft.com/fr-fr/azure/private-5g-core/)
    Déployer et gérer rapidement des réseaux 5G privés à la périphérie de l'entreprise

-   [Équilibreur de charge](https://learn.microsoft.com/fr-fr/azure/load-balancer/)
    Fournissez une haute disponibilité et des performances réseau optimales à vos applications

-   [Pare-feu Azure](https://learn.microsoft.com/fr-fr/azure/firewall/)
    Fonctionnalités de pare-feu natives, avec une haute disponibilité intégrée, une scalabilité cloud illimitée et aucune maintenance

-   [Pare-feu d'applications web](https://learn.microsoft.com/fr-fr/azure/web-application-firewall/)
    Service de pare-feu d'applications web (WAF) cloud natif qui fournit une solide protection aux applications web

-   [Passerelle VPN](https://learn.microsoft.com/fr-fr/azure/vpn-gateway/)
    Établissez une connectivité sécurisée intersite

-   [Protection DDoS dans Azure](https://learn.microsoft.com/fr-fr/azure/ddos-protection/)
    Protéger ses applications contre les attaques DDoS (Distributed Denial of Service, déni de service distribué)

-   [Réseau virtuel](https://learn.microsoft.com/fr-fr/azure/virtual-network/)
    Mettez en service des réseaux privés et établissez une connexion à des centres de données locaux

-   [Tous les services de mise en réseau](https://learn.microsoft.com/fr-fr/azure/networking/)
    Fournissent une connectivité à vos ressources dans Azure, livrent et protègent les applications et permettent de sécuriser votre réseau.

-   [WAN virtuel](https://learn.microsoft.com/fr-fr/azure/virtual-wan/)
    Service hub-and-spoke géré par Microsoft pour la connectivité et la sécurité

### Mixed Reality

-   [Azure Remote Rendering](https://learn.microsoft.com/fr-fr/azure/remote-rendering/)
    Affichez du contenu 3D interactif de haute qualité et diffusez-le sur vos appareils en temps réel

-   [Azure Digital Twins](https://learn.microsoft.com/fr-fr/azure/digital-twins/)
    Élaborer des solutions d'intelligence spatiale IoT de nouvelle génération

-   [Kinect DK](https://learn.microsoft.com/fr-fr/azure/kinect-dk/)
    Créez des modèles de vision par ordinateur et vocaux en utilisant un kit de développement avec des capteurs IA avancés

-   [Object Anchors (préversion)](https://learn.microsoft.com/fr-fr/azure/object-anchors/)
    Alignez et ancrez automatiquement du contenu 3D à des objets du monde physique

-   [Spatial Anchors](https://learn.microsoft.com/fr-fr/azure/spatial-anchors/)
    Créer des expériences de réalité mixte multi-utilisateurs sensibles à l'espace

### Mobile

-   [App Configuration](https://learn.microsoft.com/fr-fr/azure/azure-app-configuration/)
    Stockage de paramètres rapide et évolutif pour la configuration d'application

-   [App Service](https://learn.microsoft.com/fr-fr/azure/app-service/)
    Créez rapidement des applications cloud performantes pour le web et les appareils mobiles

-   [Azure AI services](https://learn.microsoft.com/fr-fr/azure/ai-services/)
    Créez des applications de pointe, prêtes à être commercialisées, et responsables pour vos organisations avec l'IA

-   [Azure Communication Services](https://learn.microsoft.com/fr-fr/azure/communication-services/overview)
    Créez des expériences de communication enrichies à l'aide de la même plateforme sécurisée que celle utilisée par Microsoft Teams

-   [Azure Maps](https://learn.microsoft.com/fr-fr/azure/azure-maps/)
    Les API de géolocalisation simples et sécurisées fournissent un contexte géospatial aux données

-   [Gestion des API](https://learn.microsoft.com/fr-fr/azure/api-management/)
    Publiez des API en toute sécurité et à grande échelle pour les développeurs, les partenaires et les employés

-   [Notification Hubs](https://learn.microsoft.com/fr-fr/azure/notification-hubs/)
    Envoyez des notifications Push vers n'importe quelle plateforme à partir d'un back end

-   [Recherche Azure AI](https://learn.microsoft.com/fr-fr/azure/search/)
    Service de recherche cloud alimenté par l'IA pour développer des applications mobiles et web

-   [Spatial Anchors](https://learn.microsoft.com/fr-fr/azure/spatial-anchors/)
    Créer des expériences de réalité mixte multi-utilisateurs sensibles à l'espace

-   [Visual Studio App Center](https://learn.microsoft.com/fr-fr/appcenter/)
    Créez, testez, publiez et supervisez en continu vos applications mobiles et de bureau

-   [Xamarin](https://learn.microsoft.com/fr-fr/xamarin/)
    Créez des applications mobiles cloud plus rapidement

### Outils de développement

-   [App Configuration](https://learn.microsoft.com/fr-fr/azure/azure-app-configuration/)
    Stockage de paramètres rapide et évolutif pour la configuration d'application

-   [Azure Data Studio](https://learn.microsoft.com/fr-fr/azure-data-studio/)
    Éditeur léger capable d'exécuter des requêtes de pool SQL serverless et d'afficher et d'enregistrer les résultats au format texte, JSON ou Excel.

-   [Azure DevOps](https://learn.microsoft.com/fr-fr/azure/devops/)
    Services permettant aux équipes de partager du code, de suivre des tâches et de livrer des logiciels

-   [Azure DevTest Labs](https://learn.microsoft.com/fr-fr/azure/devtest-labs/)
    Créez rapidement des environnements avec des modèles et des artefacts réutilisables

-   [Azure Lab Services](https://learn.microsoft.com/fr-fr/azure/lab-services/)
    Configurez des labos pour des salles de classe, des épreuves, du développement et des tests, et autres scénarios

-   [Azure Pipelines](https://learn.microsoft.com/fr-fr/azure/devops/pipelines/)
    Créez, testez et déployez en continu sur la plateforme et le cloud de votre choix

-   [GitHub Actions pour Azure](https://learn.microsoft.com/fr-fr/azure/developer/github/github-actions)
    Créer, tester et déployer une application de GitHub sur Azure

-   [Microsoft Dev Box](https://learn.microsoft.com/fr-fr/azure/dev-box/)
    Simplifier le développement avec des stations de travail prêtes à l'emploi sécurisées dans le cloud

-   [Microsoft Playwright Testing (préversion)](https://learn.microsoft.com/fr-fr/azure/playwright-testing/)
    Exécuter des tests Playwright à grande échelle

-   [Visual Studio](https://learn.microsoft.com/fr-fr/visualstudio/windows)
    Environnement puissant et flexible pour développer des applications dans le cloud

-   [Visual Studio Code](https://code.visualstudio.com/docs)
    Éditeur de code léger et performant pour le développement cloud

### Sécurité

-   [App Configuration](https://learn.microsoft.com/fr-fr/azure/azure-app-configuration/)
    Stockage de paramètres rapide et évolutif pour la configuration d'application

-   [Application Gateway](https://learn.microsoft.com/fr-fr/azure/application-gateway/)
    Créez des serveurs web frontaux sécurisés, évolutifs et à haut niveau de disponibilité dans Azure

-   [Azure Front Door](https://learn.microsoft.com/fr-fr/azure/frontdoor/)
    Point de livraison scalable avec sécurité renforcée pour des applications web mondiales basées sur des microservices

-   [Azure Information Protection](https://learn.microsoft.com/fr-fr/azure/information-protection/)
    Améliorez la protection de vos informations sensibles à tout moment et en tout lieu

-   [Key Vault](https://learn.microsoft.com/fr-fr/azure/key-vault/)
    Protégez les clés et autres secrets et gardez-en le contrôle

-   [Microsoft Defender pour IoT](https://learn.microsoft.com/fr-fr/azure/defender-for-iot/)
    Gestion continue des actifs et détection des menaces pour les appareils IoT/OT managés et non managés

-   [Microsoft Defender pour la gestion des surfaces d'attaque externe](https://learn.microsoft.com/fr-fr/azure/external-attack-surface-management/overview)
    Protéger l'expérience numérique en découvrant toutes les ressources exposées sur Internet

-   [Microsoft Defender pour le cloud](https://learn.microsoft.com/fr-fr/azure/defender-for-cloud/)
    Gestion de la posture de sécurité et protection avancée contre les menaces sur des charges de travail Azure, hybrides et multiclouds

-   [Microsoft Entra ID](https://learn.microsoft.com/fr-fr/entra/identity/)
    Synchronisez les répertoires locaux et activez l'authentification unique

-   [Microsoft Sentinel](https://learn.microsoft.com/fr-fr/azure/sentinel/)
    Mettez au travail l'analytique de sécurité intelligente et SIEM cloud-native pour contribuer à la protection de votre entreprise

-   [Module de sécurité matériel (HSM) dédié Azure](https://learn.microsoft.com/fr-fr/azure/dedicated-hsm/)
    Gérez les modules de sécurité matériels que vous utilisez dans le cloud

-   [NAT Gateway](https://learn.microsoft.com/fr-fr/azure/nat-gateway/)
    Fournir une connectivité sortante à l\'Internet hautement fiable, sécurisée et évolutive

-   [Pare-feu Azure](https://learn.microsoft.com/fr-fr/azure/firewall/)
    Fonctionnalités de pare-feu natives, avec une haute disponibilité intégrée, une scalabilité cloud illimitée et aucune maintenance

-   [Pare-feu d'applications web](https://learn.microsoft.com/fr-fr/azure/web-application-firewall/)
    Service de pare-feu d'applications web (WAF) cloud natif qui fournit une solide protection aux applications web

-   [Passerelle VPN](https://learn.microsoft.com/fr-fr/azure/vpn-gateway/)
    Établissez une connectivité sécurisée intersite

-   [Protection DDoS dans Azure](https://learn.microsoft.com/fr-fr/azure/ddos-protection/)
    Protéger ses applications contre les attaques DDoS (Distributed Denial of Service, déni de service distribué)

-   [Registre confidentiel Azure](https://learn.microsoft.com/fr-fr/azure/confidential-ledger/)
    Un magasin de données non structuré et infalsifiable hébergé dans des environnements d'exécution de confiance et étayé par une preuve cryptographique vérifiable

-   [Services de domaine Microsoft Entra](https://learn.microsoft.com/fr-fr/entra/identity/domain-services/)
    Joignez des machines virtuelles Azure à un domaine sans contrôleur de domaine

### Stockage

-   [Avere vFXT pour Azure](https://learn.microsoft.com/fr-fr/azure/avere-vfxt/)
    Exécutez des charges de travail haute performance basées sur des fichiers dans le cloud

-   [Azure Data Lake Storage](https://learn.microsoft.com/fr-fr/azure/storage/blobs/data-lake-storage-introduction)
    Fonctionnalité de lac de données sécurisée et extrêmement scalable qui repose sur le Stockage Blob Azure

-   [Azure Data Share](https://learn.microsoft.com/fr-fr/azure/data-share/)
    Service simple et sûr pour le partage de Big Data avec des organisations externes

-   [Azure Elastic SAN](https://learn.microsoft.com/fr-fr/azure/storage/elastic-san/)
    Elastic SAN est un service natif cloud de réseau de zone de stockage (SAN) basé sur Azure. Bénéficiez d'un accès à une expérience de bout en bout comme votre réseau SAN local.

-   [Azure Files](https://learn.microsoft.com/fr-fr/azure/storage/files/)
    Partages de fichiers cloud simples, sécurisés et serverless de niveau entreprise

-   [Azure FXT Edge Filer](https://learn.microsoft.com/fr-fr/azure/fxt-edge-filer/)
    Solution d'optimisation du stockage hybride pour les environnements HPC

-   [Azure HPC Cache](https://learn.microsoft.com/fr-fr/azure/hpc-cache/)
    Mise en cache de fichiers pour le calcul haute performance (HPC)

-   [Azure Managed Lustre](https://learn.microsoft.com/fr-fr/azure/azure-managed-lustre/)
    Un système de fichiers parallèle basé sur le cloud complètement managé qui permet aux clients d'exécuter leurs charges de travail de calcul haute performance dans le cloud

-   [Azure NetApp Files](https://learn.microsoft.com/fr-fr/azure/azure-netapp-files/)
    Partages de fichiers Azure de classe Entreprise, basés sur NetApp

-   [Data Box](https://learn.microsoft.com/fr-fr/azure/databox/)
    Appliances et solutions pour le transfert de données vers Azure

-   [Explorateur Stockage](https://learn.microsoft.com/fr-fr/azure/vs-azure-tools-storage-manage-with-storage-explorer)
    Consultez et utilisez les ressources Stockage Azure

-   [Registre confidentiel Azure](https://learn.microsoft.com/fr-fr/azure/confidential-ledger/)
    Un magasin de données non structuré et infalsifiable hébergé dans des environnements d'exécution de confiance et étayé par une preuve cryptographique vérifiable

-   [Sauvegarde Azure](https://learn.microsoft.com/fr-fr/azure/backup/)
    Simplifiez la protection des données et protégez-vous contre le ransomware

-   [Stockage](https://learn.microsoft.com/fr-fr/azure/storage/)
    Stockage dans le cloud durable, hautement disponible et considérablement évolutif

-   [Stockage archive](https://learn.microsoft.com/fr-fr/azure/storage/blobs/access-tiers-overview)
    Prix leader du secteur pour le stockage des données auxquelles vous accédez rarement

-   [Stockage Blob](https://learn.microsoft.com/fr-fr/azure/storage/blobs/)
    Stockage d'objets basé sur REST pour les données non structurées

-   [Stockage de conteneur Azure](https://learn.microsoft.com/fr-fr/azure/storage/container-storage/)
    Gérer des volumes persistants pour des applications de conteneur avec état

-   [Stockage File d'attente](https://learn.microsoft.com/fr-fr/azure/storage/queues/)
    Faire évoluer vos applications en fonction du trafic

-   [Stockage sur disque](https://learn.microsoft.com/fr-fr/azure/virtual-machines/managed-disks-overview)
    Stockage de blocs à haute durabilité et à hautes performances pour Machines virtuelles Azure

-   [StorSimple](https://learn.microsoft.com/fr-fr/azure/storsimple/)
    Réduction des coûts avec une solution de stockage cloud hybride de classe Entreprise

### Web

-   [API Apps](https://learn.microsoft.com/fr-fr/azure/app-service/)
    Générez et utilisez facilement des API de cloud

-   [App Configuration](https://learn.microsoft.com/fr-fr/azure/azure-app-configuration/)
    Stockage de paramètres rapide et évolutif pour la configuration d'application

-   [App Service](https://learn.microsoft.com/fr-fr/azure/app-service/)
    Créez rapidement des applications cloud performantes pour le web et les appareils mobiles

-   [Azure Communication Services](https://learn.microsoft.com/fr-fr/azure/communication-services/overview)
    Créez des expériences de communication enrichies à l'aide de la même plateforme sécurisée que celle utilisée par Microsoft Teams

-   [Azure Front Door et Content Delivery Network (CDN)](https://learn.microsoft.com/fr-fr/azure/frontdoor/)
    Garantissez la distribution de contenu fiable et sécurisée avec une large portée générale

-   [Azure Functions](https://learn.microsoft.com/fr-fr/azure/azure-functions/)
    Traitez les événements avec du code sans serveur

-   [Azure Maps](https://learn.microsoft.com/fr-fr/azure/azure-maps/)
    Les API de géolocalisation simples et sécurisées fournissent un contexte géospatial aux données

-   [Azure Spring Apps](https://learn.microsoft.com/fr-fr/azure/spring-apps/)
    Service Spring Cloud complètement managé, créé et exploité avec Pivotal

-   [Azure Web PubSub](https://learn.microsoft.com/fr-fr/azure/azure-web-pubsub/)
    Créer facilement des applications web de messagerie en temps réel avec des WebSockets et le modèle publication-abonnement

-   [Gestion des API](https://learn.microsoft.com/fr-fr/azure/api-management/)
    Publiez des API en toute sécurité et à grande échelle pour les développeurs, les partenaires et les employés

-   [Microsoft Playwright Testing (préversion)](https://learn.microsoft.com/fr-fr/azure/playwright-testing/)
    Exécuter des tests Playwright à grande échelle

-   [Notification Hubs](https://learn.microsoft.com/fr-fr/azure/notification-hubs/)
    Envoyez des notifications Push vers n'importe quelle plateforme à partir d'un back end

-   [Recherche Azure AI](https://learn.microsoft.com/fr-fr/azure/search/)
    Service de recherche cloud alimenté par l'IA pour développer des applications mobiles et web

-   [Relais Azure Fluid](https://learn.microsoft.com/fr-fr/azure/azure-fluid-relay/)
    Ajouter facilement des expériences collaboratives en temps réel à vos applications avec Infrastructure Fluid

-   [Service Azure SignalR](https://learn.microsoft.com/fr-fr/azure/azure-signalr/)
    Ajouter facilement des fonctionnalités web en temps réel

-   [Static Web Apps](https://learn.microsoft.com/fr-fr/azure/static-web-apps/)
    Un service d'application web moderne qui offre un développement full-stack fluide, du code source à la haute disponibilité mondiale

-   [Web App pour conteneurs](https://learn.microsoft.com/fr-fr/azure/app-service/)
    Déployer et exécuter facilement des applications web en conteneur qui évoluent avec votre entreprise

-   [Web Apps](https://learn.microsoft.com/fr-fr/azure/app-service/)
    Créez et déployez rapidement des applications web stratégiques à grande échelle

[](https://learn.microsoft.com/fr-fr/azure/?product=popular#langages-et-outils)

## Langages et outils

[Python](https://learn.microsoft.com/fr-fr/azure/developer/python/)

[.NET](https://learn.microsoft.com/fr-fr/dotnet/azure/)

[JavaScript](https://learn.microsoft.com/fr-fr/azure/developer/javascript/)

[Java](https://learn.microsoft.com/fr-fr/azure/developer/java/)

[Go](https://learn.microsoft.com/fr-fr/azure/developer/go/)

[API REST](https://learn.microsoft.com/fr-fr/rest/api/)

[Azure PowerShell](https://learn.microsoft.com/fr-fr/powershell/azure/)

[Azure CLI](https://learn.microsoft.com/fr-fr/cli/azure/)

[Modèles ARM](https://learn.microsoft.com/fr-fr/azure/azure-resource-manager/templates/)

[Bicep](https://learn.microsoft.com/fr-fr/azure/azure-resource-manager/bicep/)

[Jenkins](https://learn.microsoft.com/fr-fr/azure/developer/jenkins)

[Terraform](https://learn.microsoft.com/fr-fr/azure/developer/terraform/)

[](https://learn.microsoft.com/fr-fr/azure/?product=popular#clouds-azure)

## Clouds Azure

[Azure Government](https://learn.microsoft.com/fr-fr/azure/azure-government/)

Cloud dédié aux administrations américaines et leurs partenaires.

[Microsoft Azure géré par 21Vianet](https://learn.microsoft.com/fr-fr/azure/china/)

Cloud dédié situé en Chine et géré par 21Vianet.

[](https://learn.microsoft.com/fr-fr/azure/?product=popular#solutions-de-partenaires)

## Solutions de partenaires

[Azure Native ISV Services](https://learn.microsoft.com/fr-fr/azure/partner-solutions/)

Solutions de partenaires intégrés que vous pouvez utiliser dans Azure pour améliorer votre infrastructure cloud.

[Place de marché commerciale](https://learn.microsoft.com/fr-fr/azure/marketplace/)

Une place de marché en ligne d'applications et de services de partenaires ISV (Independent Software Vendor).