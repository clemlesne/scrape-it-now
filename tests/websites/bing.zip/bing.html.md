Microsoft and our third-party vendors use cookies and similar technologies to deliver, maintain, and improve our services and ads. If you agree, we will use this data for ads personalization and associated analytics.

You can select 'Accept' to consent to these uses, 'Reject' to decline these uses or click on 'More options' to review your options. You can change your selection under 'Manage Cookie Preferences' at the bottom of this page.  [Privacy Statement](https://go.microsoft.com/fwlink/?LinkId=521839)

[Accept](javascript:%20void(0))

[Reject](javascript:%20void(0))

[More options](javascript:%20void(0))

Manage Cookie Preferences

We also use essential cookies, these cannot be turned off

Analytics:

We may allow third parties to use analytics cookies to understand how you use our websites so we can make them better and the third parties can develop and improve their products, which they may use on websites that are not owned or operated by Microsoft.

Off

Social Media:

We may use social media cookies to show you content based on your social media profiles and activity on our websites. They're used to connect your activity on our websites to your social media profiles so the content you see on our websites and on social media will better reflect your interests.

Off

Advertising:

Enable the use of cookies for making advertising more relevant and to support the sourcing of high-quality content on this site.  If you don't allow this use, then ads shown to you may be less relevant.

Off

Save Settings

[](https://www.bing.com/search?q=Cl%C3%A9mence&FORM=ANNTA1#)

Skip to content

[](https://www.bing.com/ck/a?!&&p=dfd9864c348895b2199e240c64f24edccc1df3728e6808792539cb52b8155403JmltdHM9MTcyOTk4NzIwMA&ptn=3&ver=2&hsh=4&fclid=18c53c15-7230-6a11-3207-2930735e6bf0&u=a1Lz9GT1JNPVo5RkQx&ntb=1)

# 

[](javascript:void(0))

InPrivate

[](https://www.bing.com/search?q=Cl%C3%A9mence&shm=cr&form=DEEPSH)

Deep search

[Français](https://www.bing.com/search?q=Cl%c3%a9mence&FORM=ANNTA1&setlang=fr&sid=06177798D86468822FAD62BDD90A695D)[](javascript:void(0))

-   [Search](https://www.bing.com/ck/a?!&&p=312b058f4975604a83fcc16de0819edfcacbf31a4ff6c9b3368b3eb23510d52eJmltdHM9MTcyOTk4NzIwMA&ptn=3&ver=2&hsh=4&fclid=18c53c15-7230-6a11-3207-2930735e6bf0&u=a1Lz9zY29wZT13ZWImRk9STT1IRFJTQzE&ntb=1)

-   [Copilot](https://www.bing.com/ck/a?!&&p=042459030c878c1bbf1b0920eb5dec17fa9a38cca1033992f9fbd966fe9924acJmltdHM9MTcyOTk4NzIwMA&ptn=3&ver=2&hsh=4&fclid=18c53c15-7230-6a11-3207-2930735e6bf0&u=a1L2NoYXQ_cT1DbCVjMyVhOW1lbmNlJnNlbmRxdWVyeT0xJkZPUk09U0NDT0RY&ntb=1)

-   [Images](https://www.bing.com/ck/a?!&&p=46972e44861109167796fac103030c28425da1884fa2ddad10c9d67b081d68faJmltdHM9MTcyOTk4NzIwMA&ptn=3&ver=2&hsh=4&fclid=18c53c15-7230-6a11-3207-2930735e6bf0&u=a1L2ltYWdlcy9zZWFyY2g_cT1DbCVjMyVhOW1lbmNlJkZPUk09SERSU0Mz&ntb=1)

-   [Videos](https://www.bing.com/ck/a?!&&p=daa49e1761e5b2a75c3e7b0e298b32acf5f0a759b42136a7c9da6c4c3059ef80JmltdHM9MTcyOTk4NzIwMA&ptn=3&ver=2&hsh=4&fclid=18c53c15-7230-6a11-3207-2930735e6bf0&u=a1L3ZpZGVvcy9zZWFyY2g_cT1DbCVjMyVhOW1lbmNlJkZPUk09SERSU0M0&ntb=1)

-   [Maps](https://www.bing.com/ck/a?!&&p=7d9040d5e31123df2c6979a73dd02e4e8b477c0c0e0aba1f5e318dc272d787aeJmltdHM9MTcyOTk4NzIwMA&ptn=3&ver=2&hsh=4&fclid=18c53c15-7230-6a11-3207-2930735e6bf0&u=a1L21hcHM_cT1DbCVjMyVhOW1lbmNlJkZPUk09SERSU0M2&ntb=1)

-   [News](https://www.bing.com/ck/a?!&&p=33a2c98c3d1e94b68f51cfe89782c0d5b4c0ce59f7204627b0543ed2a24b4cc6JmltdHM9MTcyOTk4NzIwMA&ptn=3&ver=2&hsh=4&fclid=18c53c15-7230-6a11-3207-2930735e6bf0&u=a1L25ld3Mvc2VhcmNoP3E9Q2wlYzMlYTltZW5jZSZGT1JNPUhEUlNDNw&ntb=1)

-   [Shopping](https://www.bing.com/ck/a?!&&p=62c0265bef50f8e810c9a0e0812d8df75d43c34b2153ed046ec996b40b808b81JmltdHM9MTcyOTk4NzIwMA&ptn=3&ver=2&hsh=4&fclid=18c53c15-7230-6a11-3207-2930735e6bf0&u=a1L3Nob3A_cT1DbCVjMyVhOW1lbmNlJkZPUk09U0hPUFRC&ntb=1)

    -   [Flights](https://www.bing.com/ck/a?!&&p=f8ba2a7a4e9139327953286eae09f9fb4950b7d0d87b24b0fec48e03c8dbf532JmltdHM9MTcyOTk4NzIwMA&ptn=3&ver=2&hsh=4&fclid=18c53c15-7230-6a11-3207-2930735e6bf0&u=a1L3RyYXZlbC9zZWFyY2g_cT1DbCVjMyVhOW1lbmNlJm09ZmxpZ2h0cyZGT1JNPUZCU0NPUA&ntb=1)
    -   [Travel](https://www.bing.com/ck/a?!&&p=9d9e2ddb50bea741905c27d288c299d1027821cd2eb3bde848a8590e3f8e524dJmltdHM9MTcyOTk4NzIwMA&ptn=3&ver=2&hsh=4&fclid=18c53c15-7230-6a11-3207-2930735e6bf0&u=a1L3RyYXZlbC9zZWFyY2g_cT1DbCVjMyVhOW1lbmNlJm09dHJhdmVsJkZPUk09VEhTQ09Q&ntb=1)
    -   [Hotels](https://www.bing.com/ck/a?!&&p=68ef063203b281b362db9790fd013d9466d6acd80b2e1693a66dfa45aa4c87b5JmltdHM9MTcyOTk4NzIwMA&ptn=3&ver=2&hsh=4&fclid=18c53c15-7230-6a11-3207-2930735e6bf0&u=a1L3RyYXZlbC9zZWFyY2g_cT1DbCVjMyVhOW1lbmNlJm09aG90ZWxzJkZPUk09SFRTQ09Q&ntb=1)
    -   [Real Estate](https://www.bing.com/ck/a?!&&p=7128eb2f74d08aa7983850db59e2819a0b110cca9b571080942a54d5c9d9a526JmltdHM9MTcyOTk4NzIwMA&ptn=3&ver=2&hsh=4&fclid=18c53c15-7230-6a11-3207-2930735e6bf0&u=a1L2hvbWVzP0ZPUk09MDAwMDYw&ntb=1)

-   [About search results![About search results]()](https://www.bing.com/ck/a?!&&p=88cce2980741344cef55fee9eb5fde68b7bfd144736caaff0787cb5742c830a7JmltdHM9MTcyOTk4NzIwMA&ptn=3&ver=2&hsh=4&fclid=18c53c15-7230-6a11-3207-2930735e6bf0&psq=Cl%c3%a9mence&u=a1aHR0cHM6Ly9oZWxwLmJpbmcubWljcm9zb2Z0LmNvbS8jYXBleC8xOC9mci8xMDAyMC8tMQ&ntb=1)

    ✕
    [Results ranked by relevance · Learn more](https://www.bing.com/ck/a?!&&p=88cce2980741344cef55fee9eb5fde68b7bfd144736caaff0787cb5742c830a7JmltdHM9MTcyOTk4NzIwMA&ptn=3&ver=2&hsh=4&fclid=18c53c15-7230-6a11-3207-2930735e6bf0&psq=Cl%c3%a9mence&u=a1aHR0cHM6Ly9oZWxwLmJpbmcubWljcm9zb2Z0LmNvbS8jYXBleC8xOC9mci8xMDAyMC8tMQ&ntb=1)

-   [Tools](javascript:void(0))

About 180,000 results

[Date](javascript:)

[All](https://www.bing.com/search?q=Cl%c3%a9mence&FORM=000017&qpvt=Cl%c3%a9mence)[Past 24 hours](https://www.bing.com/search?q=Cl%c3%a9mence&filters=ex1%3a%22ez1%22&FORM=000017&qpvt=Cl%c3%a9mence)[Past week](https://www.bing.com/search?q=Cl%c3%a9mence&filters=ex1%3a%22ez2%22&FORM=000017&qpvt=Cl%c3%a9mence)[Past month](https://www.bing.com/search?q=Cl%c3%a9mence&filters=ex1%3a%22ez3%22&FORM=000017&qpvt=Cl%c3%a9mence)[Past year](https://www.bing.com/search?q=Cl%c3%a9mence&filters=ex1%3a%22ez5_19658_20023%22&FORM=000017)

Open links in new tab

1.  [](https://www.bing.com/ck/a?!&&p=5314b5ce11dd6452cb4cb1afaaeb330fd32294c5bdca727ef1214fcd605a140dJmltdHM9MTcyOTk4NzIwMA&ptn=3&ver=2&hsh=4&fclid=18c53c15-7230-6a11-3207-2930735e6bf0&psq=Cl%c3%a9mence&u=a1aHR0cHM6Ly93d3cuam91cm5hbGRlc2ZlbW1lcy5mci9wcmVub21zL2NsZW1lbmNlL3ByZW5vbS0xNTA&ntb=1)
    ![Global web icon]()

    [](https://www.bing.com/ck/a?!&&p=5314b5ce11dd6452cb4cb1afaaeb330fd32294c5bdca727ef1214fcd605a140dJmltdHM9MTcyOTk4NzIwMA&ptn=3&ver=2&hsh=4&fclid=18c53c15-7230-6a11-3207-2930735e6bf0&psq=Cl%c3%a9mence&u=a1aHR0cHM6Ly93d3cuam91cm5hbGRlc2ZlbW1lcy5mci9wcmVub21zL2NsZW1lbmNlL3ByZW5vbS0xNTA&ntb=1)
    Journal des Femmes

    [](https://www.bing.com/ck/a?!&&p=5314b5ce11dd6452cb4cb1afaaeb330fd32294c5bdca727ef1214fcd605a140dJmltdHM9MTcyOTk4NzIwMA&ptn=3&ver=2&hsh=4&fclid=18c53c15-7230-6a11-3207-2930735e6bf0&psq=Cl%c3%a9mence&u=a1aHR0cHM6Ly93d3cuam91cm5hbGRlc2ZlbW1lcy5mci9wcmVub21zL2NsZW1lbmNlL3ByZW5vbS0xNTA&ntb=1)
    [https://www.journaldesfemmes.fr › prenoms › clemence](https://www.bing.com/ck/a?!&&p=5314b5ce11dd6452cb4cb1afaaeb330fd32294c5bdca727ef1214fcd605a140dJmltdHM9MTcyOTk4NzIwMA&ptn=3&ver=2&hsh=4&fclid=18c53c15-7230-6a11-3207-2930735e6bf0&psq=Cl%c3%a9mence&u=a1aHR0cHM6Ly93d3cuam91cm5hbGRlc2ZlbW1lcy5mci9wcmVub21zL2NsZW1lbmNlL3ByZW5vbS0xNTA&ntb=1)[](https://www.bing.com/search?q=Cl%C3%A9mence&FORM=ANNTA1#)

    ## [Prénom Clémence (fille) : signification, origine, sainte, avis](https://www.bing.com/ck/a?!&&p=5314b5ce11dd6452cb4cb1afaaeb330fd32294c5bdca727ef1214fcd605a140dJmltdHM9MTcyOTk4NzIwMA&ptn=3&ver=2&hsh=4&fclid=18c53c15-7230-6a11-3207-2930735e6bf0&psq=Cl%c3%a9mence&u=a1aHR0cHM6Ly93d3cuam91cm5hbGRlc2ZlbW1lcy5mci9wcmVub21zL2NsZW1lbmNlL3ByZW5vbS0xNTA&ntb=1)

    Clémence est un prénom féminin d\'origine latine qui signifie \"douceur\" ou \"bon\". Découvrez sa signification, son histoire, sa fête, son caractère, ses variantes, sa popularité et les avis des ...

    [](https://www.bing.com/ck/a?!&&p=5314b5ce11dd6452cb4cb1afaaeb330fd32294c5bdca727ef1214fcd605a140dJmltdHM9MTcyOTk4NzIwMA&ptn=3&ver=2&hsh=4&fclid=18c53c15-7230-6a11-3207-2930735e6bf0&psq=Cl%c3%a9mence&u=a1aHR0cHM6Ly93d3cuam91cm5hbGRlc2ZlbW1lcy5mci9wcmVub21zL2NsZW1lbmNlL3ByZW5vbS0xNTA&ntb=1)
    Quelle est l\'origine du prénom Clémence ?

    Le prénom Clémence est un dérivé du prénom latin Clementia.

    [](https://www.bing.com/ck/a?!&&p=5314b5ce11dd6452cb4cb1afaaeb330fd32294c5bdca727ef1214fcd605a140dJmltdHM9MTcyOTk4NzIwMA&ptn=3&ver=2&hsh=4&fclid=18c53c15-7230-6a11-3207-2930735e6bf0&psq=Cl%c3%a9mence&u=a1aHR0cHM6Ly93d3cuam91cm5hbGRlc2ZlbW1lcy5mci9wcmVub21zL2NsZW1lbmNlL3ByZW5vbS0xNTA&ntb=1)
    Quelle est la signification du prénom Clémence ?

    Le prénom Clémence provient du mot latin clementia qui signifie \"douceur\" ou \"opale\" et de clemens qui veut dire \"bon\" ou \"indulgent\".

    [](https://www.bing.com/ck/a?!&&p=5314b5ce11dd6452cb4cb1afaaeb330fd32294c5bdca727ef1214fcd605a140dJmltdHM9MTcyOTk4NzIwMA&ptn=3&ver=2&hsh=4&fclid=18c53c15-7230-6a11-3207-2930735e6bf0&psq=Cl%c3%a9mence&u=a1aHR0cHM6Ly93d3cuam91cm5hbGRlc2ZlbW1lcy5mci9wcmVub21zL2NsZW1lbmNlL3ByZW5vbS0xNTA&ntb=1)
    Quel est le caractère des Clémence ?

    Clémence est d\'un calme et d\'une zénitude à toutes épreuves ! Il vous sera impossible de la faire sortir de ses gonds. De plus, elle déteste les co\...

    [](https://www.bing.com/ck/a?!&&p=5314b5ce11dd6452cb4cb1afaaeb330fd32294c5bdca727ef1214fcd605a140dJmltdHM9MTcyOTk4NzIwMA&ptn=3&ver=2&hsh=4&fclid=18c53c15-7230-6a11-3207-2930735e6bf0&psq=Cl%c3%a9mence&u=a1aHR0cHM6Ly93d3cuam91cm5hbGRlc2ZlbW1lcy5mci9wcmVub21zL2NsZW1lbmNlL3ByZW5vbS0xNTA&ntb=1)
    Tags:

    Clémence

    Clementia of Aquitaine

     

2.  [](https://www.bing.com/ck/a?!&&p=08e98422fa73a7179c6276788c45e5e1b9fc69ce7e7f363f279b342e2080bba0JmltdHM9MTcyOTk4NzIwMA&ptn=3&ver=2&hsh=4&fclid=18c53c15-7230-6a11-3207-2930735e6bf0&psq=Cl%c3%a9mence&u=a1aHR0cHM6Ly93d3cubGFyb3Vzc2UuZnIvZGljdGlvbm5haXJlcy9mcmFuY2Fpcy9jbCVjMyVhOW1lbmNlLzE2NDgx&ntb=1)
    ![Global web icon]()

    [](https://www.bing.com/ck/a?!&&p=08e98422fa73a7179c6276788c45e5e1b9fc69ce7e7f363f279b342e2080bba0JmltdHM9MTcyOTk4NzIwMA&ptn=3&ver=2&hsh=4&fclid=18c53c15-7230-6a11-3207-2930735e6bf0&psq=Cl%c3%a9mence&u=a1aHR0cHM6Ly93d3cubGFyb3Vzc2UuZnIvZGljdGlvbm5haXJlcy9mcmFuY2Fpcy9jbCVjMyVhOW1lbmNlLzE2NDgx&ntb=1)
    Larousse

    [](https://www.bing.com/ck/a?!&&p=08e98422fa73a7179c6276788c45e5e1b9fc69ce7e7f363f279b342e2080bba0JmltdHM9MTcyOTk4NzIwMA&ptn=3&ver=2&hsh=4&fclid=18c53c15-7230-6a11-3207-2930735e6bf0&psq=Cl%c3%a9mence&u=a1aHR0cHM6Ly93d3cubGFyb3Vzc2UuZnIvZGljdGlvbm5haXJlcy9mcmFuY2Fpcy9jbCVjMyVhOW1lbmNlLzE2NDgx&ntb=1)
    [https://www.larousse.fr › dictionnaires › francais › clémence](https://www.bing.com/ck/a?!&&p=08e98422fa73a7179c6276788c45e5e1b9fc69ce7e7f363f279b342e2080bba0JmltdHM9MTcyOTk4NzIwMA&ptn=3&ver=2&hsh=4&fclid=18c53c15-7230-6a11-3207-2930735e6bf0&psq=Cl%c3%a9mence&u=a1aHR0cHM6Ly93d3cubGFyb3Vzc2UuZnIvZGljdGlvbm5haXJlcy9mcmFuY2Fpcy9jbCVjMyVhOW1lbmNlLzE2NDgx&ntb=1)[](https://www.bing.com/search?q=Cl%C3%A9mence&FORM=ANNTA1#)

    ## [Définitions : clémence - Dictionnaire de français Larousse](https://www.bing.com/ck/a?!&&p=08e98422fa73a7179c6276788c45e5e1b9fc69ce7e7f363f279b342e2080bba0JmltdHM9MTcyOTk4NzIwMA&ptn=3&ver=2&hsh=4&fclid=18c53c15-7230-6a11-3207-2930735e6bf0&psq=Cl%c3%a9mence&u=a1aHR0cHM6Ly93d3cubGFyb3Vzc2UuZnIvZGljdGlvbm5haXJlcy9mcmFuY2Fpcy9jbCVjMyVhOW1lbmNlLzE2NDgx&ntb=1)

    Douceur favorable du climat : La clémence de la température. Synonyme : douceur. Contraires : âpreté - rigueur - rudesse

3.  [](https://www.bing.com/ck/a?!&&p=cdf9f97b0fb1bb0e58668f1f2183b17582d520335624ccc47c3639ed7f26cf3aJmltdHM9MTcyOTk4NzIwMA&ptn=3&ver=2&hsh=4&fclid=18c53c15-7230-6a11-3207-2930735e6bf0&psq=Cl%c3%a9mence&u=a1aHR0cHM6Ly93d3cucGFyZW50cy5mci9wcmVub21zL2NsZW1lbmNlLTM3OTcz&ntb=1)
    ![Global web icon]()

    [](https://www.bing.com/ck/a?!&&p=cdf9f97b0fb1bb0e58668f1f2183b17582d520335624ccc47c3639ed7f26cf3aJmltdHM9MTcyOTk4NzIwMA&ptn=3&ver=2&hsh=4&fclid=18c53c15-7230-6a11-3207-2930735e6bf0&psq=Cl%c3%a9mence&u=a1aHR0cHM6Ly93d3cucGFyZW50cy5mci9wcmVub21zL2NsZW1lbmNlLTM3OTcz&ntb=1)
    PARENTS.fr

    [](https://www.bing.com/ck/a?!&&p=cdf9f97b0fb1bb0e58668f1f2183b17582d520335624ccc47c3639ed7f26cf3aJmltdHM9MTcyOTk4NzIwMA&ptn=3&ver=2&hsh=4&fclid=18c53c15-7230-6a11-3207-2930735e6bf0&psq=Cl%c3%a9mence&u=a1aHR0cHM6Ly93d3cucGFyZW50cy5mci9wcmVub21zL2NsZW1lbmNlLTM3OTcz&ntb=1)
    [https://www.parents.fr › prenoms](https://www.bing.com/ck/a?!&&p=cdf9f97b0fb1bb0e58668f1f2183b17582d520335624ccc47c3639ed7f26cf3aJmltdHM9MTcyOTk4NzIwMA&ptn=3&ver=2&hsh=4&fclid=18c53c15-7230-6a11-3207-2930735e6bf0&psq=Cl%c3%a9mence&u=a1aHR0cHM6Ly93d3cucGFyZW50cy5mci9wcmVub21zL2NsZW1lbmNlLTM3OTcz&ntb=1)[](https://www.bing.com/search?q=Cl%C3%A9mence&FORM=ANNTA1#)

    ## [Prénom Clémence : Origine - Caractère - Signification - PARENTS.fr](https://www.bing.com/ck/a?!&&p=cdf9f97b0fb1bb0e58668f1f2183b17582d520335624ccc47c3639ed7f26cf3aJmltdHM9MTcyOTk4NzIwMA&ptn=3&ver=2&hsh=4&fclid=18c53c15-7230-6a11-3207-2930735e6bf0&psq=Cl%c3%a9mence&u=a1aHR0cHM6Ly93d3cucGFyZW50cy5mci9wcmVub21zL2NsZW1lbmNlLTM3OTcz&ntb=1)

    Clémence est un prénom ancien d\'origine latine qui signifie \"la douceur\" et \"l\'indulgence\". Découvrez son histoire, sa fête, sa répartition géographique, son caractère, ses symboles et ...

4.  [](https://www.bing.com/ck/a?!&&p=5e6f1c6f0cd176f7acaf4571cdb222abe21d984dd715e58984ca437873f74112JmltdHM9MTcyOTk4NzIwMA&ptn=3&ver=2&hsh=4&fclid=18c53c15-7230-6a11-3207-2930735e6bf0&psq=Cl%c3%a9mence&u=a1aHR0cHM6Ly9kaWN0aW9ubmFpcmUubGVyb2JlcnQuY29tL2RlZmluaXRpb24vY2xlbWVuY2U&ntb=1)
    ![Global web icon]()

    [](https://www.bing.com/ck/a?!&&p=5e6f1c6f0cd176f7acaf4571cdb222abe21d984dd715e58984ca437873f74112JmltdHM9MTcyOTk4NzIwMA&ptn=3&ver=2&hsh=4&fclid=18c53c15-7230-6a11-3207-2930735e6bf0&psq=Cl%c3%a9mence&u=a1aHR0cHM6Ly9kaWN0aW9ubmFpcmUubGVyb2JlcnQuY29tL2RlZmluaXRpb24vY2xlbWVuY2U&ntb=1)
    Dico en ligne Le Robert

    [](https://www.bing.com/ck/a?!&&p=5e6f1c6f0cd176f7acaf4571cdb222abe21d984dd715e58984ca437873f74112JmltdHM9MTcyOTk4NzIwMA&ptn=3&ver=2&hsh=4&fclid=18c53c15-7230-6a11-3207-2930735e6bf0&psq=Cl%c3%a9mence&u=a1aHR0cHM6Ly9kaWN0aW9ubmFpcmUubGVyb2JlcnQuY29tL2RlZmluaXRpb24vY2xlbWVuY2U&ntb=1)
    [https://dictionnaire.lerobert.com › definition › clemence](https://www.bing.com/ck/a?!&&p=5e6f1c6f0cd176f7acaf4571cdb222abe21d984dd715e58984ca437873f74112JmltdHM9MTcyOTk4NzIwMA&ptn=3&ver=2&hsh=4&fclid=18c53c15-7230-6a11-3207-2930735e6bf0&psq=Cl%c3%a9mence&u=a1aHR0cHM6Ly9kaWN0aW9ubmFpcmUubGVyb2JlcnQuY29tL2RlZmluaXRpb24vY2xlbWVuY2U&ntb=1)[](https://www.bing.com/search?q=Cl%C3%A9mence&FORM=ANNTA1#)

    ## [clémence - Définitions, synonymes, prononciation, exemples \| Dico ...](https://www.bing.com/ck/a?!&&p=5e6f1c6f0cd176f7acaf4571cdb222abe21d984dd715e58984ca437873f74112JmltdHM9MTcyOTk4NzIwMA&ptn=3&ver=2&hsh=4&fclid=18c53c15-7230-6a11-3207-2930735e6bf0&psq=Cl%c3%a9mence&u=a1aHR0cHM6Ly9kaWN0aW9ubmFpcmUubGVyb2JlcnQuY29tL2RlZmluaXRpb24vY2xlbWVuY2U&ntb=1)

    Jun 12, 2020 · Clémence est une vertu qui consiste à pardonner les offenses ou à adoucir les châtiments. Le mot a aussi un sens littéraire et des synonymes comme indulgence ou ...

    [](https://www.bing.com/ck/a?!&&p=5e6f1c6f0cd176f7acaf4571cdb222abe21d984dd715e58984ca437873f74112JmltdHM9MTcyOTk4NzIwMA&ptn=3&ver=2&hsh=4&fclid=18c53c15-7230-6a11-3207-2930735e6bf0&psq=Cl%c3%a9mence&u=a1aHR0cHM6Ly9kaWN0aW9ubmFpcmUubGVyb2JlcnQuY29tL2RlZmluaXRpb24vY2xlbWVuY2U&ntb=1)
    Tags:

    La Clémence

    Dico

5.  [](https://www.bing.com/ck/a?!&&p=d8fa8e2c85d18a6672e1eb29bffc1ebefd42f9e57679bc80eda9b49eebf16264JmltdHM9MTcyOTk4NzIwMA&ptn=3&ver=2&hsh=4&fclid=18c53c15-7230-6a11-3207-2930735e6bf0&psq=Cl%c3%a9mence&u=a1aHR0cHM6Ly9mci53aWtpcGVkaWEub3JnL3dpa2kvQ2wlQzMlQTltZW5jZV8ocHIlQzMlQTlub20p&ntb=1)
    ![Global web icon]()

    [](https://www.bing.com/ck/a?!&&p=d8fa8e2c85d18a6672e1eb29bffc1ebefd42f9e57679bc80eda9b49eebf16264JmltdHM9MTcyOTk4NzIwMA&ptn=3&ver=2&hsh=4&fclid=18c53c15-7230-6a11-3207-2930735e6bf0&psq=Cl%c3%a9mence&u=a1aHR0cHM6Ly9mci53aWtpcGVkaWEub3JnL3dpa2kvQ2wlQzMlQTltZW5jZV8ocHIlQzMlQTlub20p&ntb=1)
    Wikipédia

    [](https://www.bing.com/ck/a?!&&p=d8fa8e2c85d18a6672e1eb29bffc1ebefd42f9e57679bc80eda9b49eebf16264JmltdHM9MTcyOTk4NzIwMA&ptn=3&ver=2&hsh=4&fclid=18c53c15-7230-6a11-3207-2930735e6bf0&psq=Cl%c3%a9mence&u=a1aHR0cHM6Ly9mci53aWtpcGVkaWEub3JnL3dpa2kvQ2wlQzMlQTltZW5jZV8ocHIlQzMlQTlub20p&ntb=1)
    [https://fr.wikipedia.org › wiki › Clémence\_(prénom)](https://www.bing.com/ck/a?!&&p=d8fa8e2c85d18a6672e1eb29bffc1ebefd42f9e57679bc80eda9b49eebf16264JmltdHM9MTcyOTk4NzIwMA&ptn=3&ver=2&hsh=4&fclid=18c53c15-7230-6a11-3207-2930735e6bf0&psq=Cl%c3%a9mence&u=a1aHR0cHM6Ly9mci53aWtpcGVkaWEub3JnL3dpa2kvQ2wlQzMlQTltZW5jZV8ocHIlQzMlQTlub20p&ntb=1)[](https://www.bing.com/search?q=Cl%C3%A9mence&FORM=ANNTA1#)

    ## [Clémence (prénom) --- Wikipédia](https://www.bing.com/ck/a?!&&p=d8fa8e2c85d18a6672e1eb29bffc1ebefd42f9e57679bc80eda9b49eebf16264JmltdHM9MTcyOTk4NzIwMA&ptn=3&ver=2&hsh=4&fclid=18c53c15-7230-6a11-3207-2930735e6bf0&psq=Cl%c3%a9mence&u=a1aHR0cHM6Ly9mci53aWtpcGVkaWEub3JnL3dpa2kvQ2wlQzMlQTltZW5jZV8ocHIlQzMlQTlub20p&ntb=1)

    -   Vue d'ensemble
    -   Les \"Clémence\" célèbres
    -   Variantes

    • [Clémence de Hongrie](https://www.bing.com/ck/a?!&&p=82793ec5f1ad3d42a861b034ef247c0402b6682479d8bb87e15b3774299f2a3cJmltdHM9MTcyOTk4NzIwMA&ptn=3&ver=2&hsh=4&fclid=18c53c15-7230-6a11-3207-2930735e6bf0&u=a1L3NlYXJjaD9xPUNsw6ltZW5jZSUyMGRlJTIwSG9uZ3JpZSUyMHdpa2lwZWRpYSZmb3JtPVdJS0lSRQ&ntb=1), ([1293](https://www.bing.com/ck/a?!&&p=d3d9d488aa9a996ece343b6a53231a9493eb41562b5b844334bc8d65bcb69eecJmltdHM9MTcyOTk4NzIwMA&ptn=3&ver=2&hsh=4&fclid=18c53c15-7230-6a11-3207-2930735e6bf0&u=a1L3NlYXJjaD9xPTEyOTMlMjB3aWtpcGVkaWEmZm9ybT1XSUtJUkU&ntb=1) - [1328](https://www.bing.com/ck/a?!&&p=7f6da707cde810e89197ea3305f6264603df89034f594406bf6c66373ecaea25JmltdHM9MTcyOTk4NzIwMA&ptn=3&ver=2&hsh=4&fclid=18c53c15-7230-6a11-3207-2930735e6bf0&u=a1L3NlYXJjaD9xPTEzMjglMjB3aWtpcGVkaWEmZm9ybT1XSUtJUkU&ntb=1)), reine de France et de Navarre.\
    • [Clémence d\'Aquitaine](https://www.bing.com/ck/a?!&&p=eb8dd835a6b24fa61f8a949c172ee38e2a7a1c5266d0ceacee7311a1509b401fJmltdHM9MTcyOTk4NzIwMA&ptn=3&ver=2&hsh=4&fclid=18c53c15-7230-6a11-3207-2930735e6bf0&u=a1L3NlYXJjaD9xPUNsw6ltZW5jZSUyMGQnQXF1aXRhaW5lJTIwd2lraXBlZGlhJmZvcm09V0lLSVJF&ntb=1) ([1060](https://www.bing.com/ck/a?!&&p=e988bb573df8a146a44d05223eaa6f16ba143b32527aea40c5aff0459e98fd3aJmltdHM9MTcyOTk4NzIwMA&ptn=3&ver=2&hsh=4&fclid=18c53c15-7230-6a11-3207-2930735e6bf0&u=a1L3NlYXJjaD9xPTEwNjAlMjB3aWtpcGVkaWEmZm9ybT1XSUtJUkU&ntb=1) - [1142](https://www.bing.com/ck/a?!&&p=1a00fceb520d845ee873bc2973321eb0ead65ec507056fc2746b8e9d2d354c11JmltdHM9MTcyOTk4NzIwMA&ptn=3&ver=2&hsh=4&fclid=18c53c15-7230-6a11-3207-2930735e6bf0&u=a1L3NlYXJjaD9xPTExNDIlMjB3aWtpcGVkaWEmZm9ybT1XSUtJUkU&ntb=1)).\
    • [Clémence de Trèves](https://www.bing.com/ck/a?!&&p=316e832088172efd963fd6f8e938065046611fce1c4416bf1425e7c2cd366d4dJmltdHM9MTcyOTk4NzIwMA&ptn=3&ver=2&hsh=4&fclid=18c53c15-7230-6a11-3207-2930735e6bf0&u=a1L3NlYXJjaD9xPUNsw6ltZW5jZSUyMGRlJTIwVHLDqHZlcyUyMHdpa2lwZWRpYSZmb3JtPVdJS0lSRQ&ntb=1) (+ 1176), religieuse bénédictine, [bienheureuse](https://www.bing.com/ck/a?!&&p=0c5556ae7451bbe0c384743aa461dc4f484f0a0ec8e5b45c74f1c40ba95858cdJmltdHM9MTcyOTk4NzIwMA&ptn=3&ver=2&hsh=4&fclid=18c53c15-7230-6a11-3207-2930735e6bf0&u=a1L3NlYXJjaD9xPUJpZW5oZXVyZXVzZSUyMHdpa2lwZWRpYSZmb3JtPVdJS0lSRQ&ntb=1).\
    • [Clémence Isaure](https://www.bing.com/ck/a?!&&p=906a6668683cc92dfb6eb6afbb42fc6a411a7834753d0fb4086bfd7e2a1d68d4JmltdHM9MTcyOTk4NzIwMA&ptn=3&ver=2&hsh=4&fclid=18c53c15-7230-6a11-3207-2930735e6bf0&u=a1L3NlYXJjaD9xPUFjYWTDqW1pZSUyMGRlcyUyMEpldXglMjBmbG9yYXV4JTIwd2lraXBlZGlhJmZvcm09V0lLSVJF&ntb=1), personnage inventé en [1515](https://www.bing.com/ck/a?!&&p=1c6c62e1906b91791053e3147fbdcf7ff97d48778fb41dfc9358a166864400ceJmltdHM9MTcyOTk4NzIwMA&ptn=3&ver=2&hsh=4&fclid=18c53c15-7230-6a11-3207-2930735e6bf0&u=a1L3NlYXJjaD9xPTE1MTUlMjB3aWtpcGVkaWEmZm9ybT1XSUtJUkU&ntb=1) pour financer les [Jeux Floraux](https://www.bing.com/ck/a?!&&p=906a6668683cc92dfb6eb6afbb42fc6a411a7834753d0fb4086bfd7e2a1d68d4JmltdHM9MTcyOTk4NzIwMA&ptn=3&ver=2&hsh=4&fclid=18c53c15-7230-6a11-3207-2930735e6bf0&u=a1L3NlYXJjaD9xPUFjYWTDqW1pZSUyMGRlcyUyMEpldXglMjBmbG9yYXV4JTIwd2lraXBlZGlhJmZvcm09V0lLSVJF&ntb=1).

    [Wikipedia](https://www.bing.com/ck/a?!&&p=d8fa8e2c85d18a6672e1eb29bffc1ebefd42f9e57679bc80eda9b49eebf16264JmltdHM9MTcyOTk4NzIwMA&ptn=3&ver=2&hsh=4&fclid=18c53c15-7230-6a11-3207-2930735e6bf0&psq=Cl%c3%a9mence&u=a1aHR0cHM6Ly9mci53aWtpcGVkaWEub3JnL3dpa2kvQ2wlQzMlQTltZW5jZV8ocHIlQzMlQTlub20p&ntb=1) · Text under [CC-BY-SA license](https://www.bing.com/ck/a?!&&p=cb929121f9ac40547cd54d36a08ee5107732b2d650470575d27050b9fc381c90JmltdHM9MTcyOTk4NzIwMA&ptn=3&ver=2&hsh=4&fclid=18c53c15-7230-6a11-3207-2930735e6bf0&psq=Cl%c3%a9mence&u=a1aHR0cDovL2NyZWF0aXZlY29tbW9ucy5vcmcvbGljZW5zZXMvYnktc2EvMy4wLw&ntb=1)

    -   **Estimated Reading Time:** 1 min

    &nbsp;

6.  [](https://www.bing.com/ck/a?!&&p=9f410d777ca9fd4b35f468db26049b4db4760b54e2604361395e594a31e56aabJmltdHM9MTcyOTk4NzIwMA&ptn=3&ver=2&hsh=4&fclid=18c53c15-7230-6a11-3207-2930735e6bf0&psq=Cl%c3%a9mence&u=a1aHR0cHM6Ly93d3cubGFsYW5ndWVmcmFuY2Fpc2UuY29tL2RpY3Rpb25uYWlyZS9kZWZpbml0aW9uL2NsZW1lbmNl&ntb=1)
    ![Global web icon]()

    [](https://www.bing.com/ck/a?!&&p=9f410d777ca9fd4b35f468db26049b4db4760b54e2604361395e594a31e56aabJmltdHM9MTcyOTk4NzIwMA&ptn=3&ver=2&hsh=4&fclid=18c53c15-7230-6a11-3207-2930735e6bf0&psq=Cl%c3%a9mence&u=a1aHR0cHM6Ly93d3cubGFsYW5ndWVmcmFuY2Fpc2UuY29tL2RpY3Rpb25uYWlyZS9kZWZpbml0aW9uL2NsZW1lbmNl&ntb=1)
    La langue française

    [](https://www.bing.com/ck/a?!&&p=9f410d777ca9fd4b35f468db26049b4db4760b54e2604361395e594a31e56aabJmltdHM9MTcyOTk4NzIwMA&ptn=3&ver=2&hsh=4&fclid=18c53c15-7230-6a11-3207-2930735e6bf0&psq=Cl%c3%a9mence&u=a1aHR0cHM6Ly93d3cubGFsYW5ndWVmcmFuY2Fpc2UuY29tL2RpY3Rpb25uYWlyZS9kZWZpbml0aW9uL2NsZW1lbmNl&ntb=1)
    [https://www.lalanguefrancaise.com › di...](https://www.bing.com/ck/a?!&&p=9f410d777ca9fd4b35f468db26049b4db4760b54e2604361395e594a31e56aabJmltdHM9MTcyOTk4NzIwMA&ptn=3&ver=2&hsh=4&fclid=18c53c15-7230-6a11-3207-2930735e6bf0&psq=Cl%c3%a9mence&u=a1aHR0cHM6Ly93d3cubGFsYW5ndWVmcmFuY2Fpc2UuY29tL2RpY3Rpb25uYWlyZS9kZWZpbml0aW9uL2NsZW1lbmNl&ntb=1)[](https://www.bing.com/search?q=Cl%C3%A9mence&FORM=ANNTA1#)

    ![]( "Explore this image")

    ## [Définition de clémence \| Dictionnaire français - La ...](https://www.bing.com/ck/a?!&&p=9f410d777ca9fd4b35f468db26049b4db4760b54e2604361395e594a31e56aabJmltdHM9MTcyOTk4NzIwMA&ptn=3&ver=2&hsh=4&fclid=18c53c15-7230-6a11-3207-2930735e6bf0&psq=Cl%c3%a9mence&u=a1aHR0cHM6Ly93d3cubGFsYW5ndWVmcmFuY2Fpc2UuY29tL2RpY3Rpb25uYWlyZS9kZWZpbml0aW9uL2NsZW1lbmNl&ntb=1)

    Feb 13, 2024 · Clémence est la qualité de qui pardonne les fautes et adoucit les peines. Découvrez son étymologie, ses synonymes, ses antonymes, ses expressions et ses citations littéraires.

7.  [](https://www.bing.com/ck/a?!&&p=15a35c700c5083027fc2a9df4f13e9dfbcf66b755a2caaf4b3d43590c0004dd1JmltdHM9MTcyOTk4NzIwMA&ptn=3&ver=2&hsh=4&fclid=18c53c15-7230-6a11-3207-2930735e6bf0&psq=Cl%c3%a9mence&u=a1aHR0cHM6Ly9tYWRhbWUubGVmaWdhcm8uZnIvcHJlbm9tcy9wcmVub20vZmlsbGUvY2xlbWVuY2U&ntb=1)
    ![Global web icon]()

    [](https://www.bing.com/ck/a?!&&p=15a35c700c5083027fc2a9df4f13e9dfbcf66b755a2caaf4b3d43590c0004dd1JmltdHM9MTcyOTk4NzIwMA&ptn=3&ver=2&hsh=4&fclid=18c53c15-7230-6a11-3207-2930735e6bf0&psq=Cl%c3%a9mence&u=a1aHR0cHM6Ly9tYWRhbWUubGVmaWdhcm8uZnIvcHJlbm9tcy9wcmVub20vZmlsbGUvY2xlbWVuY2U&ntb=1)
    Madame Figaro

    [](https://www.bing.com/ck/a?!&&p=15a35c700c5083027fc2a9df4f13e9dfbcf66b755a2caaf4b3d43590c0004dd1JmltdHM9MTcyOTk4NzIwMA&ptn=3&ver=2&hsh=4&fclid=18c53c15-7230-6a11-3207-2930735e6bf0&psq=Cl%c3%a9mence&u=a1aHR0cHM6Ly9tYWRhbWUubGVmaWdhcm8uZnIvcHJlbm9tcy9wcmVub20vZmlsbGUvY2xlbWVuY2U&ntb=1)
    [https://madame.lefigaro.fr › prenoms › prenom › fille › clemence](https://www.bing.com/ck/a?!&&p=15a35c700c5083027fc2a9df4f13e9dfbcf66b755a2caaf4b3d43590c0004dd1JmltdHM9MTcyOTk4NzIwMA&ptn=3&ver=2&hsh=4&fclid=18c53c15-7230-6a11-3207-2930735e6bf0&psq=Cl%c3%a9mence&u=a1aHR0cHM6Ly9tYWRhbWUubGVmaWdhcm8uZnIvcHJlbm9tcy9wcmVub20vZmlsbGUvY2xlbWVuY2U&ntb=1)[](https://www.bing.com/search?q=Cl%C3%A9mence&FORM=ANNTA1#)

    ## [Prénom Clemence, féminin, latin, classique : signification](https://www.bing.com/ck/a?!&&p=15a35c700c5083027fc2a9df4f13e9dfbcf66b755a2caaf4b3d43590c0004dd1JmltdHM9MTcyOTk4NzIwMA&ptn=3&ver=2&hsh=4&fclid=18c53c15-7230-6a11-3207-2930735e6bf0&psq=Cl%c3%a9mence&u=a1aHR0cHM6Ly9tYWRhbWUubGVmaWdhcm8uZnIvcHJlbm9tcy9wcmVub20vZmlsbGUvY2xlbWVuY2U&ntb=1)

    Jun 26, 2012 · Clémence est un prénom féminin d\'origine latine qui signifie \"douceur\" ou \"indulgent\". Découvrez son histoire, sa personnalité, sa fête, sa couleur, sa pierre et sa ...

    [](https://www.bing.com/ck/a?!&&p=15a35c700c5083027fc2a9df4f13e9dfbcf66b755a2caaf4b3d43590c0004dd1JmltdHM9MTcyOTk4NzIwMA&ptn=3&ver=2&hsh=4&fclid=18c53c15-7230-6a11-3207-2930735e6bf0&psq=Cl%c3%a9mence&u=a1aHR0cHM6Ly9tYWRhbWUubGVmaWdhcm8uZnIvcHJlbm9tcy9wcmVub20vZmlsbGUvY2xlbWVuY2U&ntb=1)
    Tags:

    Clémence

    Latin

8.  [](https://www.bing.com/ck/a?!&&p=0f536b6c7ae321d934d19ccb2faaaa49b87051c3289512f923adfa331ab18684JmltdHM9MTcyOTk4NzIwMA&ptn=3&ver=2&hsh=4&fclid=18c53c15-7230-6a11-3207-2930735e6bf0&psq=Cl%c3%a9mence&u=a1aHR0cHM6Ly9mci53aWt0aW9uYXJ5Lm9yZy93aWtpL2NsJUMzJUE5bWVuY2U&ntb=1)
    ![Global web icon]()

    [](https://www.bing.com/ck/a?!&&p=0f536b6c7ae321d934d19ccb2faaaa49b87051c3289512f923adfa331ab18684JmltdHM9MTcyOTk4NzIwMA&ptn=3&ver=2&hsh=4&fclid=18c53c15-7230-6a11-3207-2930735e6bf0&psq=Cl%c3%a9mence&u=a1aHR0cHM6Ly9mci53aWt0aW9uYXJ5Lm9yZy93aWtpL2NsJUMzJUE5bWVuY2U&ntb=1)
    wiktionary.org

    [](https://www.bing.com/ck/a?!&&p=0f536b6c7ae321d934d19ccb2faaaa49b87051c3289512f923adfa331ab18684JmltdHM9MTcyOTk4NzIwMA&ptn=3&ver=2&hsh=4&fclid=18c53c15-7230-6a11-3207-2930735e6bf0&psq=Cl%c3%a9mence&u=a1aHR0cHM6Ly9mci53aWt0aW9uYXJ5Lm9yZy93aWtpL2NsJUMzJUE5bWVuY2U&ntb=1)
    [https://fr.wiktionary.org › wiki › clémence](https://www.bing.com/ck/a?!&&p=0f536b6c7ae321d934d19ccb2faaaa49b87051c3289512f923adfa331ab18684JmltdHM9MTcyOTk4NzIwMA&ptn=3&ver=2&hsh=4&fclid=18c53c15-7230-6a11-3207-2930735e6bf0&psq=Cl%c3%a9mence&u=a1aHR0cHM6Ly9mci53aWt0aW9uYXJ5Lm9yZy93aWtpL2NsJUMzJUE5bWVuY2U&ntb=1)[](https://www.bing.com/search?q=Cl%C3%A9mence&FORM=ANNTA1#)

    ## [clémence --- Wiktionnaire, le dictionnaire libre](https://www.bing.com/ck/a?!&&p=0f536b6c7ae321d934d19ccb2faaaa49b87051c3289512f923adfa331ab18684JmltdHM9MTcyOTk4NzIwMA&ptn=3&ver=2&hsh=4&fclid=18c53c15-7230-6a11-3207-2930735e6bf0&psq=Cl%c3%a9mence&u=a1aHR0cHM6Ly9mci53aWt0aW9uYXJ5Lm9yZy93aWtpL2NsJUMzJUE5bWVuY2U&ntb=1)

    Clémence est un nom féminin qui désigne la vertu de pardonner ou de modérer. Il vient du latin clementia et a des équivalents en plusieurs langues. Consultez le Wiktionnaire pour plus de ...

9.  [](https://www.bing.com/ck/a?!&&p=5c0dbbb0d4af841d18d2fdc2edb56288f92da6ffca340611a2a131be44ae9098JmltdHM9MTcyOTk4NzIwMA&ptn=3&ver=2&hsh=4&fclid=18c53c15-7230-6a11-3207-2930735e6bf0&psq=Cl%c3%a9mence&u=a1aHR0cHM6Ly93d3cuZGljdGlvbm5haXJlLWFjYWRlbWllLmZyL2FydGljbGUvQTlDMjU2Ng&ntb=1)
    ![Global web icon]()

    [](https://www.bing.com/ck/a?!&&p=5c0dbbb0d4af841d18d2fdc2edb56288f92da6ffca340611a2a131be44ae9098JmltdHM9MTcyOTk4NzIwMA&ptn=3&ver=2&hsh=4&fclid=18c53c15-7230-6a11-3207-2930735e6bf0&psq=Cl%c3%a9mence&u=a1aHR0cHM6Ly93d3cuZGljdGlvbm5haXJlLWFjYWRlbWllLmZyL2FydGljbGUvQTlDMjU2Ng&ntb=1)
    Dictionnaire de l\'Académie française

    [](https://www.bing.com/ck/a?!&&p=5c0dbbb0d4af841d18d2fdc2edb56288f92da6ffca340611a2a131be44ae9098JmltdHM9MTcyOTk4NzIwMA&ptn=3&ver=2&hsh=4&fclid=18c53c15-7230-6a11-3207-2930735e6bf0&psq=Cl%c3%a9mence&u=a1aHR0cHM6Ly93d3cuZGljdGlvbm5haXJlLWFjYWRlbWllLmZyL2FydGljbGUvQTlDMjU2Ng&ntb=1)
    [https://www.dictionnaire-academie.fr › article](https://www.bing.com/ck/a?!&&p=5c0dbbb0d4af841d18d2fdc2edb56288f92da6ffca340611a2a131be44ae9098JmltdHM9MTcyOTk4NzIwMA&ptn=3&ver=2&hsh=4&fclid=18c53c15-7230-6a11-3207-2930735e6bf0&psq=Cl%c3%a9mence&u=a1aHR0cHM6Ly93d3cuZGljdGlvbm5haXJlLWFjYWRlbWllLmZyL2FydGljbGUvQTlDMjU2Ng&ntb=1)[](https://www.bing.com/search?q=Cl%C3%A9mence&FORM=ANNTA1#)

    ## [clémence \| Dictionnaire de l'Académie française \| 9e édition](https://www.bing.com/ck/a?!&&p=5c0dbbb0d4af841d18d2fdc2edb56288f92da6ffca340611a2a131be44ae9098JmltdHM9MTcyOTk4NzIwMA&ptn=3&ver=2&hsh=4&fclid=18c53c15-7230-6a11-3207-2930735e6bf0&psq=Cl%c3%a9mence&u=a1aHR0cHM6Ly93d3cuZGljdGlvbm5haXJlLWFjYWRlbWllLmZyL2FydGljbGUvQTlDMjU2Ng&ntb=1)

    Clémence est un nom féminin qui désigne la disposition à pardonner ou à modérer. Il vient du latin clementia, qui signifie aussi douceur du temps. Découvrez son usage et ses synonymes ...

    [](https://www.bing.com/ck/a?!&&p=5c0dbbb0d4af841d18d2fdc2edb56288f92da6ffca340611a2a131be44ae9098JmltdHM9MTcyOTk4NzIwMA&ptn=3&ver=2&hsh=4&fclid=18c53c15-7230-6a11-3207-2930735e6bf0&psq=Cl%c3%a9mence&u=a1aHR0cHM6Ly93d3cuZGljdGlvbm5haXJlLWFjYWRlbWllLmZyL2FydGljbGUvQTlDMjU2Ng&ntb=1)
    Tags:

    La Clémence

    Dictionnaire de l\'Académie française

10. [](https://www.bing.com/ck/a?!&&p=70d1cb7ce17b792f1c22c828f635eaae71b61b8caa15779f89bbf2ca2d37b915JmltdHM9MTcyOTk4NzIwMA&ptn=3&ver=2&hsh=4&fclid=18c53c15-7230-6a11-3207-2930735e6bf0&psq=Cl%c3%a9mence&u=a1aHR0cHM6Ly9kaWN0aW9uYXJ5LmNhbWJyaWRnZS5vcmcvZGljdGlvbmFyeS9mcmVuY2gtZW5nbGlzaC9jbGVtZW5jZQ&ntb=1)
    ![Global web icon]()

    [](https://www.bing.com/ck/a?!&&p=70d1cb7ce17b792f1c22c828f635eaae71b61b8caa15779f89bbf2ca2d37b915JmltdHM9MTcyOTk4NzIwMA&ptn=3&ver=2&hsh=4&fclid=18c53c15-7230-6a11-3207-2930735e6bf0&psq=Cl%c3%a9mence&u=a1aHR0cHM6Ly9kaWN0aW9uYXJ5LmNhbWJyaWRnZS5vcmcvZGljdGlvbmFyeS9mcmVuY2gtZW5nbGlzaC9jbGVtZW5jZQ&ntb=1)
    Cambridge Dictionary

    [](https://www.bing.com/ck/a?!&&p=70d1cb7ce17b792f1c22c828f635eaae71b61b8caa15779f89bbf2ca2d37b915JmltdHM9MTcyOTk4NzIwMA&ptn=3&ver=2&hsh=4&fclid=18c53c15-7230-6a11-3207-2930735e6bf0&psq=Cl%c3%a9mence&u=a1aHR0cHM6Ly9kaWN0aW9uYXJ5LmNhbWJyaWRnZS5vcmcvZGljdGlvbmFyeS9mcmVuY2gtZW5nbGlzaC9jbGVtZW5jZQ&ntb=1)
    [https://dictionary.cambridge.org › dictionary › french-english › cleme...](https://www.bing.com/ck/a?!&&p=70d1cb7ce17b792f1c22c828f635eaae71b61b8caa15779f89bbf2ca2d37b915JmltdHM9MTcyOTk4NzIwMA&ptn=3&ver=2&hsh=4&fclid=18c53c15-7230-6a11-3207-2930735e6bf0&psq=Cl%c3%a9mence&u=a1aHR0cHM6Ly9kaWN0aW9uYXJ5LmNhbWJyaWRnZS5vcmcvZGljdGlvbmFyeS9mcmVuY2gtZW5nbGlzaC9jbGVtZW5jZQ&ntb=1)[](https://www.bing.com/search?q=Cl%C3%A9mence&FORM=ANNTA1#)

    ## [CLÉMENCE in English - Cambridge Dictionary](https://www.bing.com/ck/a?!&&p=70d1cb7ce17b792f1c22c828f635eaae71b61b8caa15779f89bbf2ca2d37b915JmltdHM9MTcyOTk4NzIwMA&ptn=3&ver=2&hsh=4&fclid=18c53c15-7230-6a11-3207-2930735e6bf0&psq=Cl%c3%a9mence&u=a1aHR0cHM6Ly9kaWN0aW9uYXJ5LmNhbWJyaWRnZS5vcmcvZGljdGlvbmFyeS9mcmVuY2gtZW5nbGlzaC9jbGVtZW5jZQ&ntb=1)

    CLÉMENCE translate: clemency, leniency, forgiveness, clemency. Learn more in the Cambridge French-English Dictionary.

    [](https://www.bing.com/ck/a?!&&p=70d1cb7ce17b792f1c22c828f635eaae71b61b8caa15779f89bbf2ca2d37b915JmltdHM9MTcyOTk4NzIwMA&ptn=3&ver=2&hsh=4&fclid=18c53c15-7230-6a11-3207-2930735e6bf0&psq=Cl%c3%a9mence&u=a1aHR0cHM6Ly9kaWN0aW9uYXJ5LmNhbWJyaWRnZS5vcmcvZGljdGlvbmFyeS9mcmVuY2gtZW5nbGlzaC9jbGVtZW5jZQ&ntb=1)
    Tags:

    Cambridge Advanced Learner\'s Dictionary

    English

11. People also search for

    -   [clemence **definition**](https://www.bing.com/ck/a?!&&p=2fa0546c3f61ac96fcde8c2493ac2d1a5c3cd118a3b602421ec99ae6dc3f841dJmltdHM9MTcyOTk4NzIwMA&ptn=3&ver=2&hsh=4&fclid=18c53c15-7230-6a11-3207-2930735e6bf0&u=a1L3NlYXJjaD9xPWNsZW1lbmNlK2RlZmluaXRpb24mRk9STT1RU1JFMQ&ntb=1)
    -   [clemence **pronunciation**](https://www.bing.com/ck/a?!&&p=a364d6169188a17625ea596cb6183a6167ee5687235175d2f785d73a067a7331JmltdHM9MTcyOTk4NzIwMA&ptn=3&ver=2&hsh=4&fclid=18c53c15-7230-6a11-3207-2930735e6bf0&u=a1L3NlYXJjaD9xPWNsZW1lbmNlK3Byb251bmNpYXRpb24mRk9STT1RU1JFMw&ntb=1)
    -   [**what does clemency mean**](https://www.bing.com/ck/a?!&&p=1d4bf3c053064013f57f46acae9b616a2788f62a219a608315cbb6b13bced3a1JmltdHM9MTcyOTk4NzIwMA&ptn=3&ver=2&hsh=4&fclid=18c53c15-7230-6a11-3207-2930735e6bf0&u=a1L3NlYXJjaD9xPXdoYXQrZG9lcytjbGVtZW5jeSttZWFuJkZPUk09UVNSRTU&ntb=1)

    &nbsp;

    -   [clemence **name meaning**](https://www.bing.com/ck/a?!&&p=b24254c8c0418766537e2a6cf82a672f09f18452f046c11aff16eccb79593548JmltdHM9MTcyOTk4NzIwMA&ptn=3&ver=2&hsh=4&fclid=18c53c15-7230-6a11-3207-2930735e6bf0&u=a1L3NlYXJjaD9xPWNsZW1lbmNlK25hbWUrbWVhbmluZyZGT1JNPVFTUkUy&ntb=1)
    -   [clemence **poesy children**](https://www.bing.com/ck/a?!&&p=fa1975e80b721712fcf5b989dbd9798ac009bfd195a2d7f374e5ea2975339cdcJmltdHM9MTcyOTk4NzIwMA&ptn=3&ver=2&hsh=4&fclid=18c53c15-7230-6a11-3207-2930735e6bf0&u=a1L3NlYXJjaD9xPWNsZW1lbmNlK3BvZXN5K2NoaWxkcmVuJkZPUk09UVNSRTQ&ntb=1)
    -   [**clemency meaning in english**](https://www.bing.com/ck/a?!&&p=ab0843252abaf6094a2653216d18f3f1c4c34b38156d6e596e16505be71de23bJmltdHM9MTcyOTk4NzIwMA&ptn=3&ver=2&hsh=4&fclid=18c53c15-7230-6a11-3207-2930735e6bf0&u=a1L3NlYXJjaD9xPWNsZW1lbmN5K21lYW5pbmcraW4rZW5nbGlzaCZGT1JNPVFTUkU2&ntb=1)

    ## Related searches for **Clémence**

    -   [](https://www.bing.com/ck/a?!&&p=2fa0546c3f61ac96fcde8c2493ac2d1a5c3cd118a3b602421ec99ae6dc3f841dJmltdHM9MTcyOTk4NzIwMA&ptn=3&ver=2&hsh=4&fclid=18c53c15-7230-6a11-3207-2930735e6bf0&u=a1L3NlYXJjaD9xPWNsZW1lbmNlK2RlZmluaXRpb24mRk9STT1RU1JFMQ&ntb=1)

        clemence **definition**
    -   [](https://www.bing.com/ck/a?!&&p=b24254c8c0418766537e2a6cf82a672f09f18452f046c11aff16eccb79593548JmltdHM9MTcyOTk4NzIwMA&ptn=3&ver=2&hsh=4&fclid=18c53c15-7230-6a11-3207-2930735e6bf0&u=a1L3NlYXJjaD9xPWNsZW1lbmNlK25hbWUrbWVhbmluZyZGT1JNPVFTUkUy&ntb=1)

        clemence **name meaning**
    -   [](https://www.bing.com/ck/a?!&&p=a364d6169188a17625ea596cb6183a6167ee5687235175d2f785d73a067a7331JmltdHM9MTcyOTk4NzIwMA&ptn=3&ver=2&hsh=4&fclid=18c53c15-7230-6a11-3207-2930735e6bf0&u=a1L3NlYXJjaD9xPWNsZW1lbmNlK3Byb251bmNpYXRpb24mRk9STT1RU1JFMw&ntb=1)

        clemence **pronunciation**
    -   [](https://www.bing.com/ck/a?!&&p=fa1975e80b721712fcf5b989dbd9798ac009bfd195a2d7f374e5ea2975339cdcJmltdHM9MTcyOTk4NzIwMA&ptn=3&ver=2&hsh=4&fclid=18c53c15-7230-6a11-3207-2930735e6bf0&u=a1L3NlYXJjaD9xPWNsZW1lbmNlK3BvZXN5K2NoaWxkcmVuJkZPUk09UVNSRTQ&ntb=1)

        clemence **poesy children**
    -   [](https://www.bing.com/ck/a?!&&p=1d4bf3c053064013f57f46acae9b616a2788f62a219a608315cbb6b13bced3a1JmltdHM9MTcyOTk4NzIwMA&ptn=3&ver=2&hsh=4&fclid=18c53c15-7230-6a11-3207-2930735e6bf0&u=a1L3NlYXJjaD9xPXdoYXQrZG9lcytjbGVtZW5jeSttZWFuJkZPUk09UVNSRTU&ntb=1)

        **what does clemency mean**
    -   [](https://www.bing.com/ck/a?!&&p=ab0843252abaf6094a2653216d18f3f1c4c34b38156d6e596e16505be71de23bJmltdHM9MTcyOTk4NzIwMA&ptn=3&ver=2&hsh=4&fclid=18c53c15-7230-6a11-3207-2930735e6bf0&u=a1L3NlYXJjaD9xPWNsZW1lbmN5K21lYW5pbmcraW4rZW5nbGlzaCZGT1JNPVFTUkU2&ntb=1)

        **clemency meaning in english**
    -   [](https://www.bing.com/ck/a?!&&p=557cfb23ec512aa88d188139dacced50ddd2bdf4f872d452df841864f937da7eJmltdHM9MTcyOTk4NzIwMA&ptn=3&ver=2&hsh=4&fclid=18c53c15-7230-6a11-3207-2930735e6bf0&u=a1L3NlYXJjaD9xPWNsJWMzJWE5bWVuY2UrbWVhbmluZyZGT1JNPVFTUkU3&ntb=1)

        clémence **meaning**
    -   [](https://www.bing.com/ck/a?!&&p=fe38b144ffc082eafa1703c63ad18f8d02722882f9d1f94cde5c527b7c9e34d9JmltdHM9MTcyOTk4NzIwMA&ptn=3&ver=2&hsh=4&fclid=18c53c15-7230-6a11-3207-2930735e6bf0&u=a1L3NlYXJjaD9xPWNsZW1lbmNlK3dhdGNoJkZPUk09UVNSRTg&ntb=1)

        clemence **watch**

12. #### Pagination

    -   [1](https://www.bing.com/search?q=Cl%c3%a9mence&FPIG=1F97A3FDA6EF4A7CB74C98419E20D0B4&first=1&FORM=PERE)
    -   [2](https://www.bing.com/search?q=Cl%c3%a9mence&FPIG=1F97A3FDA6EF4A7CB74C98419E20D0B4&first=11&FORM=PERE1)
    -   [3](https://www.bing.com/search?q=Cl%c3%a9mence&FPIG=1F97A3FDA6EF4A7CB74C98419E20D0B4&first=21&FORM=PERE2)
    -   [4](https://www.bing.com/search?q=Cl%c3%a9mence&FPIG=1F97A3FDA6EF4A7CB74C98419E20D0B4&first=31&FORM=PERE3)
    -   [](https://www.bing.com/search?q=Cl%c3%a9mence&FPIG=1F97A3FDA6EF4A7CB74C98419E20D0B4&first=11&FORM=PORE "Next page")
        Next

1.  ## [Explore with images](https://www.bing.com/ck/a?!&&p=2eeb3d271f1b5bcbb827e31d4fe637be9558940bc912a53c5f89f73cbbb9ce2cJmltdHM9MTcyOTk4NzIwMA&ptn=3&ver=2&hsh=4&fclid=18c53c15-7230-6a11-3207-2930735e6bf0&u=a1L2ltYWdlcy9zZWFyY2g_cT1DbCVjMyVhOW1lbmNlJnFwdnQ9Q2wlYzMlYTltZW5jZSZGT1JNPUlHUkU&ntb=1)

    [](https://www.bing.com/ck/a?!&&p=3fa2033eed551108ab2fa70c80a3b15e443fadaaf3454b995ba03f6d24554e59JmltdHM9MTcyOTk4NzIwMA&ptn=3&ver=2&hsh=4&fclid=18c53c15-7230-6a11-3207-2930735e6bf0&u=a1L2ltYWdlcy9zZWFyY2g_cT1DbGVtZW5jZStQb2VzeStCYWJ5JkZPUk09SUFSU0xL&ntb=1 "Clemence Poesy Baby")
    

    Clemence Poesy Baby

    [](https://www.bing.com/ck/a?!&&p=0862c47055e9b4945f702467f858b53b115a7bb12bf23abfb27f73b53b7c970bJmltdHM9MTcyOTk4NzIwMA&ptn=3&ver=2&hsh=4&fclid=18c53c15-7230-6a11-3207-2930735e6bf0&u=a1L2ltYWdlcy9zZWFyY2g_cT1DbGVtZW5jZStQb2VzeStTbWlsZSZGT1JNPUlBUlNMSw&ntb=1 "Clemence Poesy Smile")
    

    Clemence Poesy Smile

    [](https://www.bing.com/ck/a?!&&p=4bd8d9e6a56060aa62a3f9e89dbcf21ac79ee36b2c1f3f6c512b5f07966aebd2JmltdHM9MTcyOTk4NzIwMA&ptn=3&ver=2&hsh=4&fclid=18c53c15-7230-6a11-3207-2930735e6bf0&u=a1L2ltYWdlcy9zZWFyY2g_cT1DbGVtZW5jZStQb2VzeStTdHlsZSZGT1JNPUlBUlNMSw&ntb=1 "Clemence Poesy Style")
    

    Clemence Poesy Style

    [](https://www.bing.com/ck/a?!&&p=7b1fe5ad4a5a139dfb1b43eb44984ff3f850ecf8d789146e4701bb320d4fdb04JmltdHM9MTcyOTk4NzIwMA&ptn=3&ver=2&hsh=4&fclid=18c53c15-7230-6a11-3207-2930735e6bf0&u=a1L2ltYWdlcy9zZWFyY2g_cT1DbGVtZW5jZStQb2VzeStGbGV1ciZGT1JNPUlBUlNMSw&ntb=1 "Clemence Poesy Fleur")
    

    Clemence Poesy Fleur

    [](https://www.bing.com/ck/a?!&&p=7dca8ff90e1f80b96ae98c2f38ce796b2e132caa4ff280e9ea51f34c0f3e66cfJmltdHM9MTcyOTk4NzIwMA&ptn=3&ver=2&hsh=4&fclid=18c53c15-7230-6a11-3207-2930735e6bf0&u=a1L2ltYWdlcy9zZWFyY2g_cT1DbGVtZW5jZStQb2VzeStCcnVnZXMmRk9STT1JQVJTTEs&ntb=1 "Clemence Poesy Bruges")
    

    Clemence Poesy Bruges

    [](https://www.bing.com/ck/a?!&&p=2eeb3d271f1b5bcbb827e31d4fe637be9558940bc912a53c5f89f73cbbb9ce2cJmltdHM9MTcyOTk4NzIwMA&ptn=3&ver=2&hsh=4&fclid=18c53c15-7230-6a11-3207-2930735e6bf0&u=a1L2ltYWdlcy9zZWFyY2g_cT1DbCVjMyVhOW1lbmNlJnFwdnQ9Q2wlYzMlYTltZW5jZSZGT1JNPUlHUkU&ntb=1 "See more")
    See more

     

2.  ## Related searches

    [](https://www.bing.com/ck/a?!&&p=d707cda614f3f83048a3895604bd05965c9030819f689535cf1a43bf3da3a39eJmltdHM9MTcyOTk4NzIwMA&ptn=3&ver=2&hsh=4&fclid=18c53c15-7230-6a11-3207-2930735e6bf0&u=a1L3NlYXJjaD9xPWNsZW1lbmNlK2RlZmluaXRpb24mRk9STT1SNUZE&ntb=1)

    clemence **definition**

    [](https://www.bing.com/ck/a?!&&p=1f41621936e0aa3a9cd3f5d9f2bce977a2b527f46b38351a730739ad190e348cJmltdHM9MTcyOTk4NzIwMA&ptn=3&ver=2&hsh=4&fclid=18c53c15-7230-6a11-3207-2930735e6bf0&u=a1L3NlYXJjaD9xPWNsZW1lbmNlK25hbWUrbWVhbmluZyZGT1JNPVI1RkQx&ntb=1)

    clemence **name meaning**

    [](https://www.bing.com/ck/a?!&&p=29ebc9555d9b69717756810dc98da28a326bcaaffb9bf359cf2fb6748d66319bJmltdHM9MTcyOTk4NzIwMA&ptn=3&ver=2&hsh=4&fclid=18c53c15-7230-6a11-3207-2930735e6bf0&u=a1L3NlYXJjaD9xPWNsZW1lbmNlK3Byb251bmNpYXRpb24mRk9STT1SNUZEMg&ntb=1)

    clemence **pronunciation**

    [](https://www.bing.com/ck/a?!&&p=84f6827793027e76bf8dff0c8b438d09f258470a38be7116257a632ababcc438JmltdHM9MTcyOTk4NzIwMA&ptn=3&ver=2&hsh=4&fclid=18c53c15-7230-6a11-3207-2930735e6bf0&u=a1L3NlYXJjaD9xPWNsZW1lbmNlK3BvZXN5K2NoaWxkcmVuJkZPUk09UjVGRDM&ntb=1)

    clemence **poesy children**

    [](https://www.bing.com/ck/a?!&&p=aa89f4fd18673e48afaf2529ee397985871e93161fcae9ab7968d53497a8d27aJmltdHM9MTcyOTk4NzIwMA&ptn=3&ver=2&hsh=4&fclid=18c53c15-7230-6a11-3207-2930735e6bf0&u=a1L3NlYXJjaD9xPXdoYXQrZG9lcytjbGVtZW5jeSttZWFuJkZPUk09UjVGRDQ&ntb=1)

    **what does clemency mean**

    [](https://www.bing.com/ck/a?!&&p=9267e4e4c920b83c94c889a6fa5604a088c84bb6a689e811dd33372152d6dfcaJmltdHM9MTcyOTk4NzIwMA&ptn=3&ver=2&hsh=4&fclid=18c53c15-7230-6a11-3207-2930735e6bf0&u=a1L3NlYXJjaD9xPWNsZW1lbmN5K21lYW5pbmcraW4rZW5nbGlzaCZGT1JNPVI1RkQ1&ntb=1)

    **clemency meaning in english**

    [](https://www.bing.com/ck/a?!&&p=f909674b463f080434f4fb70b1daebcdb573309cc139fd0b84ea3e34bb084aa0JmltdHM9MTcyOTk4NzIwMA&ptn=3&ver=2&hsh=4&fclid=18c53c15-7230-6a11-3207-2930735e6bf0&u=a1L3NlYXJjaD9xPWNsJWMzJWE5bWVuY2UrbWVhbmluZyZGT1JNPVI1RkQ2&ntb=1)

    clémence **meaning**

    [](https://www.bing.com/ck/a?!&&p=081a1058f047da25f77e16e891d01d0c4168058895295a6c9f757c3ecc1962d7JmltdHM9MTcyOTk4NzIwMA&ptn=3&ver=2&hsh=4&fclid=18c53c15-7230-6a11-3207-2930735e6bf0&u=a1L3NlYXJjaD9xPWNsZW1lbmNlK3dhdGNoJkZPUk09UjVGRDc&ntb=1)

    clemence **watch**

3.  [](javascript:void(0) "Link for logging")

    ✕
    Play

    clémence

    nom féminin singulier

    1.  Fait de pardonner à un coupable pour une personne ayant la possibilité de la condamner.

    -   [](javascript:void(0) "Link for logging")
        SIMILAR:
        [indulgence](https://www.bing.com/ck/a?!&&p=b08563dff16cc83a59a7f01bff04d58b0bcd95f4a6a89ed92be7676fee7d4692JmltdHM9MTcyOTk4NzIwMA&ptn=3&ver=2&hsh=4&fclid=18c53c15-7230-6a11-3207-2930735e6bf0&u=a1L3NlYXJjaD9xPWQlYzMlYTlmaW5pcitpbmR1bGdlbmNlJkZPUk09RENUUlFZ&ntb=1)

        [bonté](https://www.bing.com/ck/a?!&&p=5971a8d21e669fb9593197549357f9668b54cfbe4ce9eaecf4b6b183875f68b6JmltdHM9MTcyOTk4NzIwMA&ptn=3&ver=2&hsh=4&fclid=18c53c15-7230-6a11-3207-2930735e6bf0&u=a1L3NlYXJjaD9xPWQlYzMlYTlmaW5pcitib250JWMzJWE5JkZPUk09RENUUlFZ&ntb=1)

        [magnanimité](https://www.bing.com/ck/a?!&&p=e36d9e04adbe091e136cd32913a73d82dbe2a764fede0a5c927361f2b7ae6dcbJmltdHM9MTcyOTk4NzIwMA&ptn=3&ver=2&hsh=4&fclid=18c53c15-7230-6a11-3207-2930735e6bf0&u=a1L3NlYXJjaD9xPWQlYzMlYTlmaW5pcittYWduYW5pbWl0JWMzJWE5JkZPUk09RENUUlFZ&ntb=1)

        [absolution](https://www.bing.com/ck/a?!&&p=d334da5623073bf7a82df9e1c5092ea13ef5f264928d19f41d756c5d749de16eJmltdHM9MTcyOTk4NzIwMA&ptn=3&ver=2&hsh=4&fclid=18c53c15-7230-6a11-3207-2930735e6bf0&u=a1L3NlYXJjaD9xPWQlYzMlYTlmaW5pcithYnNvbHV0aW9uJkZPUk09RENUUlFZ&ntb=1)

        [miséricorde](https://www.bing.com/ck/a?!&&p=c376fc7ccde641d955a8c057f0d88bd4e616c31c445aed684e3a8cda96bb960fJmltdHM9MTcyOTk4NzIwMA&ptn=3&ver=2&hsh=4&fclid=18c53c15-7230-6a11-3207-2930735e6bf0&u=a1L3NlYXJjaD9xPWQlYzMlYTlmaW5pcittaXMlYzMlYTlyaWNvcmRlJkZPUk09RENUUlFZ&ntb=1)

        [](javascript:void(0) "Link for logging")
        OPPOSITE:
        [inclémence](https://www.bing.com/ck/a?!&&p=7361abdab5990795b0293609a4284bae53bfc56f722c90d72fbf2a90405bd319JmltdHM9MTcyOTk4NzIwMA&ptn=3&ver=2&hsh=4&fclid=18c53c15-7230-6a11-3207-2930735e6bf0&u=a1L3NlYXJjaD9xPWQlYzMlYTlmaW5pcitpbmNsJWMzJWE5bWVuY2UmRk9STT1EQ1RSUVk&ntb=1)

        [sévérité](https://www.bing.com/ck/a?!&&p=95f35b18a8fe2f2bf3ec12ea671ee11bba3ab8cb5a5824edc406a41480ab23a2JmltdHM9MTcyOTk4NzIwMA&ptn=3&ver=2&hsh=4&fclid=18c53c15-7230-6a11-3207-2930735e6bf0&u=a1L3NlYXJjaD9xPWQlYzMlYTlmaW5pcitzJWMzJWE5diVjMyVhOXJpdCVjMyVhOSZGT1JNPURDVFJRWQ&ntb=1)

        [dureté](https://www.bing.com/ck/a?!&&p=d06708e0ea207aa9154c8b78d507918e412169c035e61af35ad44e1a8420f48aJmltdHM9MTcyOTk4NzIwMA&ptn=3&ver=2&hsh=4&fclid=18c53c15-7230-6a11-3207-2930735e6bf0&u=a1L3NlYXJjaD9xPWQlYzMlYTlmaW5pcitkdXJldCVjMyVhOSZGT1JNPURDVFJRWQ&ntb=1)

&nbsp;

© 2024 Microsoft

-   Manage Cookie Preferences

-   [Privacy and Cookies](https://www.bing.com/ck/a?!&&p=fd79d856d488fabf443e5fdf0162dc9fd6aa12e3bd0f523edefdb1d1bcf07d2eJmltdHM9MTcyOTk4NzIwMA&ptn=3&ver=2&hsh=4&fclid=18c53c15-7230-6a11-3207-2930735e6bf0&psq=Cl%c3%a9mence&u=a1aHR0cDovL2dvLm1pY3Jvc29mdC5jb20vZndsaW5rLz9MaW5rSWQ9NTIxODM5&ntb=1)

-   [Legal](https://www.bing.com/ck/a?!&&p=c57a5e92ec0a394101971f62578d37352f7278dd8e3fa01b4df14d7fd8b78f3aJmltdHM9MTcyOTk4NzIwMA&ptn=3&ver=2&hsh=4&fclid=18c53c15-7230-6a11-3207-2930735e6bf0&psq=Cl%c3%a9mence&u=a1aHR0cDovL2dvLm1pY3Jvc29mdC5jb20vZndsaW5rLz9MaW5rSUQ9MjQ2MzM4&ntb=1)

-   [Advertise](https://www.bing.com/ck/a?!&&p=2e0a22ce067a42707bcb9c8618d999f294912c231b03f1d0c5226d088d2322b0JmltdHM9MTcyOTk4NzIwMA&ptn=3&ver=2&hsh=4&fclid=18c53c15-7230-6a11-3207-2930735e6bf0&psq=Cl%c3%a9mence&u=a1aHR0cHM6Ly9nby5taWNyb3NvZnQuY29tL2Z3bGluay8_bGlua2lkPTg2ODkyMg&ntb=1)

-   [About our ads](https://www.bing.com/ck/a?!&&p=74d39b9354fdfa73854c48686c6a2fcdea2f4c45ad0ace2cf94d137629e8dc24JmltdHM9MTcyOTk4NzIwMA&ptn=3&ver=2&hsh=4&fclid=18c53c15-7230-6a11-3207-2930735e6bf0&psq=Cl%c3%a9mence&u=a1aHR0cDovL2dvLm1pY3Jvc29mdC5jb20vZndsaW5rLz9MaW5rSUQ9Mjg2NzU5&ntb=1)

-   [Help](https://www.bing.com/ck/a?!&&p=12062342e471d07a54dccba03284f739fd144d74a7e99dd5a639bbc85eada9caJmltdHM9MTcyOTk4NzIwMA&ptn=3&ver=2&hsh=4&fclid=18c53c15-7230-6a11-3207-2930735e6bf0&psq=Cl%c3%a9mence&u=a1aHR0cHM6Ly9zdXBwb3J0Lm1pY3Jvc29mdC5jb20vdG9waWMvODJkMjA3MjEtMmQ2Zi00MDEyLWExM2QtZDE5MTBjY2YyMDNm&ntb=1)

-   [Feedback](https://www.bing.com/search?q=Cl%C3%A9mence&FORM=ANNTA1#)

-   [Contenu illicite](https://www.bing.com/ck/a?!&&p=3055295d7591af44dd1de27ca189462a752849ef7de2f6b486b86c525b506295JmltdHM9MTcyOTk4NzIwMA&ptn=3&ver=2&hsh=4&fclid=18c53c15-7230-6a11-3207-2930735e6bf0&psq=Cl%c3%a9mence&u=a1aHR0cDovL3d3dy5wb2ludGRlY29udGFjdC5uZXQvY2xpcXVlei1zaWduYWxleg&ntb=1)

-   [la protection des données européennes](https://www.bing.com/ck/a?!&&p=de8dd4d3e52a544979cdb84735315f072b02c541bee81da80e21f303950e74b2JmltdHM9MTcyOTk4NzIwMA&ptn=3&ver=2&hsh=4&fclid=18c53c15-7230-6a11-3207-2930735e6bf0&psq=Cl%c3%a9mence&u=a1aHR0cDovL2hlbHAuYmluZy5taWNyb3NvZnQuY29tLyNhcGV4LzE4L0ZSLzEwMDEzLy0xL0ZS&ntb=1)

-   [About Bing search](https://www.bing.com/ck/a?!&&p=88cce2980741344cef55fee9eb5fde68b7bfd144736caaff0787cb5742c830a7JmltdHM9MTcyOTk4NzIwMA&ptn=3&ver=2&hsh=4&fclid=18c53c15-7230-6a11-3207-2930735e6bf0&psq=Cl%c3%a9mence&u=a1aHR0cHM6Ly9oZWxwLmJpbmcubWljcm9zb2Z0LmNvbS8jYXBleC8xOC9mci8xMDAyMC8tMQ&ntb=1)