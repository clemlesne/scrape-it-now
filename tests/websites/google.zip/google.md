# Résultats de recherche

# Principaux résultats

## Chargement...

Une erreur s\'est produite.

RÉESSAYER

Sélectionnez l\'élément pour lequel vous voulez envoyer des commentaires

Vous pouvez également

envoyer des commentaires d\'ordre général

Définitions proposées par : [Dictionnaires Le Robert](https://dictionnaire.lerobert.com/google-dictionnaire-fr?param=cl%C3%A9mence) · [En savoir plus](https://support.google.com/websearch/answer/10106608?hl=fr)

clémence

[](https://www.google.com/search?sca_esv=aa46f2d90d76e83e&q=comment+prononcer+cl%C3%A9mence&stick=H4sIAAAAAAAAAOMIfcRozS3w8sc9YSmjSWtOXmPU4eINKMrPK81LzkwsyczPExLlYglJLcoV4pXi5uJMzjm8Mjc1LznVikWJKa2IZxGrdHJ-LlCkRKEAqCsfKFOkAFcEAETn72ReAAAA&sa=X&ved=2ahUKEwipkL-9xq6JAxW-UaQEHbzvCQgQ3eEDegQIQxAL)

Apprenez à prononcer

*nom féminin*

1.  1.

    littéraire

    Vertu qui consiste, de la part de qui dispose d\'une autorité, à pardonner les offenses et à adoucir les châtiments.

    Un acte de clémence.

    h

    Synonymes :

    indulgence

    magnanimité

2.  2.

    Douceur.

    La clémence de la température.

Déclinaisons

**Genre**

**Singulier**

**Pluriel**

Féminin

clémence

clémences

[](https://www.google.com/search?sca_esv=aa46f2d90d76e83e&q=D%C3%A9clinaisons+cl%C3%A9mence&stick=H4sIAAAAAAAAAOOwfsRoyS3w8sc9YSmDSWtOXmPU4uL2zEvLSU0uyczPKxYS5WIJSS3KFeKV4ubiTM45vDI3NS851YpFiSmtiGcRq7jL4ZXJOZl5iZnFQNUKcAUAParXAFgAAAA&hl=fr)

Afficher toutes les déclinaisons/conjugaisons

Commentaires

------------------------------------------------------------------------

Autres questions

Quelle est la signification du nom Clémence ?

1. **Sentiment de générosité qui porte à épargner les coupables ou à atténuer les peines encourues**. 2. Douceur favorable du climat : La clémence de la température.

[\
](https://www.larousse.fr/dictionnaires/francais/cl%C3%A9mence/16481#:~:text=1.,%C3%A0%20att%C3%A9nuer%20les%20peines%20encourues.&text=2.,La%20cl%C3%A9mence%20de%20la%20temp%C3%A9rature.)

### Définitions : clémence - Dictionnaire de français Larousse

Larousse

https://www.larousse.fr › dictionnaires › francais › clémen\...

Larousse

https://www.larousse.fr › dictionnaires › francais › clémen\...

Rechercher : [Quelle est la signification du nom Clémence ?](/search?sca_esv=aa46f2d90d76e83e&q=Quelle+est+la+signification+du+nom+Cl%C3%A9mence+%3F&sa=X&ved=2ahUKEwipkL-9xq6JAxW-UaQEHbzvCQgQzmd6BAg5EAY)

Quel est le sens du mot clémence ?

Nom commun\
\
**Vertu qui consiste à pardonner les offenses et à modérer les châtiments en parlant de ceux qui disposent de l\'autorité souveraine et par extension, de toute personne ayant un certain pouvoir**. Des actes de clémence.

[\
](https://fr.wiktionary.org/wiki/cl%C3%A9mence#:~:text=Nom%20commun,-Singulier&text=Vertu%20qui%20consiste%20%C3%A0%20pardonner,Des%20actes%20de%20cl%C3%A9mence.)

### clémence --- Wiktionnaire, le dictionnaire libre

Wiktionary

https://fr.wiktionary.org › wiki › clémence

Wiktionary

https://fr.wiktionary.org › wiki › clémence

Rechercher : [Quel est le sens du mot clémence ?](/search?sca_esv=aa46f2d90d76e83e&q=Quel+est+le+sens+du+mot+cl%C3%A9mence+%3F&sa=X&ved=2ahUKEwipkL-9xq6JAxW-UaQEHbzvCQgQzmd6BAg3EAY)

Quel est le synonyme de clémence ?

Sentiment de générosité. Synonyme : **bienveillance, bonté, humanité, indulgence, magnanimité**. -- Littéraire : compassion, longanimité, mansuétude, miséricorde.

[\
](https://www.larousse.fr/dictionnaires/synonymes/cl%C3%A9mence/4365#:~:text=Sentiment%20de%20g%C3%A9n%C3%A9rosit%C3%A9.,%2C%20longanimit%C3%A9%2C%20mansu%C3%A9tude%2C%20mis%C3%A9ricorde.)

### Dictionnaire des synonymes : clémence - Larousse

Larousse

https://www.larousse.fr › dictionnaires › clémence

Larousse

https://www.larousse.fr › dictionnaires › clémence

Rechercher : [Quel est le synonyme de clémence ?](/search?sca_esv=aa46f2d90d76e83e&q=Quel+est+le+synonyme+de+cl%C3%A9mence+%3F&sa=X&ved=2ahUKEwipkL-9xq6JAxW-UaQEHbzvCQgQzmd6BAgxEAY)

Est-ce que le prénom Clémence est rare ?

C\'est donc **un prénom assez vieux en France, ainsi que relativement classique**. En 2006, notez que le prénom atteint son pic de popularité, quand 2 575 filles l\'obtiennent. Clémence est attribué à 1 384 bébés en 2016, 1 181 enfants le portent en 2019.

[\
](https://www.magicmaman.com/prenom/clemence,2006200,11762.asp#:~:text=C'est%20donc%20un%20pr%C3%A9nom,enfants%20le%20portent%20en%202019.)

### Prénom Clémence : origine, signification et étymologie

Magicmaman

https://www.magicmaman.com › clemence,2006200,11762

Magicmaman

https://www.magicmaman.com › clemence,2006200,11762

Rechercher : [Est-ce que le prénom Clémence est rare ?](/search?sca_esv=aa46f2d90d76e83e&q=Est-ce+que+le+pr%C3%A9nom+Cl%C3%A9mence+est+rare+%3F&sa=X&ved=2ahUKEwipkL-9xq6JAxW-UaQEHbzvCQgQzmd6BAg1EAY)

Commentaires

[\
](https://www.larousse.fr/dictionnaires/francais/cl%C3%A9mence/16481)

### Définitions : clémence - Dictionnaire de français Larousse

Larousse

https://www.larousse.fr › dictionnaires › francais › clémen\...

Larousse

https://www.larousse.fr › dictionnaires › francais › clémen\...

1\. Sentiment de générosité qui porte à épargner les coupables ou à atténuer les peines encourues. Synonymes : bienveillance - indulgence \...

[\
](https://www.parents.fr/prenoms/clemence-37973)

### Prénom Clémence : Origine - Caractère - Signification

PARENTS.fr

https://www.parents.fr › Prénoms › Prénoms filles

PARENTS.fr

https://www.parents.fr › Prénoms › Prénoms filles

9 févr. 2024 --- On fête les *Clémence* le 21 mars. L\'âge moyen des *Clémence* est de 33 ans. Signification & histoire; Popularité; Caractère; Prénoms similaires \...

## Résultats Twitter

[](https://twitter.com/Clemence_Guette?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor)

### Clémence Guetté (@Clemence_Guette) · X

X (Twitter)

https://twitter.com/Clemence_Guette

X (Twitter)

https://twitter.com/Clemence_Guette

[](https://twitter.com/Clemence_Guette/status/1850114327145038092?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Etweet)

[](https://twitter.com/Clemence_Guette/status/1850114327145038092?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Etweet)

Il y a 10 ans, la répression tuait Rémi Fraisse. Depuis, l\'État s\'est montré toujours plus violent face aux mobilisations écologistes. Mais le combat pour l\'eau bien commun et la protection du seul écosystème compatible avec la vie humaine finira par gagner.

Publié sur X · il y a 1 jour

[](https://twitter.com/Clemence_Guette/status/1849860720432910665?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Etweet)

[](https://twitter.com/Clemence_Guette/status/1849860720432910665?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Etweet)

Vous dites que vous avez une ambition écologique. Je ne vous crois pas. Vous avez une occasion de le prouver : il faut mettre fin à la niche fiscale sur le kérosène. Pour une écologie populaire.

Publié sur X · il y a 2 jours

[](https://twitter.com/Clemence_Guette/status/1849841892311134606?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Etweet)

[](https://twitter.com/Clemence_Guette/status/1849841892311134606?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Etweet)

VICTOIRE ! Nous venons de faire annuler la hausse de la taxe sur l\'électricité. La Macronie et son alliance sont à bout de souffle. Tous les jours, présents pour vous défendre.

Publié sur X · il y a 2 jours

[](https://twitter.com/Clemence_Guette/status/1849834244907897107?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Etweet)

[](https://twitter.com/Clemence_Guette/status/1849834244907897107?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Etweet)

163 secouristes et soignants ont été tués par l'armée de Netanyahou au Liban en un an. Rendons hommage à leur courage et à leur dévouement. Au cœur des massacres et du génocide, ils sont l\'honneur de l\'humanité.

Publié sur X · il y a 2 jours

[](https://twitter.com/Clemence_Guette/status/1849792278832816167?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Etweet)

[](https://twitter.com/Clemence_Guette/status/1849792278832816167?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Etweet)

Écoutez bien. Nous avons adopté un impôt exceptionnel sur 147 milliardaires pour éviter aux Français de payer. Ce député RN reproche à ses alliés macronistes de ne pas être assez présents pour l\'empêcher. Le RN, dernier soutien de la Macronie.

Publié sur X · il y a 2 jours

[](https://twitter.com/Clemence_Guette?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor)

Afficher sur X

[\
](https://fr.wikipedia.org/wiki/Cl%C3%A9mence)

### Clémence

Wikipédia

https://fr.wikipedia.org › wiki › Clémence

Wikipédia

https://fr.wikipedia.org › wiki › Clémence

La *clémence* est un terme utilisé pour décrire la paix, la compassion ou la miséricorde montrée par une personne vis-à-vis d\'une autre, ou une requête d\'une \...

[\
](https://dictionnaire.lerobert.com/definition/clemence)

### clémence - Définitions, synonymes, prononciation, exemples

Dico en ligne Le Robert

https://dictionnaire.lerobert.com › definition › clemence

Dico en ligne Le Robert

https://dictionnaire.lerobert.com › definition › clemence

littéraire Vertu qui consiste, de la part de qui dispose d\'une autorité, à pardonner les offenses et à adoucir les châtiments. ➙ indulgence, magnanimité.

[\
](https://www.instagram.com/clemdelacreeme/?hl=fr)

### Clémence (@clemdelacreeme)

Instagram · clemdelacreeme

Plus de 266,4 k abonnés

Instagram · clemdelacreeme

Plus de 266,4 k abonnés

266K Followers, 1410 Following, 1227 Posts - *Clémence* (@clemdelacreeme) on Instagram: \"comme ci comme ça clem@journey-studio.com\"

[](https://www.google.com/search?q=Cl%C3%A9mence&sca_esv=aa46f2d90d76e83e&udm=2&source=univ&ictx=2&sa=X&ved=2ahUKEwipkL-9xq6JAxW-UaQEHbzvCQgQw_oBegQIdxAC)

Images

![Clémence Saint-Preux --- Wikipédia]()

![Clémence Bringtown - La biographie de Clémence Bringtown \...]()

![Clémence Botino révèle que le noir était interdit dans les tenues des Miss France]()

![Clémence Castel - La biographie de Clémence Castel avec Gala.fr]()

[\
](https://www.instagram.com/clemenceandanna/?hl=fr)

### 𝗖𝗹𝗲𝗺𝗲𝗻𝗰𝗲 ☾ (@clemenceandanna)

Instagram · clemenceandanna

Plus de 529,8 k abonnés

Instagram · clemenceandanna

Plus de 529,8 k abonnés

530K Followers, 397 Following, 925 Posts - *Clemence* ☾ (@clemenceandanna) on Instagram: \" Une petite frenchy à Miami Ginette caniche toy Robert spitz \...

‎[Après 15 jours à Miami\...](https://www.instagram.com/clemenceandanna/p/C0XOOOPuILk/) · ‎[Love](https://www.instagram.com/clemenceandanna/p/Cv3kubIOq0X/) · ‎[𝗖𝗹𝗲𝗺𝗲𝗻𝗰𝗲](https://www.instagram.com/clemenceandanna/reel/C6tquNoL5TM/) · ‎[𝗖𝗹𝗲𝗺𝗲𝗻𝗰𝗲 ☾ \| 🤣 PRANK\...](https://www.instagram.com/clemenceandanna/reel/CqJRA42jIBV/)

[\
](https://www.linternaute.fr/dictionnaire/fr/definition/clemence/)

### Clémence : Définition simple et facile du dictionnaire

Linternaute.com

https://www.linternaute.fr › Dictionnaire

Linternaute.com

https://www.linternaute.fr › Dictionnaire

23 mars 2024 --- Vertu qui consiste à pardonner les méfaits. Synonyme : miséricorde, indulgence. Traduction en anglais : clemency. Sens 2.

[\
](https://www.cnrtl.fr/definition/cl%C3%A9mence)

### Définition de CLÉMENCE

cnrtl.fr

https://www.cnrtl.fr › definition › clémence

cnrtl.fr

https://www.cnrtl.fr › definition › clémence

B.− Au fig. \[En parlant du temps qu\'il fait\] Douceur favorable. La *clémence* du temps; la *clémence* du mois de novembre : 2.

[\
](https://nominis.cef.fr/contenus/prenom/1090/Cl%C3%A9mence.html)

### Prénom Clémence

Nominis

https://nominis.cef.fr › contenus › prenom › Clémence

Nominis

https://nominis.cef.fr › contenus › prenom › Clémence

*Clémence*. Prénom féminin. Etymologie latine : \"clemens\", bonté. Formes dérivées du prénom. Clémentia · Clémentine · Mencia. Statistiques.

Recherches associées

[](https://www.google.com/search?sca_esv=aa46f2d90d76e83e&q=Cl%C3%A9mence+pr%C3%A9nom&sa=X&ved=2ahUKEwipkL-9xq6JAxW-UaQEHbzvCQgQ1QJ6BAhsEAE)

Clémence **prénom**

[](https://www.google.com/search?sca_esv=aa46f2d90d76e83e&q=Cl%C3%A9mence+Synonyme&sa=X&ved=2ahUKEwipkL-9xq6JAxW-UaQEHbzvCQgQ1QJ6BAhlEAE)

Clémence **Synonyme**

[](https://www.google.com/search?sca_esv=aa46f2d90d76e83e&q=La+cl%C3%A9mence+D%C3%A9finition&sa=X&ved=2ahUKEwipkL-9xq6JAxW-UaQEHbzvCQgQ1QJ6BAhfEAE)

**La** clémence **Définition**

[](https://www.google.com/search?sca_esv=aa46f2d90d76e83e&q=Cl%C3%A9mence+en+arabe&sa=X&ved=2ahUKEwipkL-9xq6JAxW-UaQEHbzvCQgQ1QJ6BAhXEAE)

Clémence **en arabe**

[](https://www.google.com/search?sca_esv=aa46f2d90d76e83e&q=Comment+prononcer+Clemence&sa=X&ved=2ahUKEwipkL-9xq6JAxW-UaQEHbzvCQgQ1QJ6BAhWEAE)

**Comment prononcer Clemence**

[](https://www.google.com/search?sca_esv=aa46f2d90d76e83e&q=Faire+preuve+de+cl%C3%A9mence&sa=X&ved=2ahUKEwipkL-9xq6JAxW-UaQEHbzvCQgQ1QJ6BAhUEAE)

**Faire preuve de** clémence

[](https://www.google.com/search?sca_esv=aa46f2d90d76e83e&q=Cl%C3%A9mence+Guett%C3%A9&sa=X&ved=2ahUKEwipkL-9xq6JAxW-UaQEHbzvCQgQ1QJ6BAhSEAE)

Clémence **Guetté**

[](https://www.google.com/search?sca_esv=aa46f2d90d76e83e&q=Cl%C3%A9mence+en+anglais&sa=X&ved=2ahUKEwipkL-9xq6JAxW-UaQEHbzvCQgQ1QJ6BAhQEAE)

Clémence **en anglais**

# Principaux résultats

## Chargement...

Une erreur s\'est produite.

RÉESSAYER

# Principaux résultats

## Chargement...

Une erreur s\'est produite.

RÉESSAYER

# Navigation par pages

  -- --- ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ -----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
     1   [2](https://www.google.com/search?q=Cl%C3%A9mence&sca_esv=aa46f2d90d76e83e&ei=gjAeZ6nHEL6jkdUPvN-nQA&start=10&sa=N&sstk=AagrsuhED5nfmnDFbyRKXDzZ1WxI-pEA5sxuogrn0O77W_jZdTjlJGKmD1TvccBWBKMe9BGZP_FPCCR0wJymo01VIfd8msEetMA_PA&ved=2ahUKEwipkL-9xq6JAxW-UaQEHbzvCQgQ8tMDegQIEhAE)   [3](https://www.google.com/search?q=Cl%C3%A9mence&sca_esv=aa46f2d90d76e83e&ei=gjAeZ6nHEL6jkdUPvN-nQA&start=20&sa=N&sstk=AagrsuhED5nfmnDFbyRKXDzZ1WxI-pEA5sxuogrn0O77W_jZdTjlJGKmD1TvccBWBKMe9BGZP_FPCCR0wJymo01VIfd8msEetMA_PA&ved=2ahUKEwipkL-9xq6JAxW-UaQEHbzvCQgQ8tMDegQIEhAG)   [4](https://www.google.com/search?q=Cl%C3%A9mence&sca_esv=aa46f2d90d76e83e&ei=gjAeZ6nHEL6jkdUPvN-nQA&start=30&sa=N&sstk=AagrsuhED5nfmnDFbyRKXDzZ1WxI-pEA5sxuogrn0O77W_jZdTjlJGKmD1TvccBWBKMe9BGZP_FPCCR0wJymo01VIfd8msEetMA_PA&ved=2ahUKEwipkL-9xq6JAxW-UaQEHbzvCQgQ8tMDegQIEhAI)   [5](https://www.google.com/search?q=Cl%C3%A9mence&sca_esv=aa46f2d90d76e83e&ei=gjAeZ6nHEL6jkdUPvN-nQA&start=40&sa=N&sstk=AagrsuhED5nfmnDFbyRKXDzZ1WxI-pEA5sxuogrn0O77W_jZdTjlJGKmD1TvccBWBKMe9BGZP_FPCCR0wJymo01VIfd8msEetMA_PA&ved=2ahUKEwipkL-9xq6JAxW-UaQEHbzvCQgQ8tMDegQIEhAK)   [6](https://www.google.com/search?q=Cl%C3%A9mence&sca_esv=aa46f2d90d76e83e&ei=gjAeZ6nHEL6jkdUPvN-nQA&start=50&sa=N&sstk=AagrsuhED5nfmnDFbyRKXDzZ1WxI-pEA5sxuogrn0O77W_jZdTjlJGKmD1TvccBWBKMe9BGZP_FPCCR0wJymo01VIfd8msEetMA_PA&ved=2ahUKEwipkL-9xq6JAxW-UaQEHbzvCQgQ8tMDegQIEhAM)   [7](https://www.google.com/search?q=Cl%C3%A9mence&sca_esv=aa46f2d90d76e83e&ei=gjAeZ6nHEL6jkdUPvN-nQA&start=60&sa=N&sstk=AagrsuhED5nfmnDFbyRKXDzZ1WxI-pEA5sxuogrn0O77W_jZdTjlJGKmD1TvccBWBKMe9BGZP_FPCCR0wJymo01VIfd8msEetMA_PA&ved=2ahUKEwipkL-9xq6JAxW-UaQEHbzvCQgQ8tMDegQIEhAO)   [8](https://www.google.com/search?q=Cl%C3%A9mence&sca_esv=aa46f2d90d76e83e&ei=gjAeZ6nHEL6jkdUPvN-nQA&start=70&sa=N&sstk=AagrsuhED5nfmnDFbyRKXDzZ1WxI-pEA5sxuogrn0O77W_jZdTjlJGKmD1TvccBWBKMe9BGZP_FPCCR0wJymo01VIfd8msEetMA_PA&ved=2ahUKEwipkL-9xq6JAxW-UaQEHbzvCQgQ8tMDegQIEhAQ)   [9](https://www.google.com/search?q=Cl%C3%A9mence&sca_esv=aa46f2d90d76e83e&ei=gjAeZ6nHEL6jkdUPvN-nQA&start=80&sa=N&sstk=AagrsuhED5nfmnDFbyRKXDzZ1WxI-pEA5sxuogrn0O77W_jZdTjlJGKmD1TvccBWBKMe9BGZP_FPCCR0wJymo01VIfd8msEetMA_PA&ved=2ahUKEwipkL-9xq6JAxW-UaQEHbzvCQgQ8tMDegQIEhAS)   [10](https://www.google.com/search?q=Cl%C3%A9mence&sca_esv=aa46f2d90d76e83e&ei=gjAeZ6nHEL6jkdUPvN-nQA&start=90&sa=N&sstk=AagrsuhED5nfmnDFbyRKXDzZ1WxI-pEA5sxuogrn0O77W_jZdTjlJGKmD1TvccBWBKMe9BGZP_FPCCR0wJymo01VIfd8msEetMA_PA&ved=2ahUKEwipkL-9xq6JAxW-UaQEHbzvCQgQ8tMDegQIEhAU)   [Suivant](https://www.google.com/search?q=Cl%C3%A9mence&sca_esv=aa46f2d90d76e83e&ei=gjAeZ6nHEL6jkdUPvN-nQA&start=10&sa=N&sstk=AagrsuhED5nfmnDFbyRKXDzZ1WxI-pEA5sxuogrn0O77W_jZdTjlJGKmD1TvccBWBKMe9BGZP_FPCCR0wJymo01VIfd8msEetMA_PA&ved=2ahUKEwipkL-9xq6JAxW-UaQEHbzvCQgQ8NMDegQIEhAW)
  -- --- ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ -----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------