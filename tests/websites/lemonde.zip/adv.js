((w,d)=>{
    var s='script',
    f = d.getElementsByTagName(s)[0],
    j = d.createElement(s),
    u = "https://btloader.com/tag?o=5756097762689024&upapi=true";
    j.async = true;
    j.src = u;
    f.parentNode.insertBefore(j,f);
})(window, document);