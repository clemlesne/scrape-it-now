Manage privacy preferences

We and our vendors use cookies and similar methods to recognize visitors and remember their preferences, for analytics, to measure our marketing effectiveness and to target and measure the effectiveness of ads, among other things. To learn more about these methods, view our [Cookie Policy](https://www.nytimes.com/privacy/cookie-policy) and [Privacy Policy](https://help.nytimes.com/hc/en-us/articles/10940941449492). By clicking 'Accept all,' you consent to the processing of your data by us and our vendors using the above methods. You can always change your preferences by clicking on Manage Privacy Preferences in our website footer or in your app Privacy Settings. Your preferences here are unrelated to Apple's App Tracking Transparency Framework.

Vendors

344

Vendors using consent 316

Vendors using legitimate interest 82

Precise geolocation data, and identification through device scanning

Precise geolocation and information about device characteristics can be used.

Personalised advertising, advertising measurement, audience research and services development

Advertising can be personalised based on your profile. Your activity on this service can be used to build or improve a profile about you for personalised advertising. Advertising performance can be measured. Reports can be generated based on your activity and those of others. Your activity on this service can help develop and improve products and services.

Purposes

-   Use limited data to select advertising
-   Create profiles for personalised advertising
-   Use profiles to select personalised advertising
-   Measure advertising performance
-   Understand audiences through statistics or combinations of data from different sources
-   Develop and improve services

Store and/or access information on a device

Cookies, device or similar online identifiers (e.g. login-based identifiers, randomly assigned identifiers, network based identifiers) together with other information (e.g. browser type and information, language, screen size, supported technologies etc.) can be stored or read on your device to recognise it each time it connects to an app or to a website, for one or several of the purposes presented here.

Reject all

Accept all

English

Español

Manage preferences

Manage Privacy Preferences

We and our vendors use cookies and similar methods ("Cookies") to recognize visitors and remember their preferences. We also use them for a variety of purposes, including analytics, to measure marketing effectiveness and to target and measure the effectiveness of ads. You can accept or reject the use of Cookies for individual purposes below. If you previously accepted these methods through our prior banner, then we will use your data for targeting. Your preferences here are unrelated to Apple's App Tracking Transparency Framework.

-   Purposes
-   Features
-   Vendors

Below, you will find a list of the purposes and special features for which your data is being processed. You may exercise your rights for specific purposes, based on consent or legitimate interest, using the toggles below.

Consent

Legitimate interest

Purposes

Store and/or access information on a device

On

Cookies, device or similar online identifiers (e.g. login-based identifiers, randomly assigned identifiers, network based identifiers) together with other information (e.g. browser type and information, language, screen size, supported technologies etc.) can be stored or read on your device to recognise it each time it connects to an app or to a website, for one or several of the purposes presented here.

Most purposes explained in this notice rely on the storage or accessing of information from your device when you use an app or visit a website. For example, a vendor or publisher might need to store a cookie on your device during your first visit on a website, to be able to recognise your device during your next visits (by accessing this cookie each time).

Vendors178 vendor(s)

-   6sense
-   A.Mob
-   ADventori
-   Aarki
-   AcuityAds
-   AdElement Media Solutions
-   AdGear
-   AdKernel
-   AdSpirit AdServer
-   AdTheorent

1-10 / 178

Use limited data to select advertising

On

Advertising presented to you on this service can be based on limited data, such as the website or app you are using, your non-precise location, your device type or which content you are (or have been) interacting with (for example, to limit the number of times an ad is presented to you).

A car manufacturer wants to promote its electric vehicles to environmentally conscious users living in the city after office hours. The advertising is presented on a page with related content (such as an article on climate change actions) after 6:30 p.m. to users whose non-precise location suggests that they are in an urban zone.

A large producer of watercolour paints wants to carry out an online advertising campaign for its latest watercolour range, diversifying its audience to reach as many amateur and professional artists as possible and avoiding showing the ad next to mismatched content (for instance, articles about how to paint your house). The number of times that the ad has been presented to you is detected and limited, to avoid presenting it too often.

Vendors43 vendor(s)

-   6sense
-   AcuityAds
-   AdGear
-   AdKernel
-   Adform
-   Advanced store
-   Amazon Ad Server
-   Appier
-   AudienceProject
-   Bannernow

1-10 / 43

Create profiles for personalised advertising

On

Information about your activity on this service (such as forms you submit, content you look at) can be stored and combined with other information about you (for example, information from your previous activity on this service and other websites or apps) or similar users. This is then used to build or improve a profile about you (that might include possible interests and personal aspects). Your profile can be used (also later) to present advertising that appears more relevant based on your possible interests by this and other entities.

If you read several articles about the best bike accessories to buy, this information could be used to create a profile about your interest in bike accessories. Such a profile may be used or improved later on, on the same or a different website or app to present you with advertising for a particular bike accessory brand. If you also look at a configurator for a vehicle on a luxury car manufacturer website, this information could be combined with your interest in bikes to refine your profile and make an assumption that you are interested in luxury cycling gear.

An apparel company wishes to promote its new line of high-end baby clothes. It gets in touch with an agency that has a network of clients with high income customers (such as high-end supermarkets) and asks the agency to create profiles of young parents or couples who can be assumed to be wealthy and to have a new child, so that these can later be used to present advertising within partner apps based on those profiles.

Vendors131 vendor(s)

-   6sense
-   A.Mob
-   Aarki
-   AcuityAds
-   AdElement Media Solutions
-   AdGear
-   AdKernel
-   AdSpirit AdServer
-   AdTheorent
-   AdTiming

1-10 / 131

Use profiles to select personalised advertising

On

Advertising presented to you on this service can be based on your advertising profiles, which can reflect your activity on this service or other websites or apps (like the forms you submit, content you look at), possible interests and personal aspects.

An online retailer wants to advertise a limited sale on running shoes. It wants to target advertising to users who previously looked at running shoes on its mobile app. Tracking technologies might be used to recognise that you have previously used the mobile app to consult running shoes, in order to present you with the corresponding advertisement on the app.

A profile created for personalised advertising in relation to a person having searched for bike accessories on a website can be used to present the relevant advertisement for bike accessories on a mobile app of another organisation.

Vendors128 vendor(s)

-   6sense
-   A.Mob
-   ADventori
-   Aarki
-   AcuityAds
-   AdElement Media Solutions
-   AdGear
-   AdKernel
-   AdSpirit AdServer
-   AdTheorent

1-10 / 128

Measure advertising performance

On

Information regarding which advertising is presented to you and how you interact with it can be used to determine how well an advert has worked for you or other users and whether the goals of the advertising were reached. For instance, whether you saw an ad, whether you clicked on it, whether it led you to buy a product or visit a website, etc. This is very helpful to understand the relevance of advertising campaigns.

You have clicked on an advertisement about a "black Friday" discount by an online shop on the website of a publisher and purchased a product. Your click will be linked to this purchase. Your interaction and that of other users will be measured to know how many clicks on the ad led to a purchase.

You are one of very few to have clicked on an advertisement about an "international appreciation day" discount by an online gift shop within the app of a publisher. The publisher wants to have reports to understand how often a specific ad placement within the app, and notably the "international appreciation day" ad, has been viewed or clicked by you and other users, in order to help the publisher and its partners (such as agencies) optimise ad placements.

Vendors78 vendor(s)

-   6sense
-   Aarki
-   AcuityAds
-   AdGear
-   AdKernel
-   Adelaide
-   Adform
-   Adikteev
-   Adloox
-   Adnami

1-10 / 78

Understand audiences through statistics or combinations of data from different sources

On

Reports can be generated based on the combination of data sets (like user profiles, statistics, market research, analytics data) regarding your interactions and those of other users with advertising or (non-advertising) content to identify common characteristics (for instance, to determine which target audiences are more receptive to an ad campaign or to certain contents).

The owner of an online bookstore wants commercial reporting showing the proportion of visitors who consulted and left its site without buying, or consulted and bought the last celebrity autobiography of the month, as well as the average age and the male/female distribution of each category. Data relating to your navigation on its site and to your personal characteristics is then used and combined with other such data to produce these statistics.

An advertiser wants to better understand the type of audience interacting with its adverts. It calls upon a research institute to compare the characteristics of users who interacted with the ad with typical attributes of users of similar platforms, across different devices. This comparison reveals to the advertiser that its ad audience is mainly accessing the adverts through mobile devices and is likely in the 45-60 age range.

Vendors29 vendor(s)

-   AdGear
-   Amazon Ad Server
-   Amobee (Nexxen)
-   Appier
-   AudienceProject
-   Bombora
-   Clinch
-   Crimtan
-   Emerse
-   Google Ads

1-10 / 29

Develop and improve services

On

Information about your activity on this service, such as your interaction with ads or content, can be very helpful to improve products and services and to build new products and services based on user interactions, the type of audience, etc. This specific purpose does not include the development or improvement of user profiles and identifiers.

A technology platform working with a social media provider notices a growth in mobile app users, and sees based on their profiles that many of them are connecting through mobile connections. It uses a new technology to deliver ads that are formatted for mobile devices and that are low-bandwidth, to improve their performance.

An advertiser is looking for a way to display ads on a new type of consumer device. It collects information regarding the way users interact with this new kind of device to determine whether it can build a new mechanism for displaying advertising on this type of device.

Vendors50 vendor(s)

-   6sense
-   Aarki
-   AcuityAds
-   AdGear
-   Adelaide
-   Adform
-   Admixer
-   Amazon Ad Server
-   Amobee (Nexxen)
-   Appier

1-10 / 50

Below, you will find a list of the features for which your data is being processed. You may exercise your rights for special features using the toggles below.

Features

Match and combine data from other data sources

Information about your activity on this service may be matched and combined with other information relating to you and originating from various sources (for instance your activity on a separate online service, your use of a loyalty card in-store, or your answers to a survey), in support of the purposes explained in this notice.

Vendors110 vendor(s)

-   6sense
-   A.Mob
-   ABCS INSIGHTS
-   AdGear
-   AdTheorent
-   Adara (Rate Gain)
-   Adelaide
-   Adex (Virtual Minds)
-   Adform
-   Admixer

1-10 / 110

Link different devices

In support of the purposes explained in this notice, your device might be considered as likely linked to other devices that belong to you or your household (for instance because you are logged in to the same service on both your phone and your computer, or because you may use the same Internet connection on both devices).

Vendors110 vendor(s)

-   6sense
-   A.Mob
-   AcuityAds
-   AdElement Media Solutions
-   AdGear
-   AdTheorent
-   Adara (Rate Gain)
-   Adex (Virtual Minds)
-   Adform
-   Adikteev

1-10 / 110

Identify devices based on information transmitted automatically

Your device might be distinguished from other devices based on information it automatically sends when accessing the Internet (for instance, the IP address of your Internet connection or the type of browser you are using) in support of the purposes exposed in this notice.

Vendors128 vendor(s)

-   6sense
-   A.Mob
-   Aarki
-   AdElement Media Solutions
-   AdGear
-   AdKernel
-   AdSpirit AdServer
-   AdTheorent
-   Adacado
-   Adara (Rate Gain)

1-10 / 128

Special features

Use precise geolocation data

On

With your acceptance, your precise location (within a radius of less than 500 metres) may be used in support of the purposes explained in this notice.

Vendors66 vendor(s)

-   A.Mob
-   AdElement Media Solutions
-   AdGear
-   AdKernel
-   AdTheorent
-   Adacado
-   Admixer
-   Adrule mobile
-   AdsWizz
-   Airtory Inc

1-10 / 66

Actively scan device characteristics for identification

On

With your acceptance, certain characteristics specific to your device might be requested and used to distinguish it from other devices (such as the installed fonts or plugins, the resolution of your screen) in support of the purposes explained in this notice.

Vendors24 vendor(s)

-   A.Mob
-   AdKernel
-   AdTheorent
-   Adcell (Firstlead)
-   Cheq
-   Clickagy
-   Dentsu Product &amp; Services GmbH
-   Fraudlogix
-   Human
-   Hybrid

1-10 / 24

Below, you will find a list of vendors processing your data and the purposes or features of processing they declare. You may exercise your rights for each vendor based on the legal basis they assert.

Consent

Legitimate interest

IAB TCF Vendors

6senseIAB TCF

On

6sense stores cookies with a maximum duration of about this many days: 730. This vendor also uses other methods like \"local storage\" to store and access information on your device.

[Privacy policy](https://6sense.com/privacy-policy/)[Legitimate interest disclosure](https://6sense.com/privacy-policy/)

  Purposes                                             Retention
  ------------------------------------------------- ------------
  Store and/or access information on a device         400 day(s)
  Create profiles for personalised advertising        400 day(s)
  Use profiles to select personalised advertising     400 day(s)
  Use limited data to select advertising              400 day(s)
  Measure advertising performance                     400 day(s)
  Develop and improve services                        400 day(s)

  Special purposes                                               Retention
  ----------------------------------------------------------- ------------
  Ensure security, prevent and detect fraud, and fix errors     400 day(s)
  Deliver and present advertising and content                   400 day(s)

  Features
  -----------------------------------------------------------------
  Match and combine data from other data sources
  Link different devices
  Identify devices based on information transmitted automatically

  Data categories
  -------------------------------
  IP addresses
  Probabilistic identifiers
  Browsing and interaction data
  Non-precise location data
  Users' profiles

A.MobIAB TCF

On

A.Mob stores cookies with a maximum duration of about this many days: 395. This vendor also uses other methods like \"local storage\" to store and access information on your device.

[Privacy policy](https://we-are-adot.com/privacy-policy/)

  Purposes                                                                                    Retention
  ---------------------------------------------------------------------------------------- ------------
  Store and/or access information on a device                                                395 day(s)
  Use limited data to select advertising                                                     395 day(s)
  Create profiles for personalised advertising                                               395 day(s)
  Use profiles to select personalised advertising                                            395 day(s)
  Measure advertising performance                                                            395 day(s)
  Understand audiences through statistics or combinations of data from different sources     395 day(s)
  Develop and improve services                                                               395 day(s)

  Features
  -----------------------------------------------------------------
  Match and combine data from other data sources
  Link different devices
  Identify devices based on information transmitted automatically

  Special features
  ---------------------------------------------------------
  Use precise geolocation data
  Actively scan device characteristics for identification

  Data categories
  ------------------------------------
  IP addresses
  Device characteristics
  Device identifiers
  Probabilistic identifiers
  Authentication-derived identifiers
  Browsing and interaction data
  User-provided data
  Non-precise location data
  Precise location data
  Users' profiles
  Privacy choices

ABCS INSIGHTSIAB TCF

On

[Privacy policy](https://www.abcsinsights.com/privacy/ad-measurement)

  Purposes                                                                                   Retention
  ---------------------------------------------------------------------------------------- -----------
  Measure advertising performance                                                            60 day(s)
  Understand audiences through statistics or combinations of data from different sources     60 day(s)

  Features
  ------------------------------------------------
  Match and combine data from other data sources

  Data categories
  -----------------
  IP addresses

ADventoriIAB TCF

On

ADventori stores cookies with a maximum duration of about this many days: 90. These cookies may be refreshed. This vendor also uses other methods like \"local storage\" to store and access information on your device.

[Privacy policy](https://www.adventori.com/fr/rgpd/)[Legitimate interest disclosure](https://www.adventori.com/fr/rgpd/)

  Purposes                                             Retention
  ------------------------------------------------- ------------
  Store and/or access information on a device                 \-
  Use limited data to select advertising               90 day(s)
  Use profiles to select personalised advertising      90 day(s)
  Measure advertising performance                     400 day(s)

  Special purposes                                               Retention
  ----------------------------------------------------------- ------------
  Ensure security, prevent and detect fraud, and fix errors     400 day(s)
  Deliver and present advertising and content                   400 day(s)
  Save and communicate privacy choices                           90 day(s)

  Data categories
  -------------------------------
  IP addresses
  Device identifiers
  Probabilistic identifiers
  Browsing and interaction data
  User-provided data
  Non-precise location data
  Privacy choices

AarkiIAB TCF

On

uses methods like \"local storage\" to store and access information on your device.

[Privacy policy](https://corp.aarki.com/privacy)[Legitimate interest disclosure](https://corp.aarki.com/privacy)

  Purposes                                              Retention
  ------------------------------------------------- -------------
  Store and/or access information on a device          365 day(s)
  Use limited data to select advertising               365 day(s)
  Create profiles for personalised advertising        3650 day(s)
  Use profiles to select personalised advertising     3650 day(s)
  Measure advertising performance                     1500 day(s)
  Develop and improve services                         365 day(s)

  Special purposes                                               Retention
  ----------------------------------------------------------- ------------
  Ensure security, prevent and detect fraud, and fix errors     365 day(s)
  Deliver and present advertising and content                   365 day(s)

  Features
  -----------------------------------------------------------------
  Identify devices based on information transmitted automatically

  Data categories
  ---------------------------
  IP addresses
  Device characteristics
  Device identifiers
  User-provided data
  Non-precise location data

AcuityAdsIAB TCF

On

AcuityAds stores cookies with a maximum duration of about this many days: 365. These cookies may be refreshed.

[Privacy policy](https://privacy.acuityads.com/corporate-privacy-policy.html)[Legitimate interest disclosure](https://privacy.acuityads.com/corporate-privacy-policy.html)

  Purposes                                             Retention
  ------------------------------------------------- ------------
  Store and/or access information on a device         180 day(s)
  Create profiles for personalised advertising        180 day(s)
  Use profiles to select personalised advertising     180 day(s)
  Use limited data to select advertising              180 day(s)
  Measure advertising performance                     180 day(s)
  Develop and improve services                        180 day(s)

  Special purposes                                               Retention
  ----------------------------------------------------------- ------------
  Ensure security, prevent and detect fraud, and fix errors     180 day(s)
  Deliver and present advertising and content                   180 day(s)
  Save and communicate privacy choices                          180 day(s)

  Features
  ------------------------
  Link different devices

  Data categories
  ------------------------------------
  IP addresses
  Device characteristics
  Device identifiers
  Authentication-derived identifiers
  Browsing and interaction data
  Non-precise location data
  Users' profiles
  Privacy choices

AdElement Media SolutionsIAB TCF

On

AdElement Media Solutions stores cookies with a maximum duration of about this many days: 365. These cookies may be refreshed.

[Privacy policy](http://adelement.com/privacy-policy.html)[Legitimate interest disclosure](https://adelement.com/privacy-policy.html#legal-basis-processing)

  Purposes                                                                                    Retention
  ---------------------------------------------------------------------------------------- ------------
  Store and/or access information on a device                                                180 day(s)
  Use limited data to select advertising                                                     180 day(s)
  Create profiles for personalised advertising                                                90 day(s)
  Use profiles to select personalised advertising                                             90 day(s)
  Measure advertising performance                                                            180 day(s)
  Understand audiences through statistics or combinations of data from different sources      90 day(s)
  Develop and improve services                                                               180 day(s)

  Special purposes                                               Retention
  ----------------------------------------------------------- ------------
  Ensure security, prevent and detect fraud, and fix errors     180 day(s)
  Deliver and present advertising and content                   180 day(s)
  Save and communicate privacy choices                          180 day(s)

  Features
  -----------------------------------------------------------------
  Link different devices
  Identify devices based on information transmitted automatically

  Special features
  ------------------------------
  Use precise geolocation data

  Data categories
  -------------------------------
  IP addresses
  Device characteristics
  Device identifiers
  Browsing and interaction data
  User-provided data
  Non-precise location data
  Precise location data
  Users' profiles
  Privacy choices

AdGearIAB TCF

On

AdGear stores cookies with a maximum duration of about this many days: 395. This vendor also uses other methods like \"local storage\" to store and access information on your device.

[Privacy policy](https://samsungads.ca/en/privacy/)[Legitimate interest disclosure](https://samsungads.ca/en/privacy/english-eu/#legal)

  Purposes                                                                                    Retention
  ---------------------------------------------------------------------------------------- ------------
  Store and/or access information on a device                                                395 day(s)
  Create profiles for personalised advertising                                               395 day(s)
  Use profiles to select personalised advertising                                            395 day(s)
  Use limited data to select advertising                                                     395 day(s)
  Measure advertising performance                                                            395 day(s)
  Understand audiences through statistics or combinations of data from different sources     395 day(s)
  Develop and improve services                                                               395 day(s)

  Special purposes                                               Retention
  ----------------------------------------------------------- ------------
  Ensure security, prevent and detect fraud, and fix errors     395 day(s)
  Deliver and present advertising and content                   395 day(s)
  Save and communicate privacy choices                          730 day(s)

  Features
  -----------------------------------------------------------------
  Match and combine data from other data sources
  Link different devices
  Identify devices based on information transmitted automatically

  Special features
  ------------------------------
  Use precise geolocation data

  Data categories
  ------------------------------------
  IP addresses
  Device characteristics
  Device identifiers
  Probabilistic identifiers
  Authentication-derived identifiers
  Browsing and interaction data
  User-provided data
  Non-precise location data
  Users' profiles
  Privacy choices

AdKernelIAB TCF

On

AdKernel stores cookies with a maximum duration of about this many days: 18. These cookies may be refreshed.

[Privacy policy](https://adkernel.com/privacy-policy/)[Legitimate interest disclosure](https://adkernel.com/privacy-policy/)

  Purposes                                                                                    Retention
  ---------------------------------------------------------------------------------------- ------------
  Store and/or access information on a device                                                180 day(s)
  Create profiles for personalised advertising                                               180 day(s)
  Use profiles to select personalised advertising                                            180 day(s)
  Understand audiences through statistics or combinations of data from different sources     180 day(s)
  Develop and improve services                                                               180 day(s)
  Use limited data to select advertising                                                     180 day(s)
  Measure advertising performance                                                            180 day(s)

  Special purposes                                               Retention
  ----------------------------------------------------------- ------------
  Ensure security, prevent and detect fraud, and fix errors     180 day(s)
  Deliver and present advertising and content                   180 day(s)
  Save and communicate privacy choices                          180 day(s)

  Features
  -----------------------------------------------------------------
  Identify devices based on information transmitted automatically

  Special features
  ---------------------------------------------------------
  Use precise geolocation data
  Actively scan device characteristics for identification

  Data categories
  ---------------------------
  IP addresses
  Device identifiers
  Non-precise location data
  Precise location data
  Users' profiles

AdSpirit AdServerIAB TCF

On

AdSpirit AdServer stores cookies with a maximum duration of about this many days: 30. These cookies may be refreshed.

[Privacy policy](https://help.adspirit.de/privacy.php)[Legitimate interest disclosure](https://help.adspirit.de/privacy.php)

  Purposes                                                                                   Retention
  ---------------------------------------------------------------------------------------- -----------
  Store and/or access information on a device                                                60 day(s)
  Use limited data to select advertising                                                     14 day(s)
  Create profiles for personalised advertising                                               60 day(s)
  Use profiles to select personalised advertising                                            60 day(s)
  Measure advertising performance                                                            14 day(s)
  Understand audiences through statistics or combinations of data from different sources     60 day(s)

  Special purposes                                              Retention
  ----------------------------------------------------------- -----------
  Ensure security, prevent and detect fraud, and fix errors     60 day(s)
  Deliver and present advertising and content                   60 day(s)

  Features
  -----------------------------------------------------------------
  Identify devices based on information transmitted automatically

  Data categories
  -------------------------------
  IP addresses
  Device characteristics
  Device identifiers
  Probabilistic identifiers
  Browsing and interaction data
  Non-precise location data
  Users' profiles
  Privacy choices

1-10 / 316

Save

Reject all

Accept all

English

Español

Manage privacy preferences

We and our vendors use cookies and similar methods to recognize visitors and remember their preferences, for analytics, to measure our marketing effectiveness and to target and measure the effectiveness of ads, among other things. To learn more about these methods, view our [Cookie Policy](https://www.nytimes.com/privacy/cookie-policy) and [Privacy Policy](https://help.nytimes.com/hc/en-us/articles/10940941449492). By clicking 'Accept all,' you consent to the processing of your data by us and our vendors using the above methods. You can always change your preferences by clicking on Manage Privacy Preferences in our website footer or in your app Privacy Settings. Your preferences here are unrelated to Apple's App Tracking Transparency Framework.

Vendors

344

Vendors using consent 316

Vendors using legitimate interest 82

Precise geolocation data, and identification through device scanning

Precise geolocation and information about device characteristics can be used.

Personalised advertising, advertising measurement, audience research and services development

Advertising can be personalised based on your profile. Your activity on this service can be used to build or improve a profile about you for personalised advertising. Advertising performance can be measured. Reports can be generated based on your activity and those of others. Your activity on this service can help develop and improve products and services.

Purposes

-   Use limited data to select advertising
-   Create profiles for personalised advertising
-   Use profiles to select personalised advertising
-   Measure advertising performance
-   Understand audiences through statistics or combinations of data from different sources
-   Develop and improve services

Store and/or access information on a device

Cookies, device or similar online identifiers (e.g. login-based identifiers, randomly assigned identifiers, network based identifiers) together with other information (e.g. browser type and information, language, screen size, supported technologies etc.) can be stored or read on your device to recognise it each time it connects to an app or to a website, for one or several of the purposes presented here.

Reject all

Accept all

English

Español

Manage preferences

Manage Privacy Preferences

We and our vendors use cookies and similar methods ("Cookies") to recognize visitors and remember their preferences. We also use them for a variety of purposes, including analytics, to measure marketing effectiveness and to target and measure the effectiveness of ads. You can accept or reject the use of Cookies for individual purposes below. If you previously accepted these methods through our prior banner, then we will use your data for targeting. Your preferences here are unrelated to Apple's App Tracking Transparency Framework.

-   Purposes
-   Features
-   Vendors

Below, you will find a list of the purposes and special features for which your data is being processed. You may exercise your rights for specific purposes, based on consent or legitimate interest, using the toggles below.

Consent

Legitimate interest

Purposes

Store and/or access information on a device

Off

Cookies, device or similar online identifiers (e.g. login-based identifiers, randomly assigned identifiers, network based identifiers) together with other information (e.g. browser type and information, language, screen size, supported technologies etc.) can be stored or read on your device to recognise it each time it connects to an app or to a website, for one or several of the purposes presented here.

Most purposes explained in this notice rely on the storage or accessing of information from your device when you use an app or visit a website. For example, a vendor or publisher might need to store a cookie on your device during your first visit on a website, to be able to recognise your device during your next visits (by accessing this cookie each time).

Vendors178 vendor(s)

-   6sense
-   A.Mob
-   ADventori
-   Aarki
-   AcuityAds
-   AdElement Media Solutions
-   AdGear
-   AdKernel
-   AdSpirit AdServer
-   AdTheorent

1-10 / 178

Use limited data to select advertising

Off

Advertising presented to you on this service can be based on limited data, such as the website or app you are using, your non-precise location, your device type or which content you are (or have been) interacting with (for example, to limit the number of times an ad is presented to you).

A car manufacturer wants to promote its electric vehicles to environmentally conscious users living in the city after office hours. The advertising is presented on a page with related content (such as an article on climate change actions) after 6:30 p.m. to users whose non-precise location suggests that they are in an urban zone.

A large producer of watercolour paints wants to carry out an online advertising campaign for its latest watercolour range, diversifying its audience to reach as many amateur and professional artists as possible and avoiding showing the ad next to mismatched content (for instance, articles about how to paint your house). The number of times that the ad has been presented to you is detected and limited, to avoid presenting it too often.

Vendors43 vendor(s)

-   6sense
-   AcuityAds
-   AdGear
-   AdKernel
-   Adform
-   Advanced store
-   Amazon Ad Server
-   Appier
-   AudienceProject
-   Bannernow

1-10 / 43

Create profiles for personalised advertising

Off

Information about your activity on this service (such as forms you submit, content you look at) can be stored and combined with other information about you (for example, information from your previous activity on this service and other websites or apps) or similar users. This is then used to build or improve a profile about you (that might include possible interests and personal aspects). Your profile can be used (also later) to present advertising that appears more relevant based on your possible interests by this and other entities.

If you read several articles about the best bike accessories to buy, this information could be used to create a profile about your interest in bike accessories. Such a profile may be used or improved later on, on the same or a different website or app to present you with advertising for a particular bike accessory brand. If you also look at a configurator for a vehicle on a luxury car manufacturer website, this information could be combined with your interest in bikes to refine your profile and make an assumption that you are interested in luxury cycling gear.

An apparel company wishes to promote its new line of high-end baby clothes. It gets in touch with an agency that has a network of clients with high income customers (such as high-end supermarkets) and asks the agency to create profiles of young parents or couples who can be assumed to be wealthy and to have a new child, so that these can later be used to present advertising within partner apps based on those profiles.

Vendors131 vendor(s)

-   6sense
-   A.Mob
-   Aarki
-   AcuityAds
-   AdElement Media Solutions
-   AdGear
-   AdKernel
-   AdSpirit AdServer
-   AdTheorent
-   AdTiming

1-10 / 131

Use profiles to select personalised advertising

Off

Advertising presented to you on this service can be based on your advertising profiles, which can reflect your activity on this service or other websites or apps (like the forms you submit, content you look at), possible interests and personal aspects.

An online retailer wants to advertise a limited sale on running shoes. It wants to target advertising to users who previously looked at running shoes on its mobile app. Tracking technologies might be used to recognise that you have previously used the mobile app to consult running shoes, in order to present you with the corresponding advertisement on the app.

A profile created for personalised advertising in relation to a person having searched for bike accessories on a website can be used to present the relevant advertisement for bike accessories on a mobile app of another organisation.

Vendors128 vendor(s)

-   6sense
-   A.Mob
-   ADventori
-   Aarki
-   AcuityAds
-   AdElement Media Solutions
-   AdGear
-   AdKernel
-   AdSpirit AdServer
-   AdTheorent

1-10 / 128

Measure advertising performance

Off

Information regarding which advertising is presented to you and how you interact with it can be used to determine how well an advert has worked for you or other users and whether the goals of the advertising were reached. For instance, whether you saw an ad, whether you clicked on it, whether it led you to buy a product or visit a website, etc. This is very helpful to understand the relevance of advertising campaigns.

You have clicked on an advertisement about a "black Friday" discount by an online shop on the website of a publisher and purchased a product. Your click will be linked to this purchase. Your interaction and that of other users will be measured to know how many clicks on the ad led to a purchase.

You are one of very few to have clicked on an advertisement about an "international appreciation day" discount by an online gift shop within the app of a publisher. The publisher wants to have reports to understand how often a specific ad placement within the app, and notably the "international appreciation day" ad, has been viewed or clicked by you and other users, in order to help the publisher and its partners (such as agencies) optimise ad placements.

Vendors78 vendor(s)

-   6sense
-   Aarki
-   AcuityAds
-   AdGear
-   AdKernel
-   Adelaide
-   Adform
-   Adikteev
-   Adloox
-   Adnami

1-10 / 78

Understand audiences through statistics or combinations of data from different sources

Off

Reports can be generated based on the combination of data sets (like user profiles, statistics, market research, analytics data) regarding your interactions and those of other users with advertising or (non-advertising) content to identify common characteristics (for instance, to determine which target audiences are more receptive to an ad campaign or to certain contents).

The owner of an online bookstore wants commercial reporting showing the proportion of visitors who consulted and left its site without buying, or consulted and bought the last celebrity autobiography of the month, as well as the average age and the male/female distribution of each category. Data relating to your navigation on its site and to your personal characteristics is then used and combined with other such data to produce these statistics.

An advertiser wants to better understand the type of audience interacting with its adverts. It calls upon a research institute to compare the characteristics of users who interacted with the ad with typical attributes of users of similar platforms, across different devices. This comparison reveals to the advertiser that its ad audience is mainly accessing the adverts through mobile devices and is likely in the 45-60 age range.

Vendors29 vendor(s)

-   AdGear
-   Amazon Ad Server
-   Amobee (Nexxen)
-   Appier
-   AudienceProject
-   Bombora
-   Clinch
-   Crimtan
-   Emerse
-   Google Ads

1-10 / 29

Develop and improve services

Off

Information about your activity on this service, such as your interaction with ads or content, can be very helpful to improve products and services and to build new products and services based on user interactions, the type of audience, etc. This specific purpose does not include the development or improvement of user profiles and identifiers.

A technology platform working with a social media provider notices a growth in mobile app users, and sees based on their profiles that many of them are connecting through mobile connections. It uses a new technology to deliver ads that are formatted for mobile devices and that are low-bandwidth, to improve their performance.

An advertiser is looking for a way to display ads on a new type of consumer device. It collects information regarding the way users interact with this new kind of device to determine whether it can build a new mechanism for displaying advertising on this type of device.

Vendors50 vendor(s)

-   6sense
-   Aarki
-   AcuityAds
-   AdGear
-   Adelaide
-   Adform
-   Admixer
-   Amazon Ad Server
-   Amobee (Nexxen)
-   Appier

1-10 / 50

Below, you will find a list of the features for which your data is being processed. You may exercise your rights for special features using the toggles below.

Features

Match and combine data from other data sources

Information about your activity on this service may be matched and combined with other information relating to you and originating from various sources (for instance your activity on a separate online service, your use of a loyalty card in-store, or your answers to a survey), in support of the purposes explained in this notice.

Vendors110 vendor(s)

-   6sense
-   A.Mob
-   ABCS INSIGHTS
-   AdGear
-   AdTheorent
-   Adara (Rate Gain)
-   Adelaide
-   Adex (Virtual Minds)
-   Adform
-   Admixer

1-10 / 110

Link different devices

In support of the purposes explained in this notice, your device might be considered as likely linked to other devices that belong to you or your household (for instance because you are logged in to the same service on both your phone and your computer, or because you may use the same Internet connection on both devices).

Vendors110 vendor(s)

-   6sense
-   A.Mob
-   AcuityAds
-   AdElement Media Solutions
-   AdGear
-   AdTheorent
-   Adara (Rate Gain)
-   Adex (Virtual Minds)
-   Adform
-   Adikteev

1-10 / 110

Identify devices based on information transmitted automatically

Your device might be distinguished from other devices based on information it automatically sends when accessing the Internet (for instance, the IP address of your Internet connection or the type of browser you are using) in support of the purposes exposed in this notice.

Vendors128 vendor(s)

-   6sense
-   A.Mob
-   Aarki
-   AdElement Media Solutions
-   AdGear
-   AdKernel
-   AdSpirit AdServer
-   AdTheorent
-   Adacado
-   Adara (Rate Gain)

1-10 / 128

Special features

Use precise geolocation data

Off

With your acceptance, your precise location (within a radius of less than 500 metres) may be used in support of the purposes explained in this notice.

Vendors66 vendor(s)

-   A.Mob
-   AdElement Media Solutions
-   AdGear
-   AdKernel
-   AdTheorent
-   Adacado
-   Admixer
-   Adrule mobile
-   AdsWizz
-   Airtory Inc

1-10 / 66

Actively scan device characteristics for identification

Off

With your acceptance, certain characteristics specific to your device might be requested and used to distinguish it from other devices (such as the installed fonts or plugins, the resolution of your screen) in support of the purposes explained in this notice.

Vendors24 vendor(s)

-   A.Mob
-   AdKernel
-   AdTheorent
-   Adcell (Firstlead)
-   Cheq
-   Clickagy
-   Dentsu Product &amp; Services GmbH
-   Fraudlogix
-   Human
-   Hybrid

1-10 / 24

Below, you will find a list of vendors processing your data and the purposes or features of processing they declare. You may exercise your rights for each vendor based on the legal basis they assert.

Consent

Legitimate interest

IAB TCF Vendors

6senseIAB TCF

Off

6sense stores cookies with a maximum duration of about this many days: 730. This vendor also uses other methods like \"local storage\" to store and access information on your device.

[Privacy policy](https://6sense.com/privacy-policy/)[Legitimate interest disclosure](https://6sense.com/privacy-policy/)

  Purposes                                             Retention
  ------------------------------------------------- ------------
  Store and/or access information on a device         400 day(s)
  Create profiles for personalised advertising        400 day(s)
  Use profiles to select personalised advertising     400 day(s)
  Use limited data to select advertising              400 day(s)
  Measure advertising performance                     400 day(s)
  Develop and improve services                        400 day(s)

  Special purposes                                               Retention
  ----------------------------------------------------------- ------------
  Ensure security, prevent and detect fraud, and fix errors     400 day(s)
  Deliver and present advertising and content                   400 day(s)

  Features
  -----------------------------------------------------------------
  Match and combine data from other data sources
  Link different devices
  Identify devices based on information transmitted automatically

  Data categories
  -------------------------------
  IP addresses
  Probabilistic identifiers
  Browsing and interaction data
  Non-precise location data
  Users' profiles

A.MobIAB TCF

Off

A.Mob stores cookies with a maximum duration of about this many days: 395. This vendor also uses other methods like \"local storage\" to store and access information on your device.

[Privacy policy](https://we-are-adot.com/privacy-policy/)

  Purposes                                                                                    Retention
  ---------------------------------------------------------------------------------------- ------------
  Store and/or access information on a device                                                395 day(s)
  Use limited data to select advertising                                                     395 day(s)
  Create profiles for personalised advertising                                               395 day(s)
  Use profiles to select personalised advertising                                            395 day(s)
  Measure advertising performance                                                            395 day(s)
  Understand audiences through statistics or combinations of data from different sources     395 day(s)
  Develop and improve services                                                               395 day(s)

  Features
  -----------------------------------------------------------------
  Match and combine data from other data sources
  Link different devices
  Identify devices based on information transmitted automatically

  Special features
  ---------------------------------------------------------
  Use precise geolocation data
  Actively scan device characteristics for identification

  Data categories
  ------------------------------------
  IP addresses
  Device characteristics
  Device identifiers
  Probabilistic identifiers
  Authentication-derived identifiers
  Browsing and interaction data
  User-provided data
  Non-precise location data
  Precise location data
  Users' profiles
  Privacy choices

ABCS INSIGHTSIAB TCF

Off

[Privacy policy](https://www.abcsinsights.com/privacy/ad-measurement)

  Purposes                                                                                   Retention
  ---------------------------------------------------------------------------------------- -----------
  Measure advertising performance                                                            60 day(s)
  Understand audiences through statistics or combinations of data from different sources     60 day(s)

  Features
  ------------------------------------------------
  Match and combine data from other data sources

  Data categories
  -----------------
  IP addresses

ADventoriIAB TCF

Off

ADventori stores cookies with a maximum duration of about this many days: 90. These cookies may be refreshed. This vendor also uses other methods like \"local storage\" to store and access information on your device.

[Privacy policy](https://www.adventori.com/fr/rgpd/)[Legitimate interest disclosure](https://www.adventori.com/fr/rgpd/)

  Purposes                                             Retention
  ------------------------------------------------- ------------
  Store and/or access information on a device                 \-
  Use limited data to select advertising               90 day(s)
  Use profiles to select personalised advertising      90 day(s)
  Measure advertising performance                     400 day(s)

  Special purposes                                               Retention
  ----------------------------------------------------------- ------------
  Ensure security, prevent and detect fraud, and fix errors     400 day(s)
  Deliver and present advertising and content                   400 day(s)
  Save and communicate privacy choices                           90 day(s)

  Data categories
  -------------------------------
  IP addresses
  Device identifiers
  Probabilistic identifiers
  Browsing and interaction data
  User-provided data
  Non-precise location data
  Privacy choices

AarkiIAB TCF

Off

uses methods like \"local storage\" to store and access information on your device.

[Privacy policy](https://corp.aarki.com/privacy)[Legitimate interest disclosure](https://corp.aarki.com/privacy)

  Purposes                                              Retention
  ------------------------------------------------- -------------
  Store and/or access information on a device          365 day(s)
  Use limited data to select advertising               365 day(s)
  Create profiles for personalised advertising        3650 day(s)
  Use profiles to select personalised advertising     3650 day(s)
  Measure advertising performance                     1500 day(s)
  Develop and improve services                         365 day(s)

  Special purposes                                               Retention
  ----------------------------------------------------------- ------------
  Ensure security, prevent and detect fraud, and fix errors     365 day(s)
  Deliver and present advertising and content                   365 day(s)

  Features
  -----------------------------------------------------------------
  Identify devices based on information transmitted automatically

  Data categories
  ---------------------------
  IP addresses
  Device characteristics
  Device identifiers
  User-provided data
  Non-precise location data

AcuityAdsIAB TCF

Off

AcuityAds stores cookies with a maximum duration of about this many days: 365. These cookies may be refreshed.

[Privacy policy](https://privacy.acuityads.com/corporate-privacy-policy.html)[Legitimate interest disclosure](https://privacy.acuityads.com/corporate-privacy-policy.html)

  Purposes                                             Retention
  ------------------------------------------------- ------------
  Store and/or access information on a device         180 day(s)
  Create profiles for personalised advertising        180 day(s)
  Use profiles to select personalised advertising     180 day(s)
  Use limited data to select advertising              180 day(s)
  Measure advertising performance                     180 day(s)
  Develop and improve services                        180 day(s)

  Special purposes                                               Retention
  ----------------------------------------------------------- ------------
  Ensure security, prevent and detect fraud, and fix errors     180 day(s)
  Deliver and present advertising and content                   180 day(s)
  Save and communicate privacy choices                          180 day(s)

  Features
  ------------------------
  Link different devices

  Data categories
  ------------------------------------
  IP addresses
  Device characteristics
  Device identifiers
  Authentication-derived identifiers
  Browsing and interaction data
  Non-precise location data
  Users' profiles
  Privacy choices

AdElement Media SolutionsIAB TCF

Off

AdElement Media Solutions stores cookies with a maximum duration of about this many days: 365. These cookies may be refreshed.

[Privacy policy](http://adelement.com/privacy-policy.html)[Legitimate interest disclosure](https://adelement.com/privacy-policy.html#legal-basis-processing)

  Purposes                                                                                    Retention
  ---------------------------------------------------------------------------------------- ------------
  Store and/or access information on a device                                                180 day(s)
  Use limited data to select advertising                                                     180 day(s)
  Create profiles for personalised advertising                                                90 day(s)
  Use profiles to select personalised advertising                                             90 day(s)
  Measure advertising performance                                                            180 day(s)
  Understand audiences through statistics or combinations of data from different sources      90 day(s)
  Develop and improve services                                                               180 day(s)

  Special purposes                                               Retention
  ----------------------------------------------------------- ------------
  Ensure security, prevent and detect fraud, and fix errors     180 day(s)
  Deliver and present advertising and content                   180 day(s)
  Save and communicate privacy choices                          180 day(s)

  Features
  -----------------------------------------------------------------
  Link different devices
  Identify devices based on information transmitted automatically

  Special features
  ------------------------------
  Use precise geolocation data

  Data categories
  -------------------------------
  IP addresses
  Device characteristics
  Device identifiers
  Browsing and interaction data
  User-provided data
  Non-precise location data
  Precise location data
  Users' profiles
  Privacy choices

AdGearIAB TCF

Off

AdGear stores cookies with a maximum duration of about this many days: 395. This vendor also uses other methods like \"local storage\" to store and access information on your device.

[Privacy policy](https://samsungads.ca/en/privacy/)[Legitimate interest disclosure](https://samsungads.ca/en/privacy/english-eu/#legal)

  Purposes                                                                                    Retention
  ---------------------------------------------------------------------------------------- ------------
  Store and/or access information on a device                                                395 day(s)
  Create profiles for personalised advertising                                               395 day(s)
  Use profiles to select personalised advertising                                            395 day(s)
  Use limited data to select advertising                                                     395 day(s)
  Measure advertising performance                                                            395 day(s)
  Understand audiences through statistics or combinations of data from different sources     395 day(s)
  Develop and improve services                                                               395 day(s)

  Special purposes                                               Retention
  ----------------------------------------------------------- ------------
  Ensure security, prevent and detect fraud, and fix errors     395 day(s)
  Deliver and present advertising and content                   395 day(s)
  Save and communicate privacy choices                          730 day(s)

  Features
  -----------------------------------------------------------------
  Match and combine data from other data sources
  Link different devices
  Identify devices based on information transmitted automatically

  Special features
  ------------------------------
  Use precise geolocation data

  Data categories
  ------------------------------------
  IP addresses
  Device characteristics
  Device identifiers
  Probabilistic identifiers
  Authentication-derived identifiers
  Browsing and interaction data
  User-provided data
  Non-precise location data
  Users' profiles
  Privacy choices

AdKernelIAB TCF

Off

AdKernel stores cookies with a maximum duration of about this many days: 18. These cookies may be refreshed.

[Privacy policy](https://adkernel.com/privacy-policy/)[Legitimate interest disclosure](https://adkernel.com/privacy-policy/)

  Purposes                                                                                    Retention
  ---------------------------------------------------------------------------------------- ------------
  Store and/or access information on a device                                                180 day(s)
  Create profiles for personalised advertising                                               180 day(s)
  Use profiles to select personalised advertising                                            180 day(s)
  Understand audiences through statistics or combinations of data from different sources     180 day(s)
  Develop and improve services                                                               180 day(s)
  Use limited data to select advertising                                                     180 day(s)
  Measure advertising performance                                                            180 day(s)

  Special purposes                                               Retention
  ----------------------------------------------------------- ------------
  Ensure security, prevent and detect fraud, and fix errors     180 day(s)
  Deliver and present advertising and content                   180 day(s)
  Save and communicate privacy choices                          180 day(s)

  Features
  -----------------------------------------------------------------
  Identify devices based on information transmitted automatically

  Special features
  ---------------------------------------------------------
  Use precise geolocation data
  Actively scan device characteristics for identification

  Data categories
  ---------------------------
  IP addresses
  Device identifiers
  Non-precise location data
  Precise location data
  Users' profiles

AdSpirit AdServerIAB TCF

Off

AdSpirit AdServer stores cookies with a maximum duration of about this many days: 30. These cookies may be refreshed.

[Privacy policy](https://help.adspirit.de/privacy.php)[Legitimate interest disclosure](https://help.adspirit.de/privacy.php)

  Purposes                                                                                   Retention
  ---------------------------------------------------------------------------------------- -----------
  Store and/or access information on a device                                                60 day(s)
  Use limited data to select advertising                                                     14 day(s)
  Create profiles for personalised advertising                                               60 day(s)
  Use profiles to select personalised advertising                                            60 day(s)
  Measure advertising performance                                                            14 day(s)
  Understand audiences through statistics or combinations of data from different sources     60 day(s)

  Special purposes                                              Retention
  ----------------------------------------------------------- -----------
  Ensure security, prevent and detect fraud, and fix errors     60 day(s)
  Deliver and present advertising and content                   60 day(s)

  Features
  -----------------------------------------------------------------
  Identify devices based on information transmitted automatically

  Data categories
  -------------------------------
  IP addresses
  Device characteristics
  Device identifiers
  Probabilistic identifiers
  Browsing and interaction data
  Non-precise location data
  Users' profiles
  Privacy choices

1-10 / 316

Save

Reject all

Accept all

English

Español

[Skip to content](#site-content)[Skip to site index](#site-index)

[SKIP ADVERTISEMENT](#after-dfp-ad-top)

-   [U.S.](/)
-   [International](/international/)
-   [Canada](/ca/)
-   [Español](https://www.nytimes.com/es/)
-   [中文](https://cn.nytimes.com)

Sunday, October 27, 2024

[Today's Paper](https://www.nytimes.com/section/todayspaper)

[SUBSCRIBE FOR €0.50/WEEK](https://www.nytimes.com/subscription?campaignId=9YU8R)

-   [U.S.](https://www.nytimes.com/section/us)
    ### Sections

    -   [U.S.](https://www.nytimes.com/section/us)
    -   [Politics](https://www.nytimes.com/section/politics)
    -   [New York](https://www.nytimes.com/section/nyregion)
    -   [California](https://www.nytimes.com/spotlight/california-news)
    -   [Education](https://www.nytimes.com/section/education)
    -   [Health](https://www.nytimes.com/section/health)
    -   [Obituaries](https://www.nytimes.com/section/obituaries)
    -   [Science](https://www.nytimes.com/section/science)

    ### 

    -   [Climate](https://www.nytimes.com/section/climate)
    -   [Weather](https://www.nytimes.com/section/weather)
    -   [Sports](https://www.nytimes.com/section/sports)
    -   [Business](https://www.nytimes.com/section/business)
    -   [Tech](https://www.nytimes.com/section/technology)
    -   [The Upshot](https://www.nytimes.com/section/upshot)
    -   [The Magazine](https://www.nytimes.com/section/magazine)

    ### U.S. Politics

    -   [2024 Elections](https://www.nytimes.com/news-event/2024-election)
    -   [President Biden](https://www.nytimes.com/spotlight/joe-biden)
    -   [Donald Trump](https://www.nytimes.com/spotlight/donald-trump)
    -   [Kamala Harris](https://www.nytimes.com/spotlight/kamala-harris)
    -   [Poll Tracker](https://www.nytimes.com/interactive/2024/us/elections/polls-president.html)
    -   [Supreme Court](https://www.nytimes.com/topic/organization/us-supreme-court)
    -   [Congress](https://www.nytimes.com/topic/organization/us-congress)

    ### Top Stories

    -   [Trump Investigations](https://www.nytimes.com/news-event/donald-trump-investigations)
    -   [Immigration](https://www.nytimes.com/news-event/immigration-us)
    -   [Abortion](https://www.nytimes.com/spotlight/abortion-news)

    ### Newsletters

    -   [![The Morning Logo]()](https://www.nytimes.com/newsletters/morning-briefing)
        The Morning

        Make sense of the day's news and ideas.
    -   [![The Upshot Logo]()](https://www.nytimes.com/newsletters/upshot)
        The Upshot

        Analysis that explains politics, policy and everyday life.

    [](https://www.nytimes.com/newsletters)
    See all newsletters

    ### Podcasts

    -   [![The Daily Logo]()](https://www.nytimes.com/column/the-daily)
        The Daily

        The biggest stories of our time, in 20 minutes a day.
    -   [![The Run-Up Logo]()](https://www.nytimes.com/column/election-run-up-podcast)
        The Run-Up

        On the campaign trail with Astead Herndon.

    [](https://www.nytimes.com/spotlight/podcasts)
    See all podcasts
-   [World](https://www.nytimes.com/section/world)

    ### Sections

    -   [World](https://www.nytimes.com/section/world)
    -   [Africa](https://www.nytimes.com/section/world/africa)
    -   [Americas](https://www.nytimes.com/section/world/americas)
    -   [Asia](https://www.nytimes.com/section/world/asia)
    -   [Australia](https://www.nytimes.com/section/world/australia)
    -   [Canada](https://www.nytimes.com/section/world/canada)
    -   [Europe](https://www.nytimes.com/section/world/europe)
    -   [Middle East](https://www.nytimes.com/section/world/middleeast)
    -   [Science](https://www.nytimes.com/section/science)
    -   [Climate](https://www.nytimes.com/section/climate)
    -   [Weather](https://www.nytimes.com/section/weather)
    -   [Health](https://www.nytimes.com/section/health)
    -   [Obituaries](https://www.nytimes.com/section/obituaries)

    ### Top Stories

    -   [Israel-Hamas War](https://www.nytimes.com/news-event/israel-hamas-gaza)
    -   [Russia-Ukraine War](https://www.nytimes.com/news-event/ukraine-russia)

    ### Newsletters

    -   [![Morning Briefing: Europe Logo]()](https://www.nytimes.com/newsletters/morning-briefing-europe)
        Morning Briefing: Europe

        Get what you need to know to start your day.
    -   [![The Interpreter Logo]()](https://www.nytimes.com/newsletters/the-interpreter)
        The Interpreter

        Original analysis on the week's biggest global stories.

    ### 

    -   [![Your Places: Global Update Logo]()](https://www.nytimes.com/newsletters/your-places-global-update)
        Your Places: Global Update

        The latest news for any part of the world you select.
    -   [![Canada Letter Logo]()](https://www.nytimes.com/newsletters/canada-letter)
        Canada Letter

        Backstories and analysis from our Canadian correspondents.

    [](https://www.nytimes.com/newsletters)
    See all newsletters
-   [Business](https://www.nytimes.com/section/business)

    ### Sections

    -   [Business](https://www.nytimes.com/section/business)
    -   [Tech](https://www.nytimes.com/section/technology)
    -   [Economy](https://www.nytimes.com/section/business/economy)
    -   [Media](https://www.nytimes.com/section/business/media)
    -   [Finance and Markets](https://www.nytimes.com/section/markets-overview)

    ### 

    -   [DealBook](https://www.nytimes.com/section/business/dealbook)
    -   [Personal Tech](https://www.nytimes.com/section/technology/personaltech)
    -   [Energy Transition](https://www.nytimes.com/section/business/energy-environment)
    -   [Your Money](https://www.nytimes.com/section/your-money)

    ### Top Stories

    -   [U.S. Economy](https://www.nytimes.com/news-event/economy-business-us)
    -   [Stock Market](https://www.nytimes.com/section/markets-overview)
    -   [Artificial Intelligence](https://www.nytimes.com/spotlight/artificial-intelligence)

    ### Newsletters

    -   [![DealBook Logo]()](https://www.nytimes.com/newsletters/dealbook)
        DealBook

        The most crucial business and policy news you need to know.

    [](https://www.nytimes.com/newsletters)
    See all newsletters

    ### Podcasts

    -   [![Hard Fork Logo]()](https://www.nytimes.com/column/hard-fork)
        Hard Fork

        Our tech journalists help you make sense of the rapidly changing tech world.

    [](https://www.nytimes.com/spotlight/podcasts)
    See all podcasts
-   [Arts](https://www.nytimes.com/section/arts)

    ### Sections

    -   [Today\'s Arts](https://www.nytimes.com/section/arts)
    -   [Book Review](https://www.nytimes.com/section/books)
    -   [Best Sellers](https://www.nytimes.com/books/best-sellers)
    -   [Dance](https://www.nytimes.com/section/arts/dance)
    -   [Movies](https://www.nytimes.com/section/movies)
    -   [Music](https://www.nytimes.com/section/arts/music)

    ### 

    -   [Television](https://www.nytimes.com/section/arts/television)
    -   [Theater](https://www.nytimes.com/section/theater)
    -   [Pop Culture](https://www.nytimes.com/spotlight/pop-culture)
    -   [T Magazine](https://www.nytimes.com/section/t-magazine)
    -   [Visual Arts](https://www.nytimes.com/section/arts/design)

    ### Recommendations

    -   [100 Best Books of the 21st Century](https://www.nytimes.com/interactive/2024/books/best-books-21st-century.html)
    -   [Critic's Picks](https://www.nytimes.com/spotlight/critics-picks)
    -   [What to Read](https://www.nytimes.com/spotlight/books-to-read)
    -   [What to Watch](https://www.nytimes.com/spotlight/what-to-watch)
    -   [What to Listen To](https://www.nytimes.com/column/playlist)
    -   [5 Minutes to Make You Love Music](https://www.nytimes.com/interactive/2023/10/27/arts/music/music-fivemins-collection.html)

    ### Newsletters

    -   [![Read Like the Wind Logo]()](https://www.nytimes.com/newsletters/read-like-the-wind)
        Read Like the Wind

        Book recommendations from our critics.
    -   [![Watching Logo]()](https://www.nytimes.com/newsletters/watching)
        Watching

        Streaming TV and movie recommendations.

    [](https://www.nytimes.com/newsletters)
    See all newsletters

    ### Podcasts

    -   [![Book Review Logo]()](https://www.nytimes.com/column/book-review-podcast)
        Book Review

        The podcast that takes you inside the literary world.
    -   [![Popcast Logo]()](https://www.nytimes.com/column/popcast-pop-music-podcast)
        Popcast

        Pop music news, new songs and albums, and artists of note.

    [](https://www.nytimes.com/spotlight/podcasts)
    See all podcasts
-   [Lifestyle](https://www.nytimes.com/spotlight/lifestyle)

    ### Sections

    -   [All Lifestyle](https://www.nytimes.com/spotlight/lifestyle)
    -   [Well](https://www.nytimes.com/section/well)
    -   [Travel](https://www.nytimes.com/section/travel)
    -   [Style](https://www.nytimes.com/section/style)
    -   [Real Estate](https://www.nytimes.com/section/realestate)

    ### 

    -   [Food](https://www.nytimes.com/section/food)
    -   [Love](https://www.nytimes.com/section/fashion/weddings)
    -   [Your Money](https://www.nytimes.com/section/your-money)
    -   [Personal Tech](https://www.nytimes.com/section/technology/personaltech)
    -   [T Magazine](https://www.nytimes.com/section/t-magazine)

    ### Columns

    -   [36 Hours](https://www.nytimes.com/column/36-hours)
    -   [Ask Well](https://www.nytimes.com/column/ask-well)
    -   [The Hunt](https://www.nytimes.com/column/the-hunt)
    -   [Modern Love](https://www.nytimes.com/column/modern-love)
    -   [Where to Eat](https://www.nytimes.com/spotlight/best-restaurants)
    -   [Vows](https://www.nytimes.com/column/vows)
    -   [Social Q's](https://www.nytimes.com/column/social-qs)
    -   [The Ethicist](https://www.nytimes.com/column/the-ethicist)

    ### Newsletters

    -   [![Open Thread Logo]()](https://www.nytimes.com/newsletters/open-thread-fashion)
        Open Thread

        The latest news on what we wear, by our chief fashion critic.
    -   [![Well Logo]()](https://www.nytimes.com/newsletters/well)
        Well

        Essential news and guidance to live your healthiest life.

    [](https://www.nytimes.com/newsletters)
    See all newsletters

    ### Podcasts

    -   [![Modern Love Logo]()](https://www.nytimes.com/column/modern-love-podcast)
        Modern Love

        The complicated love lives of real people.

    [](https://www.nytimes.com/spotlight/podcasts)
    See all podcasts
-   [Opinion](https://www.nytimes.com/section/opinion)

    ### Sections

    -   [Opinion](https://www.nytimes.com/section/opinion)
    -   [Guest Essays](https://www.nytimes.com/section/opinion/contributors)
    -   [Editorials](https://www.nytimes.com/section/opinion/editorials)
    -   [Op-Docs](https://www.nytimes.com/column/op-docs)
    -   [Videos](https://www.nytimes.com/spotlight/opinion-video)
    -   [Letters](https://www.nytimes.com/section/opinion/letters)

    ### Topics

    -   [Politics](https://www.nytimes.com/section/opinion/politics)
    -   [World](https://www.nytimes.com/section/opinion/international-world)
    -   [Business](https://www.nytimes.com/section/opinion/business-economics)
    -   [Tech](https://www.nytimes.com/section/opinion/technology)
    -   [Climate](https://www.nytimes.com/section/opinion/environment)
    -   [Health](https://www.nytimes.com/section/opinion/health)
    -   [Culture](https://www.nytimes.com/section/opinion/culture)

    ### Columnists

    -   [Charles M. Blow](https://www.nytimes.com/by/charles-m-blow)
    -   [Jamelle Bouie](https://www.nytimes.com/by/jamelle-bouie)
    -   [David Brooks](https://www.nytimes.com/by/david-brooks)
    -   [Gail Collins](https://www.nytimes.com/by/gail-collins)
    -   [Ross Douthat](https://www.nytimes.com/by/ross-douthat)
    -   [Maureen Dowd](https://www.nytimes.com/by/maureen-dowd)
    -   [David French](https://www.nytimes.com/by/david-french)
    -   [Thomas L. Friedman](https://www.nytimes.com/by/thomas-l-friedman)
    -   [M. Gessen](https://www.nytimes.com/by/m-gessen)
    -   [Michelle Goldberg](https://www.nytimes.com/by/michelle-goldberg)
    -   [Ezra Klein](https://www.nytimes.com/by/ezra-klein)
    -   [Nicholas Kristof](https://www.nytimes.com/by/nicholas-kristof)
    -   [Paul Krugman](https://www.nytimes.com/by/paul-krugman)
    -   [Carlos Lozada](https://www.nytimes.com/by/carlos-lozada)
    -   [Tressie McMillan Cottom](https://www.nytimes.com/by/tressie-mcmillan-cottom)
    -   [Pamela Paul](https://www.nytimes.com/by/pamela-paul)
    -   [Lydia Polgreen](https://www.nytimes.com/by/lydia-polgreen)
    -   [Bret Stephens](https://www.nytimes.com/by/bret-stephens)
    -   [Zeynep Tufekci](https://www.nytimes.com/by/zeynep-tufekci)

    ### Podcasts

    -   [![Matter of Opinion Logo]()](https://www.nytimes.com/column/matter-of-opinion)
        Matter of Opinion

        Thoughts, aloud. With Michelle Cottle, Ross Douthat, Carlos Lozada and Lydia Polgreen.
    -   [![The Ezra Klein Show Logo]()](https://www.nytimes.com/column/ezra-klein-podcast)
        The Ezra Klein Show

        Discussions of ideas that matter, plus book recommendations.

    [](https://www.nytimes.com/spotlight/podcasts)
    See all podcasts
-   [Audio](https://www.nytimes.com/spotlight/podcasts)

    [](https://www.nytimes.com/spotlight/podcasts)
    ### Audio

    Podcasts and narrated articles covering news, tech, culture and more.

    [](https://www.nytimes.com/audio/app)
    Download the Audio app on iOS.

    ### Listen

    -   [The Headlines](https://www.nytimes.com/column/the-headlines)
    -   [The Daily](https://www.nytimes.com/column/the-daily)
    -   [Hard Fork](https://www.nytimes.com/column/hard-fork)
    -   [The Ezra Klein Show](https://www.nytimes.com/column/ezra-klein-podcast)
    -   [Matter of Opinion](https://www.nytimes.com/column/matter-of-opinion)
    -   [Serial Productions](https://www.nytimes.com/interactive/2022/podcasts/serial-productions.html)
    -   [The Book Review Podcast](https://www.nytimes.com/column/book-review-podcast)
    -   [Modern Love](https://www.nytimes.com/column/modern-love-podcast)
    -   [The Run-Up](https://www.nytimes.com/column/election-run-up-podcast)
    -   [Popcast](https://www.nytimes.com/column/popcast-pop-music-podcast)
    -   [Reporter Reads](https://www.nytimes.com/spotlight/reporter-reads)
    -   [The Sunday Read](https://www.nytimes.com/spotlight/the-sunday-read)
    -   [The Culture Desk](https://www.nytimes.com/column/the-culture-desk)
    -   [The Interview](https://www.nytimes.com/column/the-interview)

    [](https://www.nytimes.com/spotlight/podcasts)
    See all audio

    ### Featured

    -   [![The Interview Logo]()](https://www.nytimes.com/column/the-interview)
        The Interview

        Conversations with the world's most fascinating people.
    -   [![The Headlines Logo]()](https://www.nytimes.com/column/the-headlines)
        The Headlines

        Your morning listen. Top stories, in 10 minutes.
    -   [![Serial Season 4: Guantánamo Logo]()](https://www.nytimes.com/interactive/2024/podcasts/serial-season-four-guantanamo.html)
        Serial Season 4: Guantánamo

        What it was really like, from people who lived it.

    ### Newsletters

    -   [![Audio Logo]()](https://www.nytimes.com/newsletters/audio)
        Audio

        Our editors share their favorite listens from the New York Times Audio app.

    [](https://www.nytimes.com/newsletters)
    See all newsletters

    Audio is included in an All Access subscription. [Learn more.](https://www.nytimes.com/subscription/all-access)
-   [Games](https://www.nytimes.com/crosswords)

    [](https://www.nytimes.com/crosswords)
    ### Games

    Word games, logic puzzles and crosswords, including an extensive archive.

    ### Play

    -   [](https://www.nytimes.com/puzzles/spelling-bee)

        Spelling Bee

    -   [](https://www.nytimes.com/crosswords/game/mini)

        The Mini Crossword

    -   [](https://www.nytimes.com/games/wordle/index.html)

        Wordle

    -   [](https://www.nytimes.com/crosswords/game/daily/)

        The Crossword

    ### 

    -   [](https://www.nytimes.com/games/strands)

        Strands

    -   [](https://www.nytimes.com/games/connections)

        Connections

    -   [](https://www.nytimes.com/puzzles/sudoku)

        Sudoku

    -   [](https://www.nytimes.com/puzzles/letter-boxed)

        Letter Boxed

    -   [](https://www.nytimes.com/puzzles/tiles)

        Tiles

    ### Community

    -   [Spelling Bee Forum](https://www.nytimes.com/spotlight/spelling-bee-forum)
    -   [Wordplay Column](https://www.nytimes.com/spotlight/daily-crossword-column)
    -   [Wordle Review](https://www.nytimes.com/spotlight/wordle-review)
    -   [Submit a Crossword](https://www.nytimes.com/article/submit-crossword-puzzles-the-new-york-times.html)
    -   [Meet Our Crossword Constructors](https://www.nytimes.com/spotlight/puzzle-making)
    -   [Mini to Maestro](https://www.nytimes.com/2022/09/19/crosswords/mini-to-maestro-part-1.html)
    -   [Wordlebot](https://www.nytimes.com/interactive/2022/upshot/wordle-bot.html)
    -   [Take the Puzzle Personality Quiz](https://www.nytimes.com/puzzle-personality)

    ### Newsletters

    -   [![Gameplay Logo]()](https://www.nytimes.com/newsletters/gameplay)
        Gameplay

        Puzzles, brain teasers, solving tips and more.
    -   [![Easy Mode Logo]()](https://www.nytimes.com/newsletters/easy-mode)
        Easy Mode

        Get an easy version of one of the hardest crossword puzzles of the week.

    [](https://www.nytimes.com/newsletters)
    See all newsletters

    Games is included in an All Access subscription. [Learn more.](https://www.nytimes.com/subscription/all-access)
-   [Cooking](https://cooking.nytimes.com/)

    [](https://cooking.nytimes.com/)
    ### Cooking

    Recipes, advice and inspiration for everyday cooking, special occasions and more.

    ### Recipes

    -   [Easy](https://cooking.nytimes.com/topics/easy-recipes)
    -   [Dinner](https://cooking.nytimes.com/topics/dinner-recipes)
    -   [Quick](https://cooking.nytimes.com/68861692-nyt-cooking/43843372-quick-recipes)
    -   [Healthy](https://cooking.nytimes.com/topics/healthy-recipes)
    -   [Breakfast](https://cooking.nytimes.com/topics/breakfast)
    -   [Vegetarian](https://cooking.nytimes.com/topics/vegetarian)
    -   [Vegan](https://cooking.nytimes.com/topics/vegan-recipes)
    -   [Chicken](https://cooking.nytimes.com/topics/our-best-chicken-recipes)
    -   [Pasta](https://cooking.nytimes.com/topics/our-best-pasta-recipes)
    -   [Dessert](https://cooking.nytimes.com/topics/desserts)

    ### Editors\' Picks

    -   [Soups and Stews](https://cooking.nytimes.com/68861692-nyt-cooking/638891-best-soup-stew-recipes)
    -   [Easy Weeknight](https://cooking.nytimes.com/topics/easy-weeknight)
    -   [Newest Recipes](https://cooking.nytimes.com/68861692-nyt-cooking/32998034-our-newest-recipes)
    -   [One-Pot Meals](https://cooking.nytimes.com/68861692-nyt-cooking/2370458-one-pot-dinner-recipes)
    -   [Slow Cooker Recipes](https://cooking.nytimes.com/68861692-nyt-cooking/950138-amazing-slow-cooker-recipes)
    -   [Comfort Food](https://cooking.nytimes.com/topics/comfort-food)
    -   [Party Recipes](https://cooking.nytimes.com/topics/entertaining)

    ### Newsletters

    -   [![The Cooking Newsletter Logo]()](https://www.nytimes.com/newsletters/cooking)
        The Cooking Newsletter

        New recipes, easy dinner ideas and smart kitchen tips from Melissa Clark, Sam Sifton and our New York Times Cooking editors.
    -   [![The Veggie Logo]()](https://www.nytimes.com/newsletters/the-veggie)
        The Veggie

        Delicious vegetarian recipes and tips from Tanya Sichynsky.

    ### 

    -   [![Five Weeknight Dishes Logo]()](https://www.nytimes.com/newsletters/five-weeknight-dishes)
        Five Weeknight Dishes

        Dinner ideas for busy people from Emily Weinstein.

    [](https://www.nytimes.com/newsletters)
    See all newsletters

    Cooking is included in an All Access subscription. [Learn more.](https://www.nytimes.com/subscription/all-access)
-   [Wirecutter](https://www.nytimes.com/wirecutter/)

    [](https://www.nytimes.com/wirecutter)
    ### Wirecutter

    Reviews and recommendations for thousands of products.

    ### Reviews

    -   [Kitchen](https://www.nytimes.com/wirecutter/kitchen-dining/)
    -   [Tech](https://www.nytimes.com/wirecutter/electronics/)
    -   [Sleep](https://www.nytimes.com/wirecutter/sleep/)
    -   [Appliances](https://www.nytimes.com/wirecutter/appliances/)
    -   [Home and Garden](https://www.nytimes.com/wirecutter/home-garden/)
    -   [Moving](https://www.nytimes.com/wirecutter/make-a-plan/moving/)

    ### 

    -   [Travel](https://www.nytimes.com/wirecutter/travel/)
    -   [Gifts](https://www.nytimes.com/wirecutter/gifts/)
    -   [Deals](https://www.nytimes.com/wirecutter/deals/)
    -   [Baby and Kid](https://www.nytimes.com/wirecutter/baby-kid/)
    -   [Health and Fitness](https://www.nytimes.com/wirecutter/health-fitness/)

    ### The Best\...

    -   [Air Purifier](https://www.nytimes.com/wirecutter/reviews/best-air-purifier/)
    -   [Electric Toothbrush](https://www.nytimes.com/wirecutter/reviews/best-electric-toothbrush/)
    -   [Pressure Washer](https://www.nytimes.com/wirecutter/reviews/best-pressure-washer/)
    -   [Cordless Stick Vacuum](https://www.nytimes.com/wirecutter/reviews/best-cordless-stick-vacuum/)
    -   [Office Chair](https://www.nytimes.com/wirecutter/reviews/best-office-chair/)
    -   [Robot Vacuum](https://www.nytimes.com/wirecutter/reviews/best-robot-vacuum/)

    ### Newsletters

    -   [![The Recommendation Logo]()](https://www.nytimes.com/newsletters/the-recommendation)
        The Recommendation

        The best independent reviews, expert advice and intensively researched deals.
    -   [![Clean Everything Logo]()](https://www.nytimes.com/newsletters/clean-everything)
        Clean Everything

        Step-by-step advice on how to keep everything in your home squeaky clean.

    [](https://www.nytimes.com/newsletters)
    See all newsletters

    Wirecutter is included in an All Access subscription. [Learn more.](https://www.nytimes.com/subscription/all-access)
-   [The Athletic](https://www.nytimes.com/athletic/)

    [](https://www.nytimes.com/athletic/)
    ### The Athletic

    Personalized coverage of your sports teams and leagues.

    ### Leagues

    -   [NFL](https://www.nytimes.com/athletic/nfl/)
    -   [MLB](https://www.nytimes.com/athletic/mlb/)
    -   [NBA](https://www.nytimes.com/athletic/nba/)
    -   [Premier League](https://www.nytimes.com/athletic/football/premier-league/)
    -   [NCAAF](https://www.nytimes.com/athletic/college-football/)
    -   [NCAAM](https://www.nytimes.com/athletic/college-basketball/)
    -   [NHL](https://www.nytimes.com/athletic/nhl/)
    -   [NCAAW](https://www.nytimes.com/athletic/womens-college-basketball/%20)
    -   [MLS](https://www.nytimes.com/athletic/football/mls/)
    -   [Tennis](https://www.nytimes.com/athletic/tennis/)
    -   [WNBA](https://www.nytimes.com/athletic/wnba/)
    -   [Golf](https://www.nytimes.com/athletic/golf/)

    ### Top Stories

    -   [Today\'s Must-Read](https://www.nytimes.com/athletic/tag/a1-must-read-stories/)
    -   [NFL Playoff Predictions](https://www.nytimes.com/athletic/5698572/2024/09/10/nfl-playoff-2024-chances-projections-probabilities/)
    -   [College Football Projections](https://www.nytimes.com/athletic/5701128/2024/09/09/college-football-playoff-projections-odds/)

    ### Newsletters

    -   [![The Pulse Logo]()](https://www.nytimes.com/athletic/newsletters/the-pulse/)
        The Pulse

        Delivering the top stories in sports, Sunday to Friday.
    -   [![Scoop City Logo]()](https://www.nytimes.com/athletic/newsletters/scoop-city/)
        Scoop City

        The top stories in the NFL, from Jacob Robinson with Dianna Russini.

    ### 

    -   [![The Windup Logo]()](https://www.nytimes.com/athletic/newsletters/the-windup/)
        The Windup

        The biggest stories in baseball, by Levi Weaver with Ken Rosenthal.
    -   [![The Athletic FC Logo]()](https://www.nytimes.com/athletic/newsletters/the-athletic-fc/)
        The Athletic FC

        Renowned soccer writer Phil Hay\'s daily newsletter unpacks the truth behind the game\'s biggest stories.

    The Athletic is included in an All Access subscription. [Learn more.](https://www.nytimes.com/subscription/all-access)

-   [U.S.](https://www.nytimes.com/section/us)
    ### Sections

    -   [U.S.](https://www.nytimes.com/section/us)
    -   [Politics](https://www.nytimes.com/section/politics)
    -   [New York](https://www.nytimes.com/section/nyregion)
    -   [California](https://www.nytimes.com/spotlight/california-news)
    -   [Education](https://www.nytimes.com/section/education)
    -   [Health](https://www.nytimes.com/section/health)
    -   [Obituaries](https://www.nytimes.com/section/obituaries)
    -   [Science](https://www.nytimes.com/section/science)

    ### 

    -   [Climate](https://www.nytimes.com/section/climate)
    -   [Weather](https://www.nytimes.com/section/weather)
    -   [Sports](https://www.nytimes.com/section/sports)
    -   [Business](https://www.nytimes.com/section/business)
    -   [Tech](https://www.nytimes.com/section/technology)
    -   [The Upshot](https://www.nytimes.com/section/upshot)
    -   [The Magazine](https://www.nytimes.com/section/magazine)

    ### U.S. Politics

    -   [2024 Elections](https://www.nytimes.com/news-event/2024-election)
    -   [President Biden](https://www.nytimes.com/spotlight/joe-biden)
    -   [Donald Trump](https://www.nytimes.com/spotlight/donald-trump)
    -   [Kamala Harris](https://www.nytimes.com/spotlight/kamala-harris)
    -   [Poll Tracker](https://www.nytimes.com/interactive/2024/us/elections/polls-president.html)
    -   [Supreme Court](https://www.nytimes.com/topic/organization/us-supreme-court)
    -   [Congress](https://www.nytimes.com/topic/organization/us-congress)

    ### Top Stories

    -   [Trump Investigations](https://www.nytimes.com/news-event/donald-trump-investigations)
    -   [Immigration](https://www.nytimes.com/news-event/immigration-us)
    -   [Abortion](https://www.nytimes.com/spotlight/abortion-news)

    ### Newsletters

    -   [![The Morning Logo]()](https://www.nytimes.com/newsletters/morning-briefing)
        The Morning

        Make sense of the day's news and ideas.
    -   [![The Upshot Logo]()](https://www.nytimes.com/newsletters/upshot)
        The Upshot

        Analysis that explains politics, policy and everyday life.

    [](https://www.nytimes.com/newsletters)
    See all newsletters

    ### Podcasts

    -   [![The Daily Logo]()](https://www.nytimes.com/column/the-daily)
        The Daily

        The biggest stories of our time, in 20 minutes a day.
    -   [![The Run-Up Logo]()](https://www.nytimes.com/column/election-run-up-podcast)
        The Run-Up

        On the campaign trail with Astead Herndon.

    [](https://www.nytimes.com/spotlight/podcasts)
    See all podcasts
-   [World](https://www.nytimes.com/section/world)

    ### Sections

    -   [World](https://www.nytimes.com/section/world)
    -   [Africa](https://www.nytimes.com/section/world/africa)
    -   [Americas](https://www.nytimes.com/section/world/americas)
    -   [Asia](https://www.nytimes.com/section/world/asia)
    -   [Australia](https://www.nytimes.com/section/world/australia)
    -   [Canada](https://www.nytimes.com/section/world/canada)
    -   [Europe](https://www.nytimes.com/section/world/europe)
    -   [Middle East](https://www.nytimes.com/section/world/middleeast)
    -   [Science](https://www.nytimes.com/section/science)
    -   [Climate](https://www.nytimes.com/section/climate)
    -   [Weather](https://www.nytimes.com/section/weather)
    -   [Health](https://www.nytimes.com/section/health)
    -   [Obituaries](https://www.nytimes.com/section/obituaries)

    ### Top Stories

    -   [Israel-Hamas War](https://www.nytimes.com/news-event/israel-hamas-gaza)
    -   [Russia-Ukraine War](https://www.nytimes.com/news-event/ukraine-russia)

    ### Newsletters

    -   [![Morning Briefing: Europe Logo]()](https://www.nytimes.com/newsletters/morning-briefing-europe)
        Morning Briefing: Europe

        Get what you need to know to start your day.
    -   [![The Interpreter Logo]()](https://www.nytimes.com/newsletters/the-interpreter)
        The Interpreter

        Original analysis on the week's biggest global stories.

    ### 

    -   [![Your Places: Global Update Logo]()](https://www.nytimes.com/newsletters/your-places-global-update)
        Your Places: Global Update

        The latest news for any part of the world you select.
    -   [![Canada Letter Logo]()](https://www.nytimes.com/newsletters/canada-letter)
        Canada Letter

        Backstories and analysis from our Canadian correspondents.

    [](https://www.nytimes.com/newsletters)
    See all newsletters
-   [Business](https://www.nytimes.com/section/business)

    ### Sections

    -   [Business](https://www.nytimes.com/section/business)
    -   [Tech](https://www.nytimes.com/section/technology)
    -   [Economy](https://www.nytimes.com/section/business/economy)
    -   [Media](https://www.nytimes.com/section/business/media)
    -   [Finance and Markets](https://www.nytimes.com/section/markets-overview)

    ### 

    -   [DealBook](https://www.nytimes.com/section/business/dealbook)
    -   [Personal Tech](https://www.nytimes.com/section/technology/personaltech)
    -   [Energy Transition](https://www.nytimes.com/section/business/energy-environment)
    -   [Your Money](https://www.nytimes.com/section/your-money)

    ### Top Stories

    -   [U.S. Economy](https://www.nytimes.com/news-event/economy-business-us)
    -   [Stock Market](https://www.nytimes.com/section/markets-overview)
    -   [Artificial Intelligence](https://www.nytimes.com/spotlight/artificial-intelligence)

    ### Newsletters

    -   [![DealBook Logo]()](https://www.nytimes.com/newsletters/dealbook)
        DealBook

        The most crucial business and policy news you need to know.

    [](https://www.nytimes.com/newsletters)
    See all newsletters

    ### Podcasts

    -   [![Hard Fork Logo]()](https://www.nytimes.com/column/hard-fork)
        Hard Fork

        Our tech journalists help you make sense of the rapidly changing tech world.

    [](https://www.nytimes.com/spotlight/podcasts)
    See all podcasts
-   [Arts](https://www.nytimes.com/section/arts)

    ### Sections

    -   [Today\'s Arts](https://www.nytimes.com/section/arts)
    -   [Book Review](https://www.nytimes.com/section/books)
    -   [Best Sellers](https://www.nytimes.com/books/best-sellers)
    -   [Dance](https://www.nytimes.com/section/arts/dance)
    -   [Movies](https://www.nytimes.com/section/movies)
    -   [Music](https://www.nytimes.com/section/arts/music)

    ### 

    -   [Television](https://www.nytimes.com/section/arts/television)
    -   [Theater](https://www.nytimes.com/section/theater)
    -   [Pop Culture](https://www.nytimes.com/spotlight/pop-culture)
    -   [T Magazine](https://www.nytimes.com/section/t-magazine)
    -   [Visual Arts](https://www.nytimes.com/section/arts/design)

    ### Recommendations

    -   [100 Best Books of the 21st Century](https://www.nytimes.com/interactive/2024/books/best-books-21st-century.html)
    -   [Critic's Picks](https://www.nytimes.com/spotlight/critics-picks)
    -   [What to Read](https://www.nytimes.com/spotlight/books-to-read)
    -   [What to Watch](https://www.nytimes.com/spotlight/what-to-watch)
    -   [What to Listen To](https://www.nytimes.com/column/playlist)
    -   [5 Minutes to Make You Love Music](https://www.nytimes.com/interactive/2023/10/27/arts/music/music-fivemins-collection.html)

    ### Newsletters

    -   [![Read Like the Wind Logo]()](https://www.nytimes.com/newsletters/read-like-the-wind)
        Read Like the Wind

        Book recommendations from our critics.
    -   [![Watching Logo]()](https://www.nytimes.com/newsletters/watching)
        Watching

        Streaming TV and movie recommendations.

    [](https://www.nytimes.com/newsletters)
    See all newsletters

    ### Podcasts

    -   [![Book Review Logo]()](https://www.nytimes.com/column/book-review-podcast)
        Book Review

        The podcast that takes you inside the literary world.
    -   [![Popcast Logo]()](https://www.nytimes.com/column/popcast-pop-music-podcast)
        Popcast

        Pop music news, new songs and albums, and artists of note.

    [](https://www.nytimes.com/spotlight/podcasts)
    See all podcasts
-   [Lifestyle](https://www.nytimes.com/spotlight/lifestyle)

    ### Sections

    -   [All Lifestyle](https://www.nytimes.com/spotlight/lifestyle)
    -   [Well](https://www.nytimes.com/section/well)
    -   [Travel](https://www.nytimes.com/section/travel)
    -   [Style](https://www.nytimes.com/section/style)
    -   [Real Estate](https://www.nytimes.com/section/realestate)

    ### 

    -   [Food](https://www.nytimes.com/section/food)
    -   [Love](https://www.nytimes.com/section/fashion/weddings)
    -   [Your Money](https://www.nytimes.com/section/your-money)
    -   [Personal Tech](https://www.nytimes.com/section/technology/personaltech)
    -   [T Magazine](https://www.nytimes.com/section/t-magazine)

    ### Columns

    -   [36 Hours](https://www.nytimes.com/column/36-hours)
    -   [Ask Well](https://www.nytimes.com/column/ask-well)
    -   [The Hunt](https://www.nytimes.com/column/the-hunt)
    -   [Modern Love](https://www.nytimes.com/column/modern-love)
    -   [Where to Eat](https://www.nytimes.com/spotlight/best-restaurants)
    -   [Vows](https://www.nytimes.com/column/vows)
    -   [Social Q's](https://www.nytimes.com/column/social-qs)
    -   [The Ethicist](https://www.nytimes.com/column/the-ethicist)

    ### Newsletters

    -   [![Open Thread Logo]()](https://www.nytimes.com/newsletters/open-thread-fashion)
        Open Thread

        The latest news on what we wear, by our chief fashion critic.
    -   [![Well Logo]()](https://www.nytimes.com/newsletters/well)
        Well

        Essential news and guidance to live your healthiest life.

    [](https://www.nytimes.com/newsletters)
    See all newsletters

    ### Podcasts

    -   [![Modern Love Logo]()](https://www.nytimes.com/column/modern-love-podcast)
        Modern Love

        The complicated love lives of real people.

    [](https://www.nytimes.com/spotlight/podcasts)
    See all podcasts
-   [Opinion](https://www.nytimes.com/section/opinion)

    ### Sections

    -   [Opinion](https://www.nytimes.com/section/opinion)
    -   [Guest Essays](https://www.nytimes.com/section/opinion/contributors)
    -   [Editorials](https://www.nytimes.com/section/opinion/editorials)
    -   [Op-Docs](https://www.nytimes.com/column/op-docs)
    -   [Videos](https://www.nytimes.com/spotlight/opinion-video)
    -   [Letters](https://www.nytimes.com/section/opinion/letters)

    ### Topics

    -   [Politics](https://www.nytimes.com/section/opinion/politics)
    -   [World](https://www.nytimes.com/section/opinion/international-world)
    -   [Business](https://www.nytimes.com/section/opinion/business-economics)
    -   [Tech](https://www.nytimes.com/section/opinion/technology)
    -   [Climate](https://www.nytimes.com/section/opinion/environment)
    -   [Health](https://www.nytimes.com/section/opinion/health)
    -   [Culture](https://www.nytimes.com/section/opinion/culture)

    ### Columnists

    -   [Charles M. Blow](https://www.nytimes.com/by/charles-m-blow)
    -   [Jamelle Bouie](https://www.nytimes.com/by/jamelle-bouie)
    -   [David Brooks](https://www.nytimes.com/by/david-brooks)
    -   [Gail Collins](https://www.nytimes.com/by/gail-collins)
    -   [Ross Douthat](https://www.nytimes.com/by/ross-douthat)
    -   [Maureen Dowd](https://www.nytimes.com/by/maureen-dowd)
    -   [David French](https://www.nytimes.com/by/david-french)
    -   [Thomas L. Friedman](https://www.nytimes.com/by/thomas-l-friedman)
    -   [M. Gessen](https://www.nytimes.com/by/m-gessen)
    -   [Michelle Goldberg](https://www.nytimes.com/by/michelle-goldberg)
    -   [Ezra Klein](https://www.nytimes.com/by/ezra-klein)
    -   [Nicholas Kristof](https://www.nytimes.com/by/nicholas-kristof)
    -   [Paul Krugman](https://www.nytimes.com/by/paul-krugman)
    -   [Carlos Lozada](https://www.nytimes.com/by/carlos-lozada)
    -   [Tressie McMillan Cottom](https://www.nytimes.com/by/tressie-mcmillan-cottom)
    -   [Pamela Paul](https://www.nytimes.com/by/pamela-paul)
    -   [Lydia Polgreen](https://www.nytimes.com/by/lydia-polgreen)
    -   [Bret Stephens](https://www.nytimes.com/by/bret-stephens)
    -   [Zeynep Tufekci](https://www.nytimes.com/by/zeynep-tufekci)

    ### Podcasts

    -   [![Matter of Opinion Logo]()](https://www.nytimes.com/column/matter-of-opinion)
        Matter of Opinion

        Thoughts, aloud. With Michelle Cottle, Ross Douthat, Carlos Lozada and Lydia Polgreen.
    -   [![The Ezra Klein Show Logo]()](https://www.nytimes.com/column/ezra-klein-podcast)
        The Ezra Klein Show

        Discussions of ideas that matter, plus book recommendations.

    [](https://www.nytimes.com/spotlight/podcasts)
    See all podcasts
-   [Audio](https://www.nytimes.com/spotlight/podcasts)

    [](https://www.nytimes.com/spotlight/podcasts)
    ### Audio

    Podcasts and narrated articles covering news, tech, culture and more.

    [](https://www.nytimes.com/audio/app)
    Download the Audio app on iOS.

    ### Listen

    -   [The Headlines](https://www.nytimes.com/column/the-headlines)
    -   [The Daily](https://www.nytimes.com/column/the-daily)
    -   [Hard Fork](https://www.nytimes.com/column/hard-fork)
    -   [The Ezra Klein Show](https://www.nytimes.com/column/ezra-klein-podcast)
    -   [Matter of Opinion](https://www.nytimes.com/column/matter-of-opinion)
    -   [Serial Productions](https://www.nytimes.com/interactive/2022/podcasts/serial-productions.html)
    -   [The Book Review Podcast](https://www.nytimes.com/column/book-review-podcast)
    -   [Modern Love](https://www.nytimes.com/column/modern-love-podcast)
    -   [The Run-Up](https://www.nytimes.com/column/election-run-up-podcast)
    -   [Popcast](https://www.nytimes.com/column/popcast-pop-music-podcast)
    -   [Reporter Reads](https://www.nytimes.com/spotlight/reporter-reads)
    -   [The Sunday Read](https://www.nytimes.com/spotlight/the-sunday-read)
    -   [The Culture Desk](https://www.nytimes.com/column/the-culture-desk)
    -   [The Interview](https://www.nytimes.com/column/the-interview)

    [](https://www.nytimes.com/spotlight/podcasts)
    See all audio

    ### Featured

    -   [![The Interview Logo]()](https://www.nytimes.com/column/the-interview)
        The Interview

        Conversations with the world's most fascinating people.
    -   [![The Headlines Logo]()](https://www.nytimes.com/column/the-headlines)
        The Headlines

        Your morning listen. Top stories, in 10 minutes.
    -   [![Serial Season 4: Guantánamo Logo]()](https://www.nytimes.com/interactive/2024/podcasts/serial-season-four-guantanamo.html)
        Serial Season 4: Guantánamo

        What it was really like, from people who lived it.

    ### Newsletters

    -   [![Audio Logo]()](https://www.nytimes.com/newsletters/audio)
        Audio

        Our editors share their favorite listens from the New York Times Audio app.

    [](https://www.nytimes.com/newsletters)
    See all newsletters

    Audio is included in an All Access subscription. [Learn more.](https://www.nytimes.com/subscription/all-access)
-   [Games](https://www.nytimes.com/crosswords)

    [](https://www.nytimes.com/crosswords)
    ### Games

    Word games, logic puzzles and crosswords, including an extensive archive.

    ### Play

    -   [](https://www.nytimes.com/puzzles/spelling-bee)

        Spelling Bee

    -   [](https://www.nytimes.com/crosswords/game/mini)

        The Mini Crossword

    -   [](https://www.nytimes.com/games/wordle/index.html)

        Wordle

    -   [](https://www.nytimes.com/crosswords/game/daily/)

        The Crossword

    ### 

    -   [](https://www.nytimes.com/games/strands)

        Strands

    -   [](https://www.nytimes.com/games/connections)

        Connections

    -   [](https://www.nytimes.com/puzzles/sudoku)

        Sudoku

    -   [](https://www.nytimes.com/puzzles/letter-boxed)

        Letter Boxed

    -   [](https://www.nytimes.com/puzzles/tiles)

        Tiles

    ### Community

    -   [Spelling Bee Forum](https://www.nytimes.com/spotlight/spelling-bee-forum)
    -   [Wordplay Column](https://www.nytimes.com/spotlight/daily-crossword-column)
    -   [Wordle Review](https://www.nytimes.com/spotlight/wordle-review)
    -   [Submit a Crossword](https://www.nytimes.com/article/submit-crossword-puzzles-the-new-york-times.html)
    -   [Meet Our Crossword Constructors](https://www.nytimes.com/spotlight/puzzle-making)
    -   [Mini to Maestro](https://www.nytimes.com/2022/09/19/crosswords/mini-to-maestro-part-1.html)
    -   [Wordlebot](https://www.nytimes.com/interactive/2022/upshot/wordle-bot.html)
    -   [Take the Puzzle Personality Quiz](https://www.nytimes.com/puzzle-personality)

    ### Newsletters

    -   [![Gameplay Logo]()](https://www.nytimes.com/newsletters/gameplay)
        Gameplay

        Puzzles, brain teasers, solving tips and more.
    -   [![Easy Mode Logo]()](https://www.nytimes.com/newsletters/easy-mode)
        Easy Mode

        Get an easy version of one of the hardest crossword puzzles of the week.

    [](https://www.nytimes.com/newsletters)
    See all newsletters

    Games is included in an All Access subscription. [Learn more.](https://www.nytimes.com/subscription/all-access)
-   [Cooking](https://cooking.nytimes.com/)

    [](https://cooking.nytimes.com/)
    ### Cooking

    Recipes, advice and inspiration for everyday cooking, special occasions and more.

    ### Recipes

    -   [Easy](https://cooking.nytimes.com/topics/easy-recipes)
    -   [Dinner](https://cooking.nytimes.com/topics/dinner-recipes)
    -   [Quick](https://cooking.nytimes.com/68861692-nyt-cooking/43843372-quick-recipes)
    -   [Healthy](https://cooking.nytimes.com/topics/healthy-recipes)
    -   [Breakfast](https://cooking.nytimes.com/topics/breakfast)
    -   [Vegetarian](https://cooking.nytimes.com/topics/vegetarian)
    -   [Vegan](https://cooking.nytimes.com/topics/vegan-recipes)
    -   [Chicken](https://cooking.nytimes.com/topics/our-best-chicken-recipes)
    -   [Pasta](https://cooking.nytimes.com/topics/our-best-pasta-recipes)
    -   [Dessert](https://cooking.nytimes.com/topics/desserts)

    ### Editors\' Picks

    -   [Soups and Stews](https://cooking.nytimes.com/68861692-nyt-cooking/638891-best-soup-stew-recipes)
    -   [Easy Weeknight](https://cooking.nytimes.com/topics/easy-weeknight)
    -   [Newest Recipes](https://cooking.nytimes.com/68861692-nyt-cooking/32998034-our-newest-recipes)
    -   [One-Pot Meals](https://cooking.nytimes.com/68861692-nyt-cooking/2370458-one-pot-dinner-recipes)
    -   [Slow Cooker Recipes](https://cooking.nytimes.com/68861692-nyt-cooking/950138-amazing-slow-cooker-recipes)
    -   [Comfort Food](https://cooking.nytimes.com/topics/comfort-food)
    -   [Party Recipes](https://cooking.nytimes.com/topics/entertaining)

    ### Newsletters

    -   [![The Cooking Newsletter Logo]()](https://www.nytimes.com/newsletters/cooking)
        The Cooking Newsletter

        New recipes, easy dinner ideas and smart kitchen tips from Melissa Clark, Sam Sifton and our New York Times Cooking editors.
    -   [![The Veggie Logo]()](https://www.nytimes.com/newsletters/the-veggie)
        The Veggie

        Delicious vegetarian recipes and tips from Tanya Sichynsky.

    ### 

    -   [![Five Weeknight Dishes Logo]()](https://www.nytimes.com/newsletters/five-weeknight-dishes)
        Five Weeknight Dishes

        Dinner ideas for busy people from Emily Weinstein.

    [](https://www.nytimes.com/newsletters)
    See all newsletters

    Cooking is included in an All Access subscription. [Learn more.](https://www.nytimes.com/subscription/all-access)
-   [Wirecutter](https://www.nytimes.com/wirecutter/)

    [](https://www.nytimes.com/wirecutter)
    ### Wirecutter

    Reviews and recommendations for thousands of products.

    ### Reviews

    -   [Kitchen](https://www.nytimes.com/wirecutter/kitchen-dining/)
    -   [Tech](https://www.nytimes.com/wirecutter/electronics/)
    -   [Sleep](https://www.nytimes.com/wirecutter/sleep/)
    -   [Appliances](https://www.nytimes.com/wirecutter/appliances/)
    -   [Home and Garden](https://www.nytimes.com/wirecutter/home-garden/)
    -   [Moving](https://www.nytimes.com/wirecutter/make-a-plan/moving/)

    ### 

    -   [Travel](https://www.nytimes.com/wirecutter/travel/)
    -   [Gifts](https://www.nytimes.com/wirecutter/gifts/)
    -   [Deals](https://www.nytimes.com/wirecutter/deals/)
    -   [Baby and Kid](https://www.nytimes.com/wirecutter/baby-kid/)
    -   [Health and Fitness](https://www.nytimes.com/wirecutter/health-fitness/)

    ### The Best\...

    -   [Air Purifier](https://www.nytimes.com/wirecutter/reviews/best-air-purifier/)
    -   [Electric Toothbrush](https://www.nytimes.com/wirecutter/reviews/best-electric-toothbrush/)
    -   [Pressure Washer](https://www.nytimes.com/wirecutter/reviews/best-pressure-washer/)
    -   [Cordless Stick Vacuum](https://www.nytimes.com/wirecutter/reviews/best-cordless-stick-vacuum/)
    -   [Office Chair](https://www.nytimes.com/wirecutter/reviews/best-office-chair/)
    -   [Robot Vacuum](https://www.nytimes.com/wirecutter/reviews/best-robot-vacuum/)

    ### Newsletters

    -   [![The Recommendation Logo]()](https://www.nytimes.com/newsletters/the-recommendation)
        The Recommendation

        The best independent reviews, expert advice and intensively researched deals.
    -   [![Clean Everything Logo]()](https://www.nytimes.com/newsletters/clean-everything)
        Clean Everything

        Step-by-step advice on how to keep everything in your home squeaky clean.

    [](https://www.nytimes.com/newsletters)
    See all newsletters

    Wirecutter is included in an All Access subscription. [Learn more.](https://www.nytimes.com/subscription/all-access)
-   [The Athletic](https://www.nytimes.com/athletic/)

    [](https://www.nytimes.com/athletic/)
    ### The Athletic

    Personalized coverage of your sports teams and leagues.

    ### Leagues

    -   [NFL](https://www.nytimes.com/athletic/nfl/)
    -   [MLB](https://www.nytimes.com/athletic/mlb/)
    -   [NBA](https://www.nytimes.com/athletic/nba/)
    -   [Premier League](https://www.nytimes.com/athletic/football/premier-league/)
    -   [NCAAF](https://www.nytimes.com/athletic/college-football/)
    -   [NCAAM](https://www.nytimes.com/athletic/college-basketball/)
    -   [NHL](https://www.nytimes.com/athletic/nhl/)
    -   [NCAAW](https://www.nytimes.com/athletic/womens-college-basketball/%20)
    -   [MLS](https://www.nytimes.com/athletic/football/mls/)
    -   [Tennis](https://www.nytimes.com/athletic/tennis/)
    -   [WNBA](https://www.nytimes.com/athletic/wnba/)
    -   [Golf](https://www.nytimes.com/athletic/golf/)

    ### Top Stories

    -   [Today\'s Must-Read](https://www.nytimes.com/athletic/tag/a1-must-read-stories/)
    -   [NFL Playoff Predictions](https://www.nytimes.com/athletic/5698572/2024/09/10/nfl-playoff-2024-chances-projections-probabilities/)
    -   [College Football Projections](https://www.nytimes.com/athletic/5701128/2024/09/09/college-football-playoff-projections-odds/)

    ### Newsletters

    -   [![The Pulse Logo]()](https://www.nytimes.com/athletic/newsletters/the-pulse/)
        The Pulse

        Delivering the top stories in sports, Sunday to Friday.
    -   [![Scoop City Logo]()](https://www.nytimes.com/athletic/newsletters/scoop-city/)
        Scoop City

        The top stories in the NFL, from Jacob Robinson with Dianna Russini.

    ### 

    -   [![The Windup Logo]()](https://www.nytimes.com/athletic/newsletters/the-windup/)
        The Windup

        The biggest stories in baseball, by Levi Weaver with Ken Rosenthal.
    -   [![The Athletic FC Logo]()](https://www.nytimes.com/athletic/newsletters/the-athletic-fc/)
        The Athletic FC

        Renowned soccer writer Phil Hay\'s daily newsletter unpacks the truth behind the game\'s biggest stories.

    The Athletic is included in an All Access subscription. [Learn more.](https://www.nytimes.com/subscription/all-access)

# New York Times - Top Stories

[](https://www.nytimes.com/2024/10/27/us/politics/american-democracy-poll.html)

Voters Are Deeply Skeptical About the Health of American Democracy

Nearly half say it does not do a good job representing the people, and three-quarters say it is under threat, according to a Times/Siena poll.

7 min read

[](https://www.nytimes.com/2024/10/27/us/politics/trump-fascism.html)

Amid Talk of Fascism, Donald Trump's Threats and Language Evoke a Grim Past

Plenty of presidents have been called dictators by their opponents, but none until now has been publicly accused of being a "fascist" by his own handpicked advisers.

14 min read

[](https://www.nytimes.com/2024/10/27/us/politics/trump-and-harris-scrap-for-georgia-as-supporters-brace-for-a-photo-finish.html)

Trump and Harris Struggle for Georgia as Supporters Brace for a Photo Finish

6 min read

[](https://www.nytimes.com/2024/10/27/us/politics/american-democracy-poll.html)

------------------------------------------------------------------------

[](https://www.nytimes.com/2024/10/27/us/elections/beaver-country-football-walz.html)

This Town Has More Faith in Football Than Politics. Can Walz Make a Difference?

6 min read

[](https://www.nytimes.com/2024/10/27/us/politics/trump-new-york-msg.html)

Donald Trump Will Never Be Done With New York

4 min read

[](https://www.nytimes.com/2024/10/26/us/elections/election-security-luzerne-county.html)

Barricades and Bulletproof Glass: A County Prepares for Election Day

6 min read

------------------------------------------------------------------------

[](https://www.nytimes.com/2024/10/26/us/politics/harris-michelle-obama-michigan.html)

Michelle Obama Makes a Searing Appeal to Men: 'Take Our Lives Seriously'

Mrs. Obama portrayed a second Trump administration as dire for American women, and said Kamala Harris was being held to a higher standard than Donald Trump.

5 min read

[](https://www.nytimes.com/2024/10/26/us/politics/trump-democracy-threats.html)

Trump Escalates Threats as Campaign Enters Dark Final Stretch

7 min read

[](https://www.nytimes.com/2024/10/27/business/market-history-elections-disasters.html)

For Investors, What if This Time Is Different?

5 min read

[](https://www.nytimes.com/2024/10/26/us/politics/harris-michelle-obama-michigan.html)

------------------------------------------------------------------------

[](https://www.nytimes.com/interactive/2024/us/elections/polls-president.html)

### Latest Polling Averages

[](https://www.nytimes.com/interactive/2024/us/elections/polls-president.html)

#### National

40%

50%

48% Trump

49% Harris

[Pa. Harris \<1](https://www.nytimes.com/interactive/2024/us/elections/polls-president-pennsylvania.html)

[Nev. Harris \<1](https://www.nytimes.com/interactive/2024/us/elections/polls-president-nevada.html)

[N.C. Trump \<1](https://www.nytimes.com/interactive/2024/us/elections/polls-president-north-carolina.html)

[Wis. Harris \<1](https://www.nytimes.com/interactive/2024/us/elections/polls-president-wisconsin.html)

[Mich. Harris \<1](https://www.nytimes.com/interactive/2024/us/elections/polls-president-michigan.html)

[Ga. Trump +1](https://www.nytimes.com/interactive/2024/us/elections/polls-president-georgia.html)

[Ariz. Trump +2](https://www.nytimes.com/interactive/2024/us/elections/polls-president-arizona.html)

[Minn. Harris +6](https://www.nytimes.com/interactive/2024/us/elections/polls-president-minnesota.html)

[Texas Trump +6](https://www.nytimes.com/interactive/2024/us/elections/polls-president-texas.html)

### Races to Watch

-   [![President map thumbnail]()President ›](https://www.nytimes.com/interactive/2024/us/elections/presidential-election-swing-states.html)
-   [![Senate map thumbnail]()Senate ›](https://www.nytimes.com/interactive/2024/us/elections/senate-election-swing-states.html)
-   [![House map thumbnail]()House ›](https://www.nytimes.com/interactive/2024/us/elections/house-election-swing-districts.html)

-   [](https://www.nytimes.com/interactive/2024/10/16/us/politics/harris-trump-2024-campaign.html)
    ### On the Trail

    ![On the Trail]()
    See where the candidates are campaigning.
-   [](https://www.nytimes.com/interactive/2024/us/politics/trump-harris-issues-election.html)
    ### Key Issues

    ![Key Issues]()
    Here's where Trump and Harris stand.
-   [](https://www.nytimes.com/interactive/2024/us/elections/early-vote-tracker-2024.html)
    ### Early Voting

    ![Early Voting]()
    We're tracking in-person and mailed ballots by state.
-   [](https://www.nytimes.com/interactive/2024/us/politics/electoral-college-270-harris-trump.html)
    ### Electoral College Paths

    ![Electoral College Paths]()
    See how each candidate could reach 270 electoral votes.

## 

The Great Read

[](https://www.nytimes.com/2024/10/27/us/politics/springfield-ohio-family-trump-haitian-immigrants.html)

Their Son's Death Was Devastating. Then Politics Made It Worse.

Aiden Clark's death in a school bus accident in Ohio inspired conspiracy theories, campaign lies and anti-immigrant hate. His family is the latest target.

19 min read

1.  [](https://www.nytimes.com/2024/10/27/us/politics/springfield-ohio-family-trump-haitian-immigrants.html)

    The bus crash that killed 11-year-old Aiden Clark of Springfield, Ohio, was ruled an accident, caused by a legally registered Haitian immigrant driving without a valid license.

    Erin Schaff/The New York Times

2.  [](https://www.nytimes.com/2024/10/27/us/politics/springfield-ohio-family-trump-haitian-immigrants.html)

    But former President Donald Trump and his running mate, JD Vance, tell a different story: Aiden's death was a "murder" committed by "an illegal" as part of a "border blood bath."

    Erin Schaff/The New York Times

3.  [](https://www.nytimes.com/2024/10/27/us/politics/springfield-ohio-family-trump-haitian-immigrants.html)

    The Clarks had worked hard to seek out diversity in Springfield. But at city meetings, frustration about shifting demographics turned to anger, escalating into fear-mongering and racism.

    Erin Schaff/The New York Times

4.  [](https://www.nytimes.com/2024/10/27/us/politics/springfield-ohio-family-trump-haitian-immigrants.html)

    Some of the hatred turned toward the Clarks: cruel Facebook messages, letters about being "immigrant-loving race traitors" and a recent death threat relayed by the F.B.I.

    Erin Schaff/The New York Times

5.  [](https://www.nytimes.com/2024/10/27/us/politics/springfield-ohio-family-trump-haitian-immigrants.html)

    "Is there any decency left?" Nathan Clark said. "We'd at least like to be able to protect our son's memory."

    Erin Schaff/The New York Times

[Middle East Crisis](https://www.nytimes.com/news-event/israel-hamas-gaza)

-   [Why Israel Attacked Iran](https://www.nytimes.com/2024/10/25/world/middleeast/why-did-israel-attack-iran.html)
-   [Timeline of Recent Tensions](https://www.nytimes.com/article/israel-iran-conflict-history.html)
-   [Harsh Winter Looms in Gaza](https://www.nytimes.com/2024/10/23/world/middleeast/gaza-displaced-winter-tents.html)

[](https://www.nytimes.com/live/2024/10/27/world/israel-iran-lebanon-gaza)

LIVE

Oct. 27, 2024, 7:39 a.m. ET1h ago

Iran's Leaders Stress Their Right to Respond to Israel's Strikes

Ayatollah Khamenei, Iran's supreme leader, appeared to take a measured tone. He said Israel's attack should not be "magnified or downplayed," state media said.

See more updates ›

[](https://www.nytimes.com/2024/10/26/world/middleeast/iran-israel-attack-public.html)

Israeli Attack Puts Iranians on Edge: 'The Vibe Is Not Normal'

3 min read

[](https://www.nytimes.com/2024/10/26/world/middleeast/iran-israel-attack-public.html)

[Russia-Ukraine War](https://www.nytimes.com/news-event/ukraine-russia)

-   [Photos](https://www.nytimes.com/2024/04/24/world/europe/images-ukraine-war-third-year.html)
-   [North Korea's Role](https://www.nytimes.com/2024/10/23/world/asia/north-korea-troops-russia-ukraine.html)
-   [A Spotlight on Troop Fatigue](https://www.nytimes.com/2024/10/19/world/europe/ukraine-troop-fatigue.html)
-   [A Russian Deserter's Escape](https://www.nytimes.com/interactive/2024/09/20/magazine/ukraine-russia-war-deserter.html)

[](https://www.nytimes.com/2024/10/27/world/europe/russia-kursk-ukraine-invasion-civilians.html)

Ukraine Invaded Russia. Here's What It Was Like for Civilians.

Russians in the area of Ukraine's invasion have described seeing signs of violent encounters, as well as respectful treatment from Ukrainian troops.

7 min read

Advertisement

LIVE

00:00

2:49

Why Are North Korean Troops in Russia?

2:49

[](https://www.nytimes.com/2024/10/27/arts/the-satanic-panic-that-never-goes-away.html)

IDEAS

The Satanic Panic That Never Goes Away

New movies and TV shows are revisiting a "weird corner" of the '80s --- and offering lessons for today.

Photo illustration by Ricardo Tomas

------------------------------------------------------------------------

Weekend Reads

[](https://www.nytimes.com/2024/10/23/magazine/robert-paxton-facism.html)

Is It Fascism? A Leading Historian Changes His Mind.

16 min read

[](https://www.nytimes.com/2024/10/21/style/dylan-bachelet-great-british-baking-show.html)

![A man in a bright shirt and white long-sleeved undershirt, pours batter into a form while standing in a tent.]()

The Captain Jack Sparrow of Baking

4 min read

[](https://www.nytimes.com/2024/10/24/nyregion/alison-stewart-brain-surgery.html)

![Alison Stewart, wearing a floral patterned top and glasses, sits in front of a red microphone with a WNYC logo and holds one hand to her face while looking off to the side.]()

Her Job Was Talking on the Radio. Then Suddenly, Words Wouldn't Come.

7 min read

[](https://www.nytimes.com/2024/10/21/world/africa/africa-nigeria-birthrate-fertility.html)

![The Sani family at their home in the Nigerian city of Kano, watching Gidan Badamasi, a hit Hausa-language show that has prompted conversations among viewers about family size.]()

How a TV Hit Sparked Debate About Having Too Many Babies

10 min read

[](https://www.nytimes.com/2024/10/23/arts/television/seth-meyers-late-night.html)

![Seth Meyers wears a dark shirt and pants in a green marbled lobby, and caresses a golden lion statue.]()

Seth Meyers Isn't as Nice as You Think He Is

7 min read

[](https://www.nytimes.com/2024/10/22/us/politics/samuel-alito-princess-gloria.html)

![Princess Gloria von Thurn und Taxis, wearing a scarf, a necklace, a gray sweater and pink pants, sits on a pink chair.]()

The Princess and the Supreme Court Justice

7 min read

------------------------------------------------------------------------

[](https://www.nytimes.com/interactive/2024/10/25/briefing/quiz-trump-harris-north-korea-mcdonalds.html)

Did You Follow the News This Week? Take Our Quiz.

[](https://www.nytimes.com/interactive/2024/10/25/upshot/flashback.html)

Play Flashback, Your Weekly History Quiz

World Series

-   [Preview](https://www.nytimes.com/athletic/5858593/2024/10/21/dodgers-yankees-2024-world-series-preview-predictions/)
-   [Predictions](https://www.nytimes.com/athletic/5860718/2024/10/22/mlb-postseason-world-series-predictions-dodgers-yankees/)
-   [A Rivalry Resumes](https://www.nytimes.com/2024/10/21/sports/baseball/yankees-dodgers-world-series.html)
-   [5 Storylines to Watch](https://www.nytimes.com/athletic/5858503/2024/10/20/yankees-dodgers-world-series-storylines-to-watch/)
-   [More From The Athletic](https://www.nytimes.com/athletic/mlb/)

[](https://www.nytimes.com/athletic/5875245/2024/10/26/world-series-game-2-yankees-dodgers/)

Dodgers Seize 2-0 Lead Over the Yankees in a Win Overshadowed by Injury

Shohei Ohtani exited the game late after suffering an injury while attempting to steal second base.

From The Athletic

[](https://www.nytimes.com/athletic/5875734/2024/10/27/dodgers-yankees-world-series-shohei-ohtani-injury/)

In a World Series Built on Stars, Shohei Ohtani's Absence Would Hurt

From The Athletic

[](https://www.nytimes.com/athletic/5875245/2024/10/26/world-series-game-2-yankees-dodgers/)

[](https://www.nytimes.com/2024/10/27/business/media/washington-post-president-endorsement.html)

Inside The Washington Post's Decision to Stop Presidential Endorsements

Jeff Bezos ended the decades-long practice, weeks after a discussion at a meeting in Miami. The move has drawn criticism in and outside the newsroom.

5 min read

[](https://www.nytimes.com/2024/10/26/us/los-angeles-times-endorsement-soon-shiong.html)

Daughter of L.A. Times Owner Says Its Endorsement Decision Stemmed From Harris Stance on Gaza War

10 min read

[](https://www.nytimes.com/2024/10/27/business/media/washington-post-president-endorsement.html)

[](https://www.nytimes.com/2024/10/27/world/africa/nigeria-dam-disaster-flood.html)

How Years of Failures in Nigeria Caused a Flood 'Worse Than Boko Haram'

After a recent dam disaster, officials blamed God, climate change and poor people. But experts had warned the dam was at risk. The officials did nothing.

6 min read

[](https://www.nytimes.com/2024/10/27/us/book-bans-school-boards-bucks-county.html)

Book Bans Live on in School District Now Run by Democrats.

Democrats swept a school board election in Pennsylvania after Republicans instituted book bans. But the "parental rights" movement has left an indelible mark.

7 min read

[](https://www.nytimes.com/2024/10/27/us/massachusetts-mcas-test-high-school.html)

Massachusetts, Famed for Tough School Standards, Rethinks Its Big Test

A ballot measure would do away with the requirement that high schoolers pass a test to graduate. Opponents say it could water down academics for struggling students.

4 min read

[](https://www.nytimes.com/2024/10/27/us/book-bans-school-boards-bucks-county.html)

![A man in a cap and blue vest walks toward a tan brick school building with two trees and two flags out front.]()

[](https://www.nytimes.com/2024/10/27/arts/music/chopin-waltz-discovery.html)

A Chopin Waltz Was Hidden for Nearly 200 Years. Now You Can Hear It.

A manuscript by Frédéric Chopin has emerged in a New York museum, the first such find in more than a half century. The pianist Lang Lang plays it here.

7 min read

[](https://www.nytimes.com/2024/10/27/briefing/chopin-lang-lang-classical-music.html)

The MorningNewsletter

How We Made a Classical Music Discovery

8 min read

1.  [](https://www.nytimes.com/2024/10/27/arts/music/chopin-waltz-discovery.html)

    Mohamed Sadek for The New York Times

## 

What to Watch and Read

[](https://www.nytimes.com/article/best-tv-shows-netflix.html)

The 50 Best TV Shows on Netflix Right Now

25 min read

![A shirtless muscly man with shoulder-length blond hair and a muscly man with a buzz cut wearing a black vest have a conversation in a dimly lit room.]()

[](https://www.nytimes.com/2024/10/25/movies/best-science-fiction-movies-streaming.html)

5 Science Fiction Movies to Stream Now

4 min read

![A bearded man in a green T-shirt navigates a boat through wooded water.]()

[](https://www.nytimes.com/2024/10/17/books/review/new-psychological-thrillers.html)

3 Psychological Thrillers That Will Creep You Out

4 min read

[](https://www.nytimes.com/2024/10/24/books/review/new-books-recommendations.html)

7 New Books We Recommend This Week

2 min read

![The cover of "Don't Be a Stranger" is a photograph of a red light switch on a hot pink background.]()

## [](https://www.nytimes.com/section/opinion)

Opinion

[](https://www.nytimes.com/2024/10/27/opinion/ted-cruz-texas-senate-race.html)

Michelle Cottle

Nevertheless, Ted Cruz Persists

10 min read

------------------------------------------------------------------------

[](https://www.nytimes.com/2024/09/30/opinion/editorials/kamala-harris-2024-endorsement.html)

The Editorial Board

The Only Patriotic Choice for President

8 min read

------------------------------------------------------------------------

[](https://www.nytimes.com/2024/10/27/opinion/washington-post-la-times-endorsements.html)

Nancy Gibbs

Two Billionaires, Two Newspapers, Two Acts of Self-Sabotage

4 min read

------------------------------------------------------------------------

[](https://www.nytimes.com/2024/10/27/opinion/never-trump-maga-evangelicals.html)

David French

Four Lessons From Nine Years of Being 'Never Trump'

6 min read

------------------------------------------------------------------------

[](https://www.nytimes.com/2024/10/27/opinion/president-coach-eisenhower.html)

Sam Walker

We've Had a Football Coach for President, and We Should Do It Again

4 min read

------------------------------------------------------------------------

[](https://www.nytimes.com/2024/10/26/opinion/donald-trump-gender-election.html)

Maureen Dowd

How Bad Do You Want It, Ladies?

4 min read

------------------------------------------------------------------------

[](https://www.nytimes.com/2024/10/26/opinion/sherrod-brown-ohio-election.html)

Alec MacGillis

Democrats Finally Did What Sherrod Brown Asked For. It Might Be Too Late.

8 min read

------------------------------------------------------------------------

[](https://www.nytimes.com/2024/10/22/opinion/donald-trump-ezra-klein-podcast.html)

Ezra Klein

What's Wrong With Donald Trump?

------------------------------------------------------------------------

[](https://www.nytimes.com/2024/10/26/opinion/trump-age-decline-behavior.html)

Nicholas Kristof

Trump Acts Erratically. Is This Age-Related Decline?

4 min read

[](https://www.nytimes.com/2024/10/23/opinion/election-polls-results-trump-harris.html)

Nate Silver: Here's What My Gut Says About the Election. But Don't Trust Anyone's Gut, Even Mine.

6 min read

[](https://www.nytimes.com/2024/10/26/opinion/wine-sober-october.html)

Boris Fishman

You'll Have to Take My Glass From My Cold, Wine-Stained Hand

4 min read

[](https://www.nytimes.com/2024/10/22/opinion/election-fraud-voting-security.html)

Neil Makhija

I Help Run Elections in My Pennsylvania County. The Right Is Being Lied To.

[](https://www.nytimes.com/live/2024/10/22/opinion/thepoint/liz-cheney-kamala-harris)

Patrick Healy

Liz Cheney Is Certain That Kamala Harris Will Win

3 min read

[](https://www.nytimes.com/2024/10/26/opinion/eminem-harris-gen-x.html)

Jessica Grose

Could Eminem Snap Gen X Voters Back to Reality?

5 min read

[](https://www.nytimes.com/2024/10/26/opinion/lina-khan-ftc-venture-capital-silicon-valley.html)

Nate Loewentheil

The Push to Fire Lina Khan Reveals a Serious Problem in Silicon Valley

4 min read

[](https://www.nytimes.com/2024/10/26/opinion/gender-election-voting-men-women-young.html)

Jamelle Bouie

We're Looking at the Wrong Gender Gap in Voting

4 min read

[](https://www.nytimes.com/card/2024/10/24/arts/crop-seed-art-minnesota)

[](https://www.nytimes.com/card/2024/10/24/arts/crop-seed-art-minnesota)

Making Masterpieces With Elmer's Glue and Mustard Seeds

Crop artists create mosaics that can take hundreds of hours of work. And there's no bigger showcase for them than the Minnesota State Fair.

------------------------------------------------------------------------

[](https://www.nytimes.com/2024/10/26/nyregion/tom-llamas-nbc.html)

Here's how one NBC anchor spends his Sundays.

6 min read

[](https://www.nytimes.com/2024/10/27/nyregion/metropolitan-diary.html)

In the Metropolitan Diary: "She pulled a packet of tissues from her bag and tried to take one out."

3 min read

[](https://www.nytimes.com/2024/10/25/dining/chili-secret-ingredient.html)

The secret ingredient every chili needs is probably in your pantry.

2 min read

[](https://www.nytimes.com/2024/10/25/magazine/return-policy-ethics.html)

The EthicistNewsletter

A reader asks: Is it OK to keep returning purchases you've worn for months?

7 min read

## 

In Case You Missed It

[](https://www.nytimes.com/interactive/2024/10/26/upshot/census-relative-income.html)

They Used to Be Ahead in the American Economy. Now They've Fallen Behind.

[](https://www.nytimes.com/2024/10/23/world/canada/newfoundland-canada-beach-blobs.html)

White 'Blobs' Washing Up on Canada's Shores Stump Residents and Scientists

3 min read

[](https://www.nytimes.com/2024/10/24/us/politics/boeing-email-ethiopian-airlines.html)

Email From Boeing to Ethiopian Airlines Sheds Light on a Tragic Crash

6 min read

[](https://www.nytimes.com/interactive/2024/10/24/realestate/upper-east-side-co-op-condo.html)

On the Upper East Side, Was \$800,000 Enough for a Two-Bedroom?

[](https://www.nytimes.com/2024/10/23/style/danny-amendola-dancing-with-the-stars-tiktok.html)

A Dance Trend That Comes With a Warning Label

3 min read

Advertisement

[SKIP ADVERTISEMENT](#after-dfp-ad-mid1)

## 

More News

[](https://www.nytimes.com/2024/10/26/world/asia/japan-election.html)

For the First Time in Decades, Japan Votes in a Knife-Edge Election

The Japanese electorate seemed poised to punish the Liberal Democrats, even if it does not go so far as to hand power to the opposition.

6 min read

[](https://www.nytimes.com/2024/10/25/nyregion/columbia-university-kathleen-franke.html)

Top Law Firms Shrink From the Heat of the Mideast Conflict

When a pro-Palestinian Columbia professor needed a lawyer, tensions over the Israel-Hamas war got in the way, our columnist writes.

6 min read

[](https://www.nytimes.com/2024/10/27/world/europe/naples-volcano-campi-flegrei-disaster-plan.html)

Living on a Volcano's Edge, Italians Practice for Disaster

The Italian authorities carried out a drill of their plan to save a half-million people from toxic fumes, deadly quakes or a full eruption.

5 min read

[](https://www.nytimes.com/2024/10/26/world/asia/india-temple-laddu.html)

![People wearing orange caps sit on a floor and roll out balls of golden sweets. Large trays contain finished balls.]()

The Curious Case of a Temple Sweet: How Food Increasingly Divides India

A Hindu politician has accused his Christian predecessor of allowing a temple's sanctity to be violated with an animal product.

4 min read

[](https://www.nytimes.com/athletic/5875747/2024/10/27/yamal-racist-abuse-real-madrid-barcelona-el-clasico/)

Real Madrid Says It Will Investigate Fans Suspected of Racially Abusing Lamine Yamal

From The Athletic

[](https://www.nytimes.com/athletic/5870026/2024/10/27/tua-tagovailoa-bryce-young-nfl-week-8/)

N.F.L. Week 8: Amid Struggles, a Young Quarterback Gets a Second Chance

From The Athletic

[](https://www.nytimes.com/2024/10/26/nyregion/daniel-penny-jury-consultant-ny-subway-choking.html)

Subway Chokehold Suspect Hires Jury Consultant Who Aided O.J. Simpson and Kyle Rittenhouse

6 min read

[](https://www.nytimes.com/athletic/5874967/2024/10/26/holden-trent-philadelphia-union-death/)

M.L.S. Player Holden Trent Dies at 25 Years Old

From The Athletic

[](https://www.nytimes.com/2024/10/26/world/europe/georgia-elections-russia-china-west.html)

Governing Party in Georgia Wins Election, as Opposition Calls for Protests

5 min read

[](https://www.nytimes.com/2024/10/26/business/dealbook/dei-backlash-advisers.html)

A New Business on Wall Street: Defending Against D.E.I. Backlash

8 min read

## [](https://www.nytimes.com/athletic/)

The Athletic

Sports coverage

[](https://www.nytimes.com/athletic/5867806/2024/10/25/jayden-daniels-washington-commanders-hope-nfl/)

Hope Is Dangerous in Washington, but a Rookie Quarterback Has D.C. Believing

It only took one practice for Commanders players to realize Jayden Daniels was different.

[](https://www.nytimes.com/athletic/5854102/2024/10/24/uncrustables-nfl/)

What's in an N.F.L. Diet? 80,000 Uncrustables Each Year.

Fever around the sealed peanut butter and jelly sandwiches is spreading around the league. The findings are nuts.

[](https://www.nytimes.com/athletic/5867806/2024/10/25/jayden-daniels-washington-commanders-hope-nfl/)

[](https://www.nytimes.com/athletic/5870030/2024/10/25/ohtani-japan-dodgers-yankees-world-series/)

Japan's Own National Pastime: Watching Shohei Ohtani in the World Series

People in Japan say it's hard to conceive of the popularity of the Dodgers superstar from an American perspective: "He has his own section of the news."

[](https://www.nytimes.com/athletic/5869794/2024/10/25/anthony-davis-zion-williamson-and-9-other-nba-players-ready-for-big-years/)

The 11 N.B.A. Players Poised for Breakout Seasons

[](https://www.nytimes.com/athletic/5870864/2024/10/24/amir-abdur-rahim-death-usf-coach/)

University of South Florida Coach Dies at 43 From Complications During Surgery

[](https://www.nytimes.com/athletic/5867884/2024/10/24/ole-miss-college-football-playoff-nil/)

A College Football Team With a \$10 Million Roster Is on the Brink of Failure

Advertisement

[SKIP ADVERTISEMENT](#after-dfp-ad-mid2)

## 

Well

[](https://www.nytimes.com/2024/09/30/well/eat/tuna-fish-mercury.html)

![Cuts of raw tuna are stacked on top of one another. A test tube of mercury leans against the stack.]()

The Truth About Tuna

5 min read

[](https://www.nytimes.com/2024/10/24/well/cdc-covid-vaccine-recommendations.html)

![Gloved hands inject a COVID-19 vaccine into a person\'s arm.]()

C.D.C. Expands Covid Vaccine Recommendations

2 min read

[](https://www.nytimes.com/2022/10/14/well/live/cold-flu-immune-system.html)

How to Boost Your Immune System This Fall

5 min read

[](https://www.nytimes.com/2024/10/21/well/what-is-pink-cocaine.html)

![Bags containing a powder known as tusi (or pink cocaine) sit on a gray surface with a blade.]()

Dangerous Party Drug Known as 'Pink Cocaine' Grows in Popularity

3 min read

[](https://www.nytimes.com/2024/09/19/well/pasta-chickpea-bean-legume.html)

![Close-up of a variety of pastas along with black beans and red lentils, all on a textured brown surface.]()

Are Chickpea and Bean Pastas Good for You?

4 min read

## 

Culture and Lifestyle

[](https://www.nytimes.com/2024/10/25/style/jonathan-otcasek-erin-kim-wedding.html)

They Were Just What They Needed

Jonathan Otcasek and Erin Kim connected 10 years ago over a gravesite. Since then, they've had the kind of relationship that even their parents admire.

6 min read

![Jonathan Otcasek and Erin Kim hold hands standing on a rooftop garden in New York City.]()

[](https://www.nytimes.com/2024/10/26/arts/podcasts-new-hobby.html)

7 Podcasts to Inspire a New Hobby

These shows spotlight tips from experts and interviews with casual hobbyists.

4 min read

![An illustration shows people surrounding a large microphone gardening, playing guitars, painting, sewing and making pottery.]()

[](https://www.nytimes.com/2024/10/24/arts/monique-knowlton-dead.html)

Monique Knowlton Dies at 87

A Vogue cover girl in the early 1960s, she later opened a gallery for contemporary art.

5 min read

![A black and white photo of a model, in a light-colored dress with ruffled sleeves, looking at stock market tape spooling out of a ticker-tape machine as a hairdresser also looks at the tape while lifting some of her hair high off her head. She wears thick-framed eyeglasses, and he, in a dark suit and tie, has a cigarette in his mouth.]()

[](https://www.nytimes.com/2024/10/26/style/erykah-badu-icon-award.html)

Erykah Badu, the Icon

Ms. Badu is set to receive one of fashion's highest honors.

4 min read

![Erykah Badu in a black dress and wide-brimmed black hat looking toward the camera.]()

## 

Games

Daily puzzles

[](https://www.nytimes.com/games/wordle/index.html)

Wordle

Guess the 5-letter word with 6 chances.

[](https://www.nytimes.com/games/connections?GAMES_connectionsRollout_1130=1_ConnectionsV2)

Connections

Group words that share a common thread.

[](https://www.nytimes.com/games/strands)

Strands

Uncover hidden words and reveal the theme.

[](https://www.nytimes.com/puzzles/spelling-bee)

Spelling Bee

How many words can you make with 7 letters?

[](https://www.nytimes.com/crosswords)

The Crossword

Get clued in with wordplay, every day.

[](http://www.nytimes.com/crosswords/game/mini)

The Mini Crossword

Take a break from the news. Solve this bite-sized puzzle in just a few minutes.

Advertisement

[SKIP ADVERTISEMENT](#after-dfp-ad-mid3)

## Site Index

## Site Information Navigation

-   [© 2024 The New York Times Company](https://help.nytimes.com/hc/en-us/articles/115014792127-Copyright-notice)

&nbsp;

-   [NYTCo](https://www.nytco.com/)
-   [Contact Us](https://help.nytimes.com/hc/en-us/articles/115015385887-Contact-Us)
-   [Accessibility](https://help.nytimes.com/hc/en-us/articles/115015727108-Accessibility)
-   [Work with us](https://www.nytco.com/careers/)
-   [Advertise](https://advertising.nytimes.com/)
-   [T Brand Studio](https://www.tbrandstudio.com/)
-   [Your Ad Choices](https://www.nytimes.com/privacy/cookie-policy#how-do-i-manage-trackers)
-   [Privacy Policy](https://www.nytimes.com/privacy/privacy-policy)
-   [Terms of Service](https://help.nytimes.com/hc/en-us/articles/115014893428-Terms-of-service)
-   [Terms of Sale](https://help.nytimes.com/hc/en-us/articles/115014893968-Terms-of-sale)
-   [Site Map](/sitemap/)
-   [Canada](https://www.nytimes.com/ca/)
-   [International](https://www.nytimes.com/international/)
-   [Help](https://help.nytimes.com/hc/en-us)
-   [Subscriptions](https://www.nytimes.com/subscription?campaignId=37WXW)

&nbsp;

# We\'ve updated our terms

We encourage you to review our updated [Terms of Sale](https://help.nytimes.com/hc/en-us/articles/115014893968-Terms-of-Sale), [Terms of Service](https://help.nytimes.com/hc/en-us/articles/115014893428-Terms-of-Service), and [Privacy Policy](https://help.nytimes.com/hc/en-us/articles/10940941449492-The-New-York-Times-Company-Privacy-Policy-). By continuing, you agree to the updated Terms listed here.

Continue