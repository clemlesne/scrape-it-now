# New York Times - Top Stories

[](https://www.nytimes.com/2024/10/27/us/politics/american-democracy-poll.html)

Voters Are Deeply Skeptical About the Health of American Democracy

Nearly half say it does not do a good job representing the people, and three-quarters say it is under threat, according to a Times/Siena poll.

7 min read

[](https://www.nytimes.com/2024/10/27/us/politics/trump-fascism.html)

Amid Talk of Fascism, Donald Trump's Threats and Language Evoke a Grim Past

Plenty of presidents have been called dictators by their opponents, but none until now has been publicly accused of being a "fascist" by his own handpicked advisers.

14 min read

[](https://www.nytimes.com/2024/10/27/us/politics/trump-and-harris-scrap-for-georgia-as-supporters-brace-for-a-photo-finish.html)

Trump and Harris Struggle for Georgia as Supporters Brace for a Photo Finish

6 min read

[](https://www.nytimes.com/2024/10/27/us/politics/american-democracy-poll.html)

------------------------------------------------------------------------

[](https://www.nytimes.com/2024/10/27/us/elections/beaver-country-football-walz.html)

This Town Has More Faith in Football Than Politics. Can Walz Make a Difference?

6 min read

[](https://www.nytimes.com/2024/10/27/us/politics/trump-new-york-msg.html)

Donald Trump Will Never Be Done With New York

4 min read

[](https://www.nytimes.com/2024/10/26/us/elections/election-security-luzerne-county.html)

Barricades and Bulletproof Glass: A County Prepares for Election Day

6 min read

------------------------------------------------------------------------

[](https://www.nytimes.com/interactive/2024/us/elections/polls-president.html)

### Latest Polling Averages

[](https://www.nytimes.com/interactive/2024/us/elections/polls-president.html)

#### National

40%

50%

48% Trump

49% Harris

[Pa. Harris \<1](https://www.nytimes.com/interactive/2024/us/elections/polls-president-pennsylvania.html)

[Nev. Trump \<1](https://www.nytimes.com/interactive/2024/us/elections/polls-president-nevada.html)

[N.C. Trump \<1](https://www.nytimes.com/interactive/2024/us/elections/polls-president-north-carolina.html)

[Mich. Harris \<1](https://www.nytimes.com/interactive/2024/us/elections/polls-president-michigan.html)

[Wis. Harris +1](https://www.nytimes.com/interactive/2024/us/elections/polls-president-wisconsin.html)

[Ga. Trump +1](https://www.nytimes.com/interactive/2024/us/elections/polls-president-georgia.html)

[Ariz. Trump +3](https://www.nytimes.com/interactive/2024/us/elections/polls-president-arizona.html)

[Minn. Harris +5](https://www.nytimes.com/interactive/2024/us/elections/polls-president-minnesota.html)

[Fla. Trump +6](https://www.nytimes.com/interactive/2024/us/elections/polls-president-florida.html)

### Races to Watch

-   [![President map thumbnail]()President ›](https://www.nytimes.com/interactive/2024/us/elections/presidential-election-swing-states.html)
-   [![Senate map thumbnail]()Senate ›](https://www.nytimes.com/interactive/2024/us/elections/senate-election-swing-states.html)
-   [![House map thumbnail]()House ›](https://www.nytimes.com/interactive/2024/us/elections/house-election-swing-districts.html)

-   [](https://www.nytimes.com/interactive/2024/10/16/us/politics/harris-trump-2024-campaign.html)
    ### On the Trail

    ![On the Trail]()
    See where the candidates are campaigning.
-   [](https://www.nytimes.com/interactive/2024/us/politics/trump-harris-issues-election.html)
    ### Key Issues

    ![Key Issues]()
    Here's where Trump and Harris stand.
-   [](https://www.nytimes.com/interactive/2024/us/elections/early-vote-tracker-2024.html)
    ### Early Voting

    ![Early Voting]()
    We're tracking in-person and mailed ballots by state.
-   [](https://www.nytimes.com/interactive/2024/us/politics/electoral-college-270-harris-trump.html)
    ### Electoral College Paths

    ![Electoral College Paths]()
    See how each candidate could reach 270 electoral votes.

## 

The Great Read

[](https://www.nytimes.com/2024/10/27/us/politics/springfield-ohio-family-trump-haitian-immigrants.html)

Their Son's Death Was Devastating. Then Politics Made It Worse.

Aiden Clark's death in a school bus accident in Ohio inspired conspiracy theories, campaign lies and anti-immigrant hate. His family is the latest target.

19 min read

1.  [](https://www.nytimes.com/2024/10/27/us/politics/springfield-ohio-family-trump-haitian-immigrants.html)

    The bus crash that killed 11-year-old Aiden Clark of Springfield, Ohio, was ruled an accident, caused by a legally registered Haitian immigrant driving without a valid license.

    Erin Schaff/The New York Times

2.  [](https://www.nytimes.com/2024/10/27/us/politics/springfield-ohio-family-trump-haitian-immigrants.html)

    But former President Donald Trump and his running mate, JD Vance, tell a different story: Aiden's death was a "murder" committed by "an illegal" as part of a "border blood bath."

    Erin Schaff/The New York Times

3.  [](https://www.nytimes.com/2024/10/27/us/politics/springfield-ohio-family-trump-haitian-immigrants.html)

    The Clarks had worked hard to seek out diversity in Springfield. But at city meetings, frustration about shifting demographics turned to anger, escalating into fear-mongering and racism.

    Erin Schaff/The New York Times

4.  [](https://www.nytimes.com/2024/10/27/us/politics/springfield-ohio-family-trump-haitian-immigrants.html)

    Some of the hatred turned toward the Clarks: cruel Facebook messages, letters about being "immigrant-loving race traitors" and a recent death threat relayed by the F.B.I.

    Erin Schaff/The New York Times

5.  [](https://www.nytimes.com/2024/10/27/us/politics/springfield-ohio-family-trump-haitian-immigrants.html)

    "Is there any decency left?" Nathan Clark said. "We'd at least like to be able to protect our son's memory."

    Erin Schaff/The New York Times

[Middle East Crisis](https://www.nytimes.com/news-event/israel-hamas-gaza)

-   [Why Israel Attacked Iran](https://www.nytimes.com/2024/10/25/world/middleeast/why-did-israel-attack-iran.html)
-   [Timeline of Recent Tensions](https://www.nytimes.com/article/israel-iran-conflict-history.html)
-   [Harsh Winter Looms in Gaza](https://www.nytimes.com/2024/10/23/world/middleeast/gaza-displaced-winter-tents.html)

[](https://www.nytimes.com/live/2024/10/27/world/israel-iran-lebanon-gaza)

LIVE

Oct. 27, 2024, 7:39 a.m. ETOct. 27

Iran's Leaders Stress Their Right to Respond to Israel's Strikes

Ayatollah Khamenei, Iran's supreme leader, appeared to take a measured tone. He said Israel's attack should not be "magnified or downplayed," state media said.

See more updates ›

[](https://www.nytimes.com/2024/10/26/world/middleeast/iran-israel-attack-public.html)

Israeli Attack Puts Iranians on Edge: 'The Vibe Is Not Normal'

3 min read

[](https://www.nytimes.com/2024/10/26/world/middleeast/iran-israel-attack-public.html)

[Russia-Ukraine War](https://www.nytimes.com/news-event/ukraine-russia)

-   [Photos](https://www.nytimes.com/2024/04/24/world/europe/images-ukraine-war-third-year.html)
-   [North Korea's Role](https://www.nytimes.com/2024/10/23/world/asia/north-korea-troops-russia-ukraine.html)
-   [A Spotlight on Troop Fatigue](https://www.nytimes.com/2024/10/19/world/europe/ukraine-troop-fatigue.html)
-   [A Russian Deserter's Escape](https://www.nytimes.com/interactive/2024/09/20/magazine/ukraine-russia-war-deserter.html)

[](https://www.nytimes.com/2024/10/27/world/europe/russia-kursk-ukraine-invasion-civilians.html)

Ukraine Invaded Russia. Here's What It Was Like for Civilians.

Russians in the area of Ukraine's invasion have described seeing signs of violent encounters, as well as respectful treatment from Ukrainian troops.

7 min read

Advertisement

LIVE

00:00

2:49

Why Are North Korean Troops in Russia?

2:49

[](https://www.nytimes.com/2024/10/27/arts/the-satanic-panic-that-never-goes-away.html)

IDEAS

The Satanic Panic That Never Goes Away

New movies and TV shows are revisiting a "weird corner" of the '80s --- and offering lessons for today.

Photo illustration by Ricardo Tomas

------------------------------------------------------------------------

[](https://www.nytimes.com/interactive/2024/10/25/briefing/quiz-trump-harris-north-korea-mcdonalds.html)

Did You Follow the News This Week? Take Our Quiz.

[](https://www.nytimes.com/interactive/2024/10/25/upshot/flashback.html)

Play Flashback, Your Weekly History Quiz

World Series

-   [Preview](https://www.nytimes.com/athletic/5858593/2024/10/21/dodgers-yankees-2024-world-series-preview-predictions/)
-   [Predictions](https://www.nytimes.com/athletic/5860718/2024/10/22/mlb-postseason-world-series-predictions-dodgers-yankees/)
-   [A Rivalry Resumes](https://www.nytimes.com/2024/10/21/sports/baseball/yankees-dodgers-world-series.html)
-   [5 Storylines to Watch](https://www.nytimes.com/athletic/5858503/2024/10/20/yankees-dodgers-world-series-storylines-to-watch/)
-   [More From The Athletic](https://www.nytimes.com/athletic/mlb/)

[](https://www.nytimes.com/athletic/5875245/2024/10/26/world-series-game-2-yankees-dodgers/)

Dodgers Seize 2-0 Lead Over the Yankees in a Win Overshadowed by Injury

Shohei Ohtani exited the game late after suffering an injury while attempting to steal second base.

From The Athletic

[](https://www.nytimes.com/athletic/5875734/2024/10/27/dodgers-yankees-world-series-shohei-ohtani-injury/)

In a World Series Built on Stars, Shohei Ohtani's Absence Would Hurt

From The Athletic

[](https://www.nytimes.com/athletic/5875245/2024/10/26/world-series-game-2-yankees-dodgers/)

[](https://www.nytimes.com/2024/10/27/business/media/washington-post-president-endorsement.html)

Inside The Washington Post's Decision to Stop Presidential Endorsements

Jeff Bezos ended the decades-long practice, weeks after a discussion at a meeting in Miami. The move has drawn criticism in and outside the newsroom.

5 min read

[](https://www.nytimes.com/2024/10/26/us/los-angeles-times-endorsement-soon-shiong.html)

Daughter of L.A. Times Owner Says Its Endorsement Decision Stemmed From Harris Stance on Gaza War

10 min read

[](https://www.nytimes.com/2024/10/27/business/media/washington-post-president-endorsement.html)

[](https://www.nytimes.com/2024/10/27/world/africa/nigeria-dam-disaster-flood.html)

How Years of Failures in Nigeria Caused a Flood 'Worse Than Boko Haram'

After a recent dam disaster, officials blamed God, climate change and poor people. But experts had warned the dam was at risk. The officials did nothing.

6 min read

[](https://www.nytimes.com/2024/10/27/us/book-bans-school-boards-bucks-county.html)

Book Bans Live on in School District Now Run by Democrats.

Democrats swept a school board election in Pennsylvania after Republicans instituted book bans. But the "parental rights" movement has left an indelible mark.

7 min read

[](https://www.nytimes.com/2024/10/27/us/massachusetts-mcas-test-high-school.html)

Massachusetts, Famed for Tough School Standards, Rethinks Its Big Test

A ballot measure would do away with the requirement that high schoolers pass a test to graduate. Opponents say it could water down academics for struggling students.

4 min read

[](https://www.nytimes.com/2024/10/27/us/book-bans-school-boards-bucks-county.html)

![A man in a cap and blue vest walks toward a tan brick school building with two trees and two flags out front.]()

[](https://www.nytimes.com/2024/10/27/arts/music/chopin-waltz-discovery.html)

A Chopin Waltz Was Hidden for Nearly 200 Years. Now You Can Hear It.

A manuscript by Frédéric Chopin has emerged in a New York museum, the first such find in more than a half century. The pianist Lang Lang plays it here.

7 min read

[](https://www.nytimes.com/2024/10/27/briefing/chopin-lang-lang-classical-music.html)

The MorningNewsletter

How We Made a Classical Music Discovery

8 min read

1.  [](https://www.nytimes.com/2024/10/27/arts/music/chopin-waltz-discovery.html)

    Mohamed Sadek for The New York Times

## 

What to Watch and Read

[](https://www.nytimes.com/2024/11/01/movies/martha-netflix-documentary.html)

A Prickly Martha Stewart Makes for a Bracing Netflix Portrait

3 min read

![In a scene from the documentary, Martha Stewart, in all black, sits in a nicely appointed room looking off-camera.]()

[](https://www.nytimes.com/2024/10/25/arts/television/somebody-somewhere-final-season.html)

'Somebody Somewhere' Is Going Out on a Bittersweet Note

5 min read

![Paul Thureen and Hannah Bos and stand beside each other, smiling.]()

[](https://www.nytimes.com/2024/10/25/books/review/sarah-moss-my-good-bright-wolf.html)

Book Review

A Chilling True Fable of Anorexia

4 min read

![Fans of Moss's novels will recognize in this memoir the ominous air of danger, the alertness to class issues and the figure of a bright, spiky woman chafing against restrictions.]()

[](https://www.nytimes.com/2024/10/31/books/review/new-crime-books.html)

4 Smart, Riveting New Crime Novels

4 min read

![A line drawing shows a couple gazing at a hillside dotted with houses. One of the figures is headless.]()

## [](https://www.nytimes.com/section/opinion)

Opinion

[](https://www.nytimes.com/2024/10/27/opinion/ted-cruz-texas-senate-race.html)

Michelle Cottle

Nevertheless, Ted Cruz Persists

10 min read

------------------------------------------------------------------------

[](https://www.nytimes.com/2024/09/30/opinion/editorials/kamala-harris-2024-endorsement.html)

The Editorial Board

The Only Patriotic Choice for President

8 min read

------------------------------------------------------------------------

[](https://www.nytimes.com/2024/10/27/opinion/washington-post-la-times-endorsements.html)

Nancy Gibbs

Two Billionaires, Two Newspapers, Two Acts of Self-Sabotage

4 min read

------------------------------------------------------------------------

[](https://www.nytimes.com/2024/10/27/opinion/never-trump-maga-evangelicals.html)

David French

Four Lessons From Nine Years of Being 'Never Trump'

6 min read

------------------------------------------------------------------------

[](https://www.nytimes.com/2024/10/27/opinion/president-coach-eisenhower.html)

Sam Walker

We've Had a Football Coach for President, and We Should Do It Again

4 min read

------------------------------------------------------------------------

[](https://www.nytimes.com/2024/10/26/opinion/donald-trump-gender-election.html)

Maureen Dowd

How Bad Do You Want It, Ladies?

4 min read

------------------------------------------------------------------------

[](https://www.nytimes.com/2024/10/26/opinion/sherrod-brown-ohio-election.html)

Alec MacGillis

Democrats Finally Did What Sherrod Brown Asked For. It Might Be Too Late.

8 min read

------------------------------------------------------------------------

[](https://www.nytimes.com/2024/10/22/opinion/donald-trump-ezra-klein-podcast.html)

Ezra Klein

What's Wrong With Donald Trump?

------------------------------------------------------------------------

[](https://www.nytimes.com/2024/10/26/opinion/trump-age-decline-behavior.html)

Nicholas Kristof

Trump Acts Erratically. Is This Age-Related Decline?

4 min read

[](https://www.nytimes.com/2024/10/23/opinion/election-polls-results-trump-harris.html)

Nate Silver: Here's What My Gut Says About the Election. But Don't Trust Anyone's Gut, Even Mine.

6 min read

[](https://www.nytimes.com/2024/10/26/opinion/wine-sober-october.html)

Boris Fishman

You'll Have to Take My Glass From My Cold, Wine-Stained Hand

4 min read

[](https://www.nytimes.com/2024/10/22/opinion/election-fraud-voting-security.html)

Neil Makhija

I Help Run Elections in My Pennsylvania County. The Right Is Being Lied To.

[](https://www.nytimes.com/live/2024/10/22/opinion/thepoint/liz-cheney-kamala-harris)

Patrick Healy

Liz Cheney Is Certain That Kamala Harris Will Win

3 min read

[](https://www.nytimes.com/2024/10/26/opinion/eminem-harris-gen-x.html)

Jessica Grose

Could Eminem Snap Gen X Voters Back to Reality?

5 min read

[](https://www.nytimes.com/2024/10/26/opinion/lina-khan-ftc-venture-capital-silicon-valley.html)

Nate Loewentheil

The Push to Fire Lina Khan Reveals a Serious Problem in Silicon Valley

4 min read

[](https://www.nytimes.com/2024/10/26/opinion/gender-election-voting-men-women-young.html)

Jamelle Bouie

We're Looking at the Wrong Gender Gap in Voting

4 min read

[](https://www.nytimes.com/interactive/2024/11/07/realestate/east-side-studio-apartment-sale.html)

[](https://www.nytimes.com/interactive/2024/11/07/realestate/east-side-studio-apartment-sale.html)

Two Empty Nesters Flew to New York With \$600,000 for a Studio

With their daughter in college on Long Island, an Atlanta couple looked for a second home in Manhattan so they could visit more often.

------------------------------------------------------------------------

[](https://www.nytimes.com/2024/11/06/style/extramarital-affairs.html)

Their daughter is having an affair with a married man. What should they do?

4 min read

[](https://www.nytimes.com/interactive/2023/07/07/well/live/sleep-better-age.html)

Try these tips to sleep better at every age.

[](https://www.nytimes.com/2024/11/05/style/high-sport-pleats-please-pants.html)

Wearing these pants, to some fashion enthusiasts, is akin to carrying "it" bags.

3 min read

[](https://www.nytimes.com/2024/11/05/well/how-to-treat-plantar-warts.html)

Here's what to know about plantar warts, and the best ways to get rid of them.

4 min read

## 

Most Commented

[](https://www.nytimes.com/2024/11/05/realestate/conceal-small-kitchen-appliances-clutter.html)

Eliminating Kitchen Clutter Has Never Looked More Stylish

5 min read

[](https://www.nytimes.com/2024/11/05/opinion/uncertainty.html)

Opinion

Advice From a Psychotherapist on How to Cope Today

4 min read

[](https://www.nytimes.com/2024/01/11/style/sleepunders-lateovers-sleepovers.html)

Sweetie, I'll Be Back at 2 A.M.

[](https://www.nytimes.com/2024/11/07/dining/turkey-hunting-minnesota.html)

Where the Turkey Comes From the Field, Not the Freezer

6 min read

[](https://www.nytimes.com/2024/11/05/well/how-to-treat-plantar-warts.html)

What's the Best Way to Get Rid of Plantar Warts?

4 min read

Advertisement

[SKIP ADVERTISEMENT](#after-dfp-ad-mid1)

## 

More News

[](https://www.nytimes.com/2024/10/26/world/asia/japan-election.html)

For the First Time in Decades, Japan Votes in a Knife-Edge Election

The Japanese electorate seemed poised to punish the Liberal Democrats, even if it does not go so far as to hand power to the opposition.

6 min read

[](https://www.nytimes.com/2024/10/25/nyregion/columbia-university-kathleen-franke.html)

Top Law Firms Shrink From the Heat of the Mideast Conflict

When a pro-Palestinian Columbia professor needed a lawyer, tensions over the Israel-Hamas war got in the way, our columnist writes.

6 min read

[](https://www.nytimes.com/2024/10/27/world/europe/naples-volcano-campi-flegrei-disaster-plan.html)

Living on a Volcano's Edge, Italians Practice for Disaster

The Italian authorities carried out a drill of their plan to save a half-million people from toxic fumes, deadly quakes or a full eruption.

5 min read

[](https://www.nytimes.com/2024/10/26/world/asia/india-temple-laddu.html)

![People wearing orange caps sit on a floor and roll out balls of golden sweets. Large trays contain finished balls.]()

The Curious Case of a Temple Sweet: How Food Increasingly Divides India

A Hindu politician has accused his Christian predecessor of allowing a temple's sanctity to be violated with an animal product.

4 min read

[](https://www.nytimes.com/2024/11/07/weather/snow-storm-new-mexico-colorado.html)

Several Feet of Snow Are Forecast in New Mexico and Colorado

2 min read

[](https://www.nytimes.com/athletic/5905910/2024/11/07/raygun-retires-breaking-olympics/)

Raygun Retires From Competitive Breaking After Intense Olympic Backlash

From The Athletic

[](https://www.nytimes.com/2024/11/07/business/canada-tiktok.html)

Canada Shuts TikTok's Offices Over National Security Risks

2 min read

[](https://www.nytimes.com/2024/11/07/world/asia/pakistan-air-pollution-punjab.html)

Record Air Pollution Hospitalizes Hundreds in Pakistani City

3 min read

[](https://www.nytimes.com/2024/11/06/world/europe/geoff-capes-dead.html)

Geoff Capes, World's Strongest Man and Champion Bird Breeder, Dies at 75

5 min read

[](https://www.nytimes.com/2024/11/06/us/salisbury-university-students-arrested.html)

7 Salisbury U. Students Beat Person Because of Sexual Orientation, Police Say

3 min read

## [](https://www.nytimes.com/athletic/)

The Athletic

Sports coverage

[](https://www.nytimes.com/athletic/5867806/2024/10/25/jayden-daniels-washington-commanders-hope-nfl/)

Hope Is Dangerous in Washington, but a Rookie Quarterback Has D.C. Believing

It only took one practice for Commanders players to realize Jayden Daniels was different.

[](https://www.nytimes.com/athletic/5854102/2024/10/24/uncrustables-nfl/)

What's in an N.F.L. Diet? 80,000 Uncrustables Each Year.

Fever around the sealed peanut butter and jelly sandwiches is spreading around the league. The findings are nuts.

[](https://www.nytimes.com/athletic/5867806/2024/10/25/jayden-daniels-washington-commanders-hope-nfl/)

[](https://www.nytimes.com/athletic/5870030/2024/10/25/ohtani-japan-dodgers-yankees-world-series/)

Japan's Own National Pastime: Watching Shohei Ohtani in the World Series

People in Japan say it's hard to conceive of the popularity of the Dodgers superstar from an American perspective: "He has his own section of the news."

[](https://www.nytimes.com/athletic/5869794/2024/10/25/anthony-davis-zion-williamson-and-9-other-nba-players-ready-for-big-years/)

The 11 N.B.A. Players Poised for Breakout Seasons

[](https://www.nytimes.com/athletic/5870864/2024/10/24/amir-abdur-rahim-death-usf-coach/)

University of South Florida Coach Dies at 43 From Complications During Surgery

[](https://www.nytimes.com/athletic/5867884/2024/10/24/ole-miss-college-football-playoff-nil/)

A College Football Team With a \$10 Million Roster Is on the Brink of Failure

Advertisement

[SKIP ADVERTISEMENT](#after-dfp-ad-mid2)

## 

Well

[](https://www.nytimes.com/2024/07/12/well/teeth-dental-coffee-charcoal-toothpaste.html)

![A close-up of a person flossing their teeth.]()

The Best and Worst Habits for Your Teeth

4 min read

[](https://www.nytimes.com/2024/01/30/well/live/chapped-lip-balm.html)

![A tight shot of lip balm being applied to lips. ]()

Is Lip Balm Making My Chapped Lips Worse?

3 min read

[](https://www.nytimes.com/interactive/2022/11/10/well/eat/vegetable-healthy-raw-cooked.html)

Is This Vegetable Healthier Raw or Cooked? Take the Quiz.

[](https://www.nytimes.com/2023/10/15/well/family/sex-myths.html)

![An illustration of two people sitting closely, facing each other, with their legs overlapping. One person is gently holding the face of the other. Abstract shapes with an orange and purple gradient are surrounding them.]()

8 Sex Myths That Experts Wish Would Go Away

7 min read

[](https://www.nytimes.com/interactive/2023/02/22/well/eat/gut-microbiome-health.html)

The Wild World Inside Your Gut

## 

Culture and Lifestyle

[](https://www.nytimes.com/2024/10/25/style/jonathan-otcasek-erin-kim-wedding.html)

They Were Just What They Needed

Jonathan Otcasek and Erin Kim connected 10 years ago over a gravesite. Since then, they've had the kind of relationship that even their parents admire.

6 min read

![Jonathan Otcasek and Erin Kim hold hands standing on a rooftop garden in New York City.]()

[](https://www.nytimes.com/2024/11/06/movies/elevation-review.html)

MOVIE REVIEW

'Elevation'

Humans flee monsters who refuse to surpass 8,000 feet in altitude.

1 min read

![Two women and a man, all wearing coats, have a conversation on a tall perch overlooking mountains. The man is holding a map.]()

[](https://www.nytimes.com/2024/11/06/movies/leni-riefenstahl-documentary-nuba-photographs.html)

New Debate Over Filmmaker's Nazi Ties

Recent access to Leni Riefenstahl's estate has prompted new discussions.

4 min read

![A black-and-white image of Leni Riefenstahl behind a camera, with men behind her.]()

[](https://www.nytimes.com/2024/11/06/realestate/claremont-hall-luxury-tower-morningside-heights.html)

A New Tower Rises From a Seminary

The luxury building tries not to disrupt Morningside Heights in New York.

4 min read

## 

Games

Daily puzzles

[](https://www.nytimes.com/games/wordle/index.html)

Wordle

Guess the 5-letter word with 6 chances.

[](https://www.nytimes.com/games/connections?GAMES_connectionsRollout_1130=1_ConnectionsV2)

Connections

Group words that share a common thread.

[](https://www.nytimes.com/games/strands)

Strands

Uncover hidden words and reveal the theme.

[](https://www.nytimes.com/puzzles/spelling-bee)

Spelling Bee

How many words can you make with 7 letters?

[](https://www.nytimes.com/crosswords)

The Crossword

Get clued in with wordplay, every day.

[](http://www.nytimes.com/crosswords/game/mini)

The Mini Crossword

Take a break from the news. Solve this bite-sized puzzle in just a few minutes.

Advertisement

[SKIP ADVERTISEMENT](#after-dfp-ad-mid3)