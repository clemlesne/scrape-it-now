Javascript est desactivé dans votre navigateur.

-   [Contenu](https://www.service-public.fr/particuliers/vosdroits/F2057#main)
-   [Menu](https://www.service-public.fr/particuliers/vosdroits/F2057#header-navigation)
-   [Recherche](https://www.service-public.fr/particuliers/vosdroits/F2057#header-search-main)
-   [Pied de page](https://www.service-public.fr/particuliers/vosdroits/F2057#footer)

République\
Française

Ouvrir la recherche

Menu

[](https://www.service-public.fr/ "Accueil Service-Public.fr")

Service-Public.fr

Le site officiel de l'administration française

-   [Se connecter](https://www.service-public.fr/compte/se-connecter)
-   [Accéder au site pour les entreprises](https://entreprendre.service-public.fr/ "Accéder au site pour les entreprises - nouvelle fenêtre")

Fermer

Recherche

Des suggestions vous seront proposées lors de votre saisie situées après le champ

Rechercher sur le site

Fermer

-   [Se connecter](https://www.service-public.fr/compte/se-connecter)
-   [Accéder au site pour les entreprises](https://entreprendre.service-public.fr/ "Accéder au site pour les entreprises - nouvelle fenêtre")

-   [Actualité\
    de vos droits et démarches](https://www.service-public.fr/particuliers/actualites)
-   Fiches pratiques\
    par événement de vie
    -   [Je déménage](https://www.service-public.fr/particuliers/vosdroits/F14128)
    -   [Je cherche un emploi](https://www.service-public.fr/particuliers/vosdroits/F17556)
    -   [J'attends un enfant](https://www.service-public.fr/particuliers/vosdroits/F16225)
    -   [Je veux obtenir un crédit immobilier](https://www.service-public.fr/particuliers/vosdroits/F16123)
    -   [J\'achète un logement](https://www.service-public.fr/particuliers/vosdroits/F15913)
    -   [Je prépare ma retraite](https://www.service-public.fr/particuliers/vosdroits/F17904)
    -   [Un proche est décédé](https://www.service-public.fr/particuliers/vosdroits/F16507)
    -   [Voir tous les événements de vie](https://www.service-public.fr/particuliers/vosdroits/comment-faire-si)
-   Fiches pratiques\
    par thème
    -   [Papiers - Citoyenneté - Élections](https://www.service-public.fr/particuliers/vosdroits/N19810)
    -   [Famille - Scolarité](https://www.service-public.fr/particuliers/vosdroits/N19805)
    -   [Social - Santé](https://www.service-public.fr/particuliers/vosdroits/N19811)
    -   [Travail - Formation](https://www.service-public.fr/particuliers/vosdroits/N19806)
    -   [Logement](https://www.service-public.fr/particuliers/vosdroits/N19808)
    -   [Transports - Mobilité](https://www.service-public.fr/particuliers/vosdroits/N19812)
    -   [Argent - Impôts - Consommation](https://www.service-public.fr/particuliers/vosdroits/N19803)
    -   [Voir tous les thèmes](https://www.service-public.fr/particuliers/vosdroits/theme)
-   Démarches\
    et outils
    -   [Démarches en ligne](https://www.service-public.fr/particuliers/recherche?rubricFilter=serviceEnLigne&rubricTypeFilter=teleservice)
    -   [Simulateurs](https://www.service-public.fr/particuliers/recherche?rubricFilter=serviceEnLigne&rubricTypeFilter=simulateur)
    -   [Modèles de lettres](https://www.service-public.fr/particuliers/recherche?rubricFilter=serviceEnLigne&rubricTypeFilter=modeleLettre)
    -   [Formulaires administratifs (cerfas)](https://www.service-public.fr/particuliers/recherche?rubricFilter=serviceEnLigne&rubricTypeFilter=formulaire)
    -   [Outils de recherche](https://www.service-public.fr/particuliers/recherche?rubricFilter=serviceEnLigne&rubricTypeFilter=outilrecherche)
-   [Annuaire\
    de l'administration](https://lannuaire.service-public.fr/)
-   [Contacter\
    Service-Public.fr](https://www.service-public.fr/P10017)

[Accéder au site pour les entreprises ](https://entreprendre.service-public.fr/ "Accéder au site pour les entreprises - nouvelle fenêtre")

Voir le fil d\'ariane

1.  [Accueil](https://www.service-public.fr/particuliers)
2.  [Logement](https://www.service-public.fr/particuliers/vosdroits/N19808)
3.  [Achat d\'un terrain](https://www.service-public.fr/particuliers/vosdroits/N312)
4.  Promesse de vente d\'un terrain isolé à bâtir

-   
    Focus

FR - Français

-   [FR - Français](https://www.service-public.fr/particuliers/vosdroits/F2057)
-   [EN - English](https://www.service-public.fr/particuliers/vosdroits/F2057?lang=en)

Partager la page

-   [Facebook](https://www.facebook.com/sharer/sharer.php?u=https://www.service-public.fr/particuliers/vosdroits/F2057 "Partager sur Facebook - facebook.com - Nouvelle fenêtre")

-   [X](https://x.com/intent/tweet?text=Promesse%20de%20vente%20d%27un%20terrain%20isol%C3%A9%20%C3%A0%20b%C3%A2tir&url=https://www.service-public.fr/particuliers/vosdroits/F2057 "Partager sur X (anciennement Twitter) - x.com - Nouvelle fenêtre")

-   [Linkedin](https://www.linkedin.com/shareArticle?mini=true&url=https://www.service-public.fr/particuliers/vosdroits/F2057&title=Promesse%20de%20vente%20d%27un%20terrain%20isol%C3%A9%20%C3%A0%20b%C3%A2tir "Partager sur LinkedIn - linkedin.com - Nouvelle fenêtre")

-   [Email](mailto:%20?subject=Service-Public.fr%20-%20Promesse%20de%20vente%20d%27un%20terrain%20isol%C3%A9%20%C3%A0%20b%C3%A2tir&body=Bonjour,%0D%0A%0D%0ACette%20information%20de%20service-public.fr%20vous%20est%20conseill%C3%A9e%20:%20%0D%0A%0D%0APromesse%20de%20vente%20d%27un%20terrain%20isol%C3%A9%20%C3%A0%20b%C3%A2tir%0D%0A%0D%0Ahttps://www.service-public.fr/particuliers/vosdroits/F2057 "Envoyer par Email")

-   Copier le lien

Votre abonnement a bien été pris en compte

Vous serez **alerté(e) par email** dès que la page « **Promesse de vente d\'un terrain isolé à bâtir** » sera mise à jour significativement.

Vous pouvez à tout moment supprimer votre abonnement dans votre compte [service-public.fr](https://www.service-public.fr/compte/mes-alertes) .

Votre abonnement n'a pas pu être pris en compte.

Vous devez vous connecter à votre espace personnel afin de vous abonner à la mise à jour de cette page.

Être alerté(e) en cas de changement

**Ce sujet vous intéresse ?**\
Connectez-vous à votre compte et recevez une **alerte par email** dès que l'information de la page « **Promesse de vente d\'un terrain isolé à bâtir** » est mise à jour.

Pour vous abonner aux mises à jour des pages service-public.fr, **vous devez activer votre espace personnel**.

Vous serez **alerté(e) par courriel** dès que la page « **Promesse de vente d\'un terrain isolé à bâtir** » sera mise à jour significativement.

ACTIVER MON ESPACE PERSONNEL

### Le lien vers cette page a été envoyé avec succès aux destinataires.

# Promesse de vente d\'un terrain isolé à bâtir

Vérifié le 27 juin 2023 - Direction de l\'information légale et administrative (Premier ministre)

Droit sur un bien immobilier accordé à une personne à qui l\'on doit de l\'argent en garantie du paiement de sa dette

Contrainte imposée à une propriété au profit d\'une autre propriété (par exemple, un droit de passage)

Rémunération des services rendus par les membres de certaines professions libérales (médecins, notaires, avocats, architectes, etc.)

Acte rédigé et signé par des particuliers, sans la présence d\'un notaire (par exemple, un contrat)

Document établi par un officier public compétent, tels qu\'un notaire, un commissaire de justice (anciennement huissier de justice et commissaire-priseur judiciaire), un officier d\'état civil, rédigé selon les formalités exigées par la loi et dont le contenu peut avoir la même valeur qu\'une décision judiciaire

Correspond à tous les jours de la semaine, à l\'exception du jour de repos hebdomadaire (généralement le dimanche) et des jours fériés habituellement non travaillés dans l\'entreprise

Suspend l\'exécution d\'un contrat tant qu\'un événement futur et incertain n\'est pas survenu

Individu qui possède une personnalité juridique, ce qui lui permet de conclure des actes juridiques.

Document complémentaire du contrat constatant une modification, une adaptation ou un complément qui y sont apportés d\'un commun accord entre les 2 parties

Compte bancaire professionnel dédié à mettre en dépôt les fonds (sommes d\'argent), versés en acompte par l\'acquéreur d\'un bien lors d\'une transaction (immobilière)

Vous envisagez d\'acheter ou de vendre un terrain à bâtir (hors lotissement). Vous allez signer une promesse de vente. C\'est un contrat qui prépare l\'acte définitif de vente. Il prend la forme d\'une **promesse unilatérale de vente** s\'il est signé uniquement par le vendeur ou d\'un **compromis de vente** s\'il est signé par le vendeur et l\'acheteur.

Nous faisons le point sur le contenu, la forme et la signature de ces 2 documents.

-   Promesse unilatérale de vente
-   Compromis de vente

## Promesse unilatérale de vente

Tout déplier

La promesse unilatérale de vente est **signée uniquement par le vendeur**. Elle l\'engage à vendre son terrain à un **acheteur déterminé** et à un **prix fixé dans la promesse**.

Pendant toute la durée de validité de la promesse, le vendeur ne peut pas laisser son bien sur le marché ou le vendre à un autre acheteur.

L\'**acheteur bénéficie d\'une option d\'achat** dans un délai défini par les 2 parties. Elle lui donne le droit d\'acheter le bien sans pour autant l\'y obliger.

La promesse de vente donne notamment les informations suivantes :

-   **Coordonnées** du vendeur et de l\'acheteur
-   **Descriptif détaillé du terrain** et sa surface exacte (adresse, références cadastrales\...)
-   **Prix** de vente et **modes de paiement** (avec ou sans l\'aide d\'un prêt immobilier)
-   **[Condition suspensive](https://www.service-public.fr/particuliers/vosdroits/F188 "Promesse de vente et condition suspensive d'obtention du prêt : de quoi s'agit-il ?")** [de prêt](https://www.service-public.fr/particuliers/vosdroits/F188 "Promesse de vente et condition suspensive d'obtention du prêt : de quoi s'agit-il ?") si vous prenez un crédit immobilier
-   Condition suspensive d\'obtention d\'un [permis de construire](https://www.service-public.fr/particuliers/vosdroits/F1986 "Permis de construire") si vous en demandez un
-   Existence ou non d\'un ****[bornage](https://www.service-public.fr/particuliers/vosdroits/F3037 "Bornage de terrains")**** du terrain
-   Existence ou non d\'**hypothèqueDroit sur un bien immobilier accordé à une personne à qui l\'on doit de l\'argent en garantie du paiement de sa dette** et de servitudeContrainte imposée à une propriété au profit d\'une autre propriété (par exemple, un droit de passage) sur le terrain
-   Montant des honorairesRémunération des services rendus par les membres de certaines professions libérales (médecins, notaires, avocats, architectes, etc.) du professionnel chargé de la vente (s\'il y a intervention d\'un professionnel) et nom de la personne devant payer ces honoraires
-   Montant de l\'**indemnité d\'immobilisation** du terrain (en contrepartie de l\'engagement pris par le vendeur de vendre exclusivement à l\'acheteur)
-   **Durée de validité** de la promesse de vente
-   **Date limite de signature de [l\'acte de vente](https://www.service-public.fr/particuliers/vosdroits/F258 "Acte de vente d'un terrain à bâtir isolé") **(elle intervient généralement 3 mois après la signature de la promesse de vente)
-   **Délai** accordé à l\'acheteur pour **lever l\'option d\'achat**

##### Documents annexés à la promesse de vente

-   [État des risques et pollutions (naturels, miniers, technologiques, sismiques, radon\...)](https://www.service-public.fr/particuliers/vosdroits/F12239 "Diagnostic immobilier : état des risques")
-   Étude de sol **dans les zones exposées** au phénomène de mouvement de terrain différentiel consécutif à la sécheresse et à la réhydratation des **sols argileux**
-   [État des nuisances sonores aériennes](https://www.service-public.fr/particuliers/vosdroits/F35266 "Diagnostic immobilier sur les bruits des aéroports") **dans les zones de bruit** définies par un plan d\'exposition au bruit

La promesse de vente prend la forme d\'un **acte sous signature privéeActe rédigé et signé par des particuliers, sans la présence d\'un notaire (par exemple, un contrat)** ou d\'un acte authentiqueDocument établi par un officier public compétent, tels qu\'un notaire, un commissaire de justice (anciennement huissier de justice et commissaire-priseur judiciaire), un officier d\'état civil, rédigé selon les formalités exigées par la loi et dont le contenu peut avoir la même valeur qu\'une décision judiciaire.

Quand la durée de validité d\'une promesse de vente signée par une personne physique dépasse 18 mois, il est obligatoire de signer un acte authentique.

La promesse peut être signée sur support papier ou electronique.

Répondez aux questions successives et les réponses s'afficheront automatiquement

#### Support papier

Il est réalisé 2 exemplaires originaux (1 pour le vendeur, 1 pour l\'acheteur), sauf si un original unique est conservé par un professionnel (notaire, agent immobilier).

#### Support électronique

Le procédé de signature et de conservation de l\'acte doit permettre à chaque partie d\'avoir un exemplaire de la promese ou d\'y avoir accès.

Vous avez choisi

Choisissez votre cas

-    Support papier
-    Support électronique

#### Support papier

Il est réalisé 2 exemplaires originaux (1 pour le vendeur, 1 pour l\'acheteur), sauf si un original unique est conservé par un professionnel (notaire, agent immobilier).

#### Support électronique

Le procédé de signature et de conservation de l\'acte doit permettre à chaque partie d\'avoir un exemplaire de la promese ou d\'y avoir accès.

Pour être valable, la promesse unilatérale de vente **sous signature privée** doit être **enregistrée au bureau d\'enregistrement du centre des impôts** par le vendeur ou l\'acheteur.

###### Où s'adresser ?

Pivot Local Quelle est votre ville ou code postal ? Exemple : Sainte-Cécile-les-Vignes ou 95200

Des suggestions vous seront proposées lors de votre saisie situées après le champ

-   [Centre des impôts fonciers et cadastre ](https://www.impots.gouv.fr/portail/contacts "Centre des impôts fonciers et cadastre - www.impots.gouv.fr - Nouvelle fenêtre")

La démarche s\'effectue dans les 10 jours ouvrablesCorrespond à tous les jours de la semaine, à l\'exception du jour de repos hebdomadaire (généralement le dimanche) et des jours fériés habituellement non travaillés dans l\'entreprise à compter de la date d\'acceptation de la promesse par l\'acheteur (en principe le jour de sa signature).

L\'enregistrement coûte 125 €.

Une **indemnité d\'immobilisation** du terrain peut être demandée à l\'acheteur. Elle est versée en contrepartie de l\'engagement pris par le vendeur de vendre son terrain exclusivement à l\'acheteur.

L\'indemnité est **versée le jour de la signature de la promesse de vente**. Elle est fixée librement par les parties. En principe, elle représente 5 % à 10 % du prix de vente.

Elle est consignée sur un compte bloqué. Les fonds sont **indisponibles** jusqu\'à la conclusion du contrat de vente.

**Si les conditions suspensivesSuspend l\'exécution d\'un contrat tant qu\'un événement futur et incertain n\'est pas survenu prévues dans la promesse ne se réalisent pas**, l\'indemnité est rendue. L\'acheteur doit apporter la preuve qu\'il a bien effectué les démarches correspondantes (demande d\'emprunt à la banque, demande d\'urbanisme en mairie\...).

**Si le bénéficiaire de la promesse renonce à acheter** ou s\'il ne manifeste pas son acceptation dans le délai de levée d\'option, l\'indemnité est conservée par le propriétaire.

**Quand la vente se réalise**, la somme versée est déduite du prix de vente à payer.

À noter

L\'indemnité d\'immobilisation est obligatoire quand la promesse de vente signée par une personne physiqueIndividu qui possède une personnalité juridique, ce qui lui permet de conclure des actes juridiques. a une durée de plus de 18 mois.

L\'acheteur d\'un terrain à bâtir ne bénéficie pas du droit de rétractation.

Le vendeur ne peut plus changer d\'avis après avoir accepté l\'[offre d\'achat](https://www.service-public.fr/particuliers/vosdroits/F2753 "Qu'est-ce qu'une offre d'achat d'un bien immobilier ?").

En principe, la promesse prévoit et fixe les délais suivants :

-   Délai de 3 mois en général pour lever l\'option (décision de l\'acheteur d\'acheter le bien)

&nbsp;

-   Délai de réalisation de toutes les clauses suspensives ou de chacune d\'entre elles (par exemple, 2 mois pour un permis de construire)
-   Délai pour signer l\'acte authentique de vente après la levée d\'option

La promesse peut prévoir une **prolongation** automatique en cas d\'insuffisance du délai initial, pour un retard dû aux difficultés d\'obtention de certaines pièces.

Avant la fin du délai fixé dans la promesse, les 2 parties peuvent également décider de la prolonger. Elles rédigent un avenant Document complémentaire du contrat constatant une modification, une adaptation ou un complément qui y sont apportés d\'un commun accord entre les 2 partiesau contrat dans lequel elles précisent l\'objet de cette prolongation.

La date de signature de l\'acte de vente est ainsi décalée.

À noter

Dans les départements du Haut-Rhin, du Bas-Rhin et de la Moselle, la promesse de vente doit être suivie d\'un acte authentique de vente dans un délai de 6 mois. Les parties ne peuvent pas convenir d\'un délai supérieur.

## Compromis de vente

Tout déplier

Le compromis de vente est un avant-contrat dans lequel un vendeur et un candidat acheteur s\'engagent réciproquement à vendre et à acquérir un bien à un certain prix.

Le compromis définit les conditions de la vente. Elles ne peuvent être modifiées sans l\'accord des 2 parties.

Le compromis de vente constate **l\'accord des parties** sur le bien (le terrain) et sur le prix. Il définit avec précision les **conditions de la vente**.

Il contient notamment les informations suivantes :

-   **Coordonnées** du vendeur et de l\'acheteur
-   **Descriptif détaillé du terrain** et sa surface exacte (références cadastrales, adresse\...)
-   **Prix** de vente et **modes de paiement** (avec ou sans l\'aide d\'un prêt immobilier)
-   Suspend l\'exécution d\'un contrat tant qu\'un événement futur et incertain n\'est pas survenu[Condition suspensive de prêt](https://www.service-public.fr/particuliers/vosdroits/F188 "Promesse de vente et condition suspensive d'obtention du prêt : de quoi s'agit-il ?") si vous prenez un crédit immobilier
-   Condition suspensive d\'obtention d\'un [permis de construire](https://www.service-public.fr/particuliers/vosdroits/F1986 "Permis de construire") si vous en demandez un
-   Existence ou non d\'un [bornage](https://www.service-public.fr/particuliers/vosdroits/F3037 "Bornage de terrains") du terrain
-   Existence ou non d\'hypothèqueDroit sur un bien immobilier accordé à une personne à qui l\'on doit de l\'argent en garantie du paiement de sa dette, de servitudeContrainte imposée à une propriété au profit d\'une autre propriété (par exemple, un droit de passage) sur le terrain
-   Montant des **honorairesRémunération des services rendus par les membres de certaines professions libérales (médecins, notaires, avocats, architectes, etc.) **du professionnel chargé de la vente (s\'il y a intervention d\'un professionnel) et nom de la personne devant payer ces honoraires
-   Montant du **dépôt de garantie**
-   **Date limite de signature de [l\'acte de vente](https://www.service-public.fr/particuliers/vosdroits/F258 "Acte de vente d'un terrain à bâtir isolé") **(elle intervient généralement 3 mois après la signature de la promesse de vente)

##### Documents annexés au compromis

-   [État des risques et pollutions (naturels, miniers, technologiques, sismiques, radon\...)](https://www.service-public.fr/particuliers/vosdroits/F12239 "Diagnostic immobilier : état des risques")
-   Étude de sol **dans les zones exposées** au phénomène de mouvement de terrain différentiel consécutif à la sécheresse et à la réhydratation des **sols argileux**
-   [État des nuisances sonores aériennes](https://www.service-public.fr/particuliers/vosdroits/F35266 "Diagnostic immobilier sur les bruits des aéroports") **dans les zones de bruit** définies par un plan d\'exposition au bruit

Si le vendeur ou l\'acheteur connaît une information dont l\'importance est déterminante pour le consentement ou l\'accord de l\'autre, il doit l\'en informer dans le compromis.

Le compromis de vente prend la forme d\'un acte sous signature privéeActe rédigé et signé par des particuliers, sans la présence d\'un notaire (par exemple, un contrat) ou d\'un acte authentiqueDocument établi par un officier public compétent, tels qu\'un notaire, un commissaire de justice (anciennement huissier de justice et commissaire-priseur judiciaire), un officier d\'état civil, rédigé selon les formalités exigées par la loi et dont le contenu peut avoir la même valeur qu\'une décision judiciaire. Il peut être signé sur support papier ou électronique.

Répondez aux questions successives et les réponses s'afficheront automatiquement

#### Support papier

Il est réalisé en 2 exemplaires originaux (1 pour le vendeur, 1 pour l\'acheteur), sauf quand un original unique est conservé par un professionnel (notaire, agent immobilier).

#### Support électronique

Le procédé de signature et de conservation de l\'acte doit permettre à chaque partie d\'avoir un exemplaire de la promese ou d\'y avoir accès.

Vous avez choisi

Choisissez votre cas

-    Support papier
-    Support électronique

#### Support papier

Il est réalisé en 2 exemplaires originaux (1 pour le vendeur, 1 pour l\'acheteur), sauf quand un original unique est conservé par un professionnel (notaire, agent immobilier).

#### Support électronique

Le procédé de signature et de conservation de l\'acte doit permettre à chaque partie d\'avoir un exemplaire de la promese ou d\'y avoir accès.

À savoir  

Un acte authentique est toujours exigé pour un compromis de vente signé par une personne physique d\'une durée de validité supérieure à 18 mois.

Une somme correspondant à **5 % à 10 % du prix de vente** peut être demandée à l\'acheteur le jour de la signature du compromis.

Ce **dépôt de garantie** est encaissé et bloqué jusqu\'à la conclusion du contrat de vente sur le compte séquestreCompte bancaire professionnel dédié à mettre en dépôt les fonds (sommes d\'argent), versés en acompte par l\'acquéreur d\'un bien lors d\'une transaction (immobilière) du notaire.

**Si les conditions suspensivesSuspend l\'exécution d\'un contrat tant qu\'un événement futur et incertain n\'est pas survenu prévues dans le compromis ne se réalisent pas**, la somme est rendue.

**Si l\'acheteur renonce à l\'achat**, elle est conservée par le propriétaire.

**Quand l\'acte définitif de vente est signé,** la somme versée est déduite du prix de vente.

L\'acheteur d\'un terrain à bâtir ne bénéficie pas du droit de rétractation.

Le vendeur ne peut plus changer d\'avis après avoir accepter l\'[offre d\'achat](https://www.service-public.fr/particuliers/vosdroits/F2753 "Qu'est-ce qu'une offre d'achat d'un bien immobilier ?").

En principe, le compromis distingue et fixe les délais suivants :

-   Délai de réalisation des toutes les clauses suspensives ou de chacune d\'entre elles (par exemple, 2 mois pour un permis de construire)
-   Délai **de 3 ou 4 mois** jusqu\'à la signature de l\'acte authentique de vente

Le compromis peut prévoir une **prolongation** automatique en cas d\'insuffisance du délai initial, pour un retard dû aux difficultés d\'obtention de certains documents.

Avant la fin du délai fixé dans le compromis, les 2 parties peuvent également décider de le prolonger. Elles rédigent un avenantDocument complémentaire du contrat constatant une modification, une adaptation ou un complément qui y sont apportés d\'un commun accord entre les 2 parties au contrat dans lequel elles précisent l\'objet de cette prolongation.

La date de signature de l\'acte de vente est ainsi décalée.

À noter

Dans les départements du Haut-Rhin, du Bas-Rhin et de la Moselle, le compromis de vente doit être suivi d\'un acte authentique de vente dans un délai de 6 mois. Les parties ne peuvent pas convenir d\'un délai supérieur.

Vous avez une question ? Vous souhaitez être accompagné(e) dans vos démarches ?

Trouver un interlocuteur

Pivot Local Quelle est votre ville ou code postal ? Exemple : Sainte-Cécile-les-Vignes ou 95200

Des suggestions vous seront proposées lors de votre saisie situées après le champ

-   [Agence départementale pour l\'information sur le logement (Adil) ](https://www.anil.org/lanil-et-les-adil/votre-adil/ "Agence départementale pour l'information sur le logement (Adil) - www.anil.org - Nouvelle fenêtre")

-   
    [Code civil : article 1124](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000032040818/ "Code civil : article 1124 - legifrance.gouv.fr - Nouvelle fenêtre")

    Promesse unilatérale de vente

-   
    [Code civil : article 1375](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000032042416/ "Code civil : article 1375 - legifrance.gouv.fr - Nouvelle fenêtre")

    Nombre d\'exemplaires

-   
    [Code civil : article 1367](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000032042456 "Code civil : article 1367 - legifrance.gouv.fr - Nouvelle fenêtre")

    Signature électronique

-   
    [Code civil : article 1589](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000006441324/ "Code civil : article 1589 - legifrance.gouv.fr - Nouvelle fenêtre")

    Promesse de vente

-   
    [Code civil : article 1589-2](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000006441326 "Code civil : article 1589-2 - legifrance.gouv.fr - Nouvelle fenêtre")

    Enregistrement promesse de vente unilatérale

-   
    [Code de la construction et de l\'habitation : articles L290-1 et L290-2](https://www.legifrance.gouv.fr/codes/id/LEGISCTA000020466370/ "Code de la construction et de l'habitation : articles L290-1 et L290-2 - legifrance.gouv.fr - Nouvelle fenêtre")

    Promesse de vente de plus de 18 mois sous acte authentique

-   
    [Code de la consommation : articles L313-40 à L313-45](https://www.legifrance.gouv.fr/codes/id/LEGISCTA000032225898/ "Code de la consommation : articles L313-40 à L313-45 - legifrance.gouv.fr - Nouvelle fenêtre")

    Condition suspensive

-   
    [Code de la construction et de l\'habitation : articles L132-4 à L132-9](https://www.legifrance.gouv.fr/codes/section_lc/LEGITEXT000006074096/LEGISCTA000041565555 "Code de la construction et de l'habitation : articles L132-4 à L132-9 - legifrance.gouv.fr - Nouvelle fenêtre")

    Risques liés aux sols argileux

-   
    [Code de la construction et de l\'habitation : articles R132-3 à R132-8](https://www.legifrance.gouv.fr/codes/section_lc/LEGITEXT000006074096/LEGISCTA000043818703 "Code de la construction et de l'habitation : articles R132-3 à R132-8 - legifrance.gouv.fr - Nouvelle fenêtre")

    Contenu et durée de validité des études géotechniques

-   
    [Arrêté du 22 juillet 2020 définissant le contenu des études géotechniques dans les zones exposées au phénomène de mouvement de terrain différentiel du à la sécheresse et à la réhydratation des sols](https://www.legifrance.gouv.fr/loda/id/JORFTEXT000042211476/ "Arrêté du 22 juillet 2020 définissant le contenu des études géotechniques dans les zones exposées au phénomène de mouvement de terrain différentiel du à la sécheresse et à la réhydratation des sols - legifrance.gouv.fr - Nouvelle fenêtre")

-   
    [Arrêté du 22 juillet 2020 définissant les zones exposées au phénomène de mouvement de terrain différentiel des sols argileux](https://www.legifrance.gouv.fr/jorf/id/JORFTEXT000042220805 "Arrêté du 22 juillet 2020 définissant les zones exposées au phénomène de mouvement de terrain différentiel des sols argileux - legifrance.gouv.fr - Nouvelle fenêtre")

-   
    [Code de l\'urbanisme : article L112-11](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000039785320/ "Code de l'urbanisme : article L112-11 - legifrance.gouv.fr - Nouvelle fenêtre")

    État des nuisances sonores aériennes

-   
    [État des nuisances sonores aériennes](https://www.service-public.fr/particuliers/vosdroits/R56743)

    Formulaire

-   
    [Rechercher les risques naturels et technologiques sur Géorisques](https://www.service-public.fr/particuliers/vosdroits/R56989)

    Outil de recherche

## Questions ? Réponses !

-   
    [Quelles précautions prendre avant l\'achat d\'un terrain à bâtir isolé?](https://www.service-public.fr/particuliers/vosdroits/F33818)

-   
    [Acte de vente d'un terrain à bâtir isolé](https://www.service-public.fr/particuliers/vosdroits/F258)

    Service-Public.fr

## Cette page vous a-t-elle été utile ?

## Cette page vous a-t-elle été utile ?

Pas du tout

Un peu

Moyen

Beaucoup

Parfait !

L'équipe Service-Public.fr vous remercie

[Je vais sur la page d'accueil](https://www.service-public.fr/particuliers)

Masquer le message

Vous avez noté 1 sur 5 : Pas du tout

Vous avez noté 2 sur 5 : Un peu

Vous avez noté 3 sur 5 : Moyen

Vous avez noté 4 sur 5 : Beaucoup

Vous avez noté 5 sur 5 : Parfait !

Je fais une** remarque **sur cette page

L'équipe Service-Public.fr vous remercie pour vos remarques utiles à l\'amélioration du site.

Pour des raisons de sécurité, nous ne pouvons valider ce formulaire suite à une trop longue période d'inactivité. Merci de recharger la page si vous souhaitez le soumettre à nouveau.

Une erreur technique s\'est produite. Merci de réessayer ultérieurement.

## Vos remarques pour améliorer la page

### La page est-elle facile à comprendre ?

### L'information a-t-elle été utile ?

### Avez-vous rencontré une difficulté ?

Non

Je ne suis ** pas satisfait(e) ** de cette réglementation

Cette page ** ne correspond pas ** à ma situation

Il ** manque des informations ** *(préciser lesquelles)*

Les informations ne sont ** pas claires ** *(préciser lesquelles)*

Il y a une** erreur **dans la page  *(préciser laquelle)*

### Avez-vous des suggestions pour améliorer la page ?

Je suggère une modification à une rédactrice ou un rédacteur Service-Public.fr Saisie complémentaire requise -- affichage automatique

Les **informations** demandées sont **obligatoires**

Des exemples nous permettent d'améliorer les pages plus facilement : ***« Je n'ai pas compris la partie sur\... »***, ***« Je cherchais des informations plus précises/plus claires sur\... »***.

Votre suggestion Ne mentionnez pas de données personnelles (nom, adresse, numéros de téléphone, numéro de sécurité sociale, numéro fiscal, lieu et date de naissance\...) à l\'exception, bien sûr, de votre adresse de messagerie.

1000 caractères restants

#### Comment pouvons-nous vous répondre ?

Votre adresse email Exemple : nom@exemple.com

##### Protection des données personnelles

Les informations recueillies à partir de ce formulaire sont traitées par la DILA pour répondre à votre demande. Pour connaitre et exercer vos droits, veuillez consulter la rubrique [données personnelles et sécurité](https://www.service-public.fr/P10001).

Envoyer vos remarques

## Recevoir la lettre de Service-Public.fr

Abonnement hebdomadaire gratuit

[S'abonner](https://www.service-public.fr/actualites/lettresp/abonnement "S’abonner à notre lettre d’information")

-   [Lire la dernière lettre](https://www.service-public.fr/actualites/lettresp/archives/)
-   [Voir toutes les lettres](https://www.service-public.fr/actualites/lettresp/archives)

## Suivez-nous sur les réseaux sociaux

-   [facebook](https://www.facebook.com/ServicePublicFr "facebook - nouvelle fenêtre")
-   [X (anciennement twitter)](https://x.com/servicepublicfr "X (anciennement twitter) - nouvelle fenêtre")
-   [linkedin](https://www.linkedin.com/company/service-public-fr "linkedin - nouvelle fenêtre")
-   [instagram](https://www.instagram.com/servicepublicfr/ "instagram - nouvelle fenêtre")
-   [youtube](https://www.youtube.com/ServicePublicFrance "youtube - nouvelle fenêtre")

Fiches pratiques par thèmes

-   [Papiers - Citoyenneté - Élections](https://www.service-public.fr/particuliers/vosdroits/N19810)
-   [Famille - Scolarité](https://www.service-public.fr/particuliers/vosdroits/N19805)
-   [Social - Santé](https://www.service-public.fr/particuliers/vosdroits/N19811)
-   [Travail - Formation](https://www.service-public.fr/particuliers/vosdroits/N19806)
-   [Logement](https://www.service-public.fr/particuliers/vosdroits/N19808)
-   [Transports - Mobilité](https://www.service-public.fr/particuliers/vosdroits/N19812)
-   [Argent - Impôts - Consommation](https://www.service-public.fr/particuliers/vosdroits/N19803)
-   [Justice](https://www.service-public.fr/particuliers/vosdroits/N19807)
-   [Étranger - Europe](https://www.service-public.fr/particuliers/vosdroits/N19804)
-   [Loisirs - Sports - Culture](https://www.service-public.fr/particuliers/vosdroits/N19809)
-   [Associations](https://www.service-public.fr/particuliers/vosdroits/N31931)

Démarches et outils

-   [Démarches en ligne](https://www.service-public.fr/particuliers/recherche?rubricFilter=serviceEnLigne&rubricTypeFilter=teleservice "Démarches en ligne - www.service-public.fr - Nouvelle fenêtre")
-   [Formulaires administratifs (cerfas)](https://www.service-public.fr/particuliers/recherche?rubricFilter=serviceEnLigne&rubricTypeFilter=formulaire "Formulaires administratifs (cerfas) - www.service-public.fr - Nouvelle fenêtre")
-   [Simulateurs](https://www.service-public.fr/particuliers/recherche?rubricFilter=serviceEnLigne&rubricTypeFilter=simulateur "Simulateurs - www.service-public.fr - Nouvelle fenêtre")
-   [Modèles de lettres](https://www.service-public.fr/particuliers/recherche?rubricFilter=serviceEnLigne&rubricTypeFilter=modeleLettre "Modèles de lettres - www.service-public.fr - Nouvelle fenêtre")
-   [Outils de recherche](https://www.service-public.fr/particuliers/recherche?rubricFilter=serviceEnLigne&rubricTypeFilter=outilrecherche "Outils de recherche - www.service-public.fr - Nouvelle fenêtre")
-   [Allo Service Public](https://www.service-public.fr/particuliers/vosdroits/F33683 "Allo Service Public - www.service-public.fr - Nouvelle fenêtre")
-   [Annuaire de l\'administration](https://lannuaire.service-public.fr/ "Annuaire de l'administration - lannuaire.service-public.fr - Nouvelle fenêtre")

Nous connaître

-   [Missions et chiffres](https://www.service-public.fr/D10002)
-   [Mise à disposition des données](https://www.service-public.fr/P10004)
-   [Engagements et qualité](https://www.service-public.fr/P10002)
-   [Aide](https://www.service-public.fr/D10003)
-   [Vous êtes une administration ?](https://www.service-public.fr/D10000)
-   [Vous êtes journaliste ?](https://www.service-public.fr/P10026)
-   [Contacter Service-Public.fr](https://www.service-public.fr/P10017)

République\
Française

Service Public vous informe et vous oriente vers les services qui permettent de connaître vos obligations, d'exercer vos droits et de faire vos démarches du quotidien.

Il est édité par la [Direction de l'information légale et administrative ](https://www.dila.premier-ministre.gouv.fr/ "Direction de l'information légale et administrative - Nouvelle fenêtre") et réalisé en partenariat avec les administrations nationales et locales.

-   [legifrance.gouv.fr](https://www.legifrance.gouv.fr/ "legifrance.gouv.fr - Nouvelle fenêtre")
-   [info.gouv.fr](https://www.info.gouv.fr/ "info.gouv.fr - Nouvelle fenêtre")
-   [data.gouv.fr](https://www.data.gouv.fr/ "data.gouv.fr - Nouvelle fenêtre")

Nos partenaires

[![Your Europe]()](https://europa.eu/youreurope/index.htm#en "Your Europe - europa.eu - Nouvelle fenêtre")

-   [![Vie publique, au cœur du débat public]()](https://www.vie-publique.fr/ "Vie publique, au cœur du débat public - vie-publique.fr - Nouvelle fenêtre")
-   [![Entreprendre.Service-Public.fr]()](https://entreprendre.service-public.fr/ "Entreprendre.Service-Public - entreprendre.service-Public.fr - Nouvelle fenêtre")
-   [![Service Publics +]()](https://www.plus.transformation.gouv.fr/ "Services Publics + - plus.transformation.gouv.fr - Nouvelle fenêtre")

-   [Plan du site](https://www.service-public.fr/P10003)
-   [Accessibilité : totalement conforme](https://www.service-public.fr/P10000)
-   [Accessibilité des services en ligne](https://www.service-public.fr/P10125)
-   [Mentions légales](https://www.service-public.fr/P10025)
-   [Données personnelles et sécurité](https://www.service-public.fr/P10001)
-   [Conditions générales d\'utilisation](https://www.service-public.fr/P10050)
-   [Gestion des cookies](https://www.service-public.fr/particuliers/vosdroits/F2057# "Gestion des cookies")

Sauf mention contraire, tous les contenus de ce site sont sous [licence etalab-2.0 ](https://github.com/etalab/licence-ouverte/blob/master/LO.md "licence etalab-2.0 - nouvelle fenêtre")